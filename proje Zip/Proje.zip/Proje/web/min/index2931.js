
/* jquery-2.1.1.min.js */

/* 1 */ /*! jQuery v2.1.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
/* 2 */ !function(a,b){"object"==typeof module&&"object"==typeof module.exports?module.exports=a.document?b(a,!0):function(a){if(!a.document)throw new Error("jQuery requires a window with a document");return b(a)}:b(a)}("undefined"!=typeof window?window:this,function(a,b){var c=[],d=c.slice,e=c.concat,f=c.push,g=c.indexOf,h={},i=h.toString,j=h.hasOwnProperty,k={},l=a.document,m="2.1.1",n=function(a,b){return new n.fn.init(a,b)},o=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,p=/^-ms-/,q=/-([\da-z])/gi,r=function(a,b){return b.toUpperCase()};n.fn=n.prototype={jquery:m,constructor:n,selector:"",length:0,toArray:function(){return d.call(this)},get:function(a){return null!=a?0>a?this[a+this.length]:this[a]:d.call(this)},pushStack:function(a){var b=n.merge(this.constructor(),a);return b.prevObject=this,b.context=this.context,b},each:function(a,b){return n.each(this,a,b)},map:function(a){return this.pushStack(n.map(this,function(b,c){return a.call(b,c,b)}))},slice:function(){return this.pushStack(d.apply(this,arguments))},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},eq:function(a){var b=this.length,c=+a+(0>a?b:0);return this.pushStack(c>=0&&b>c?[this[c]]:[])},end:function(){return this.prevObject||this.constructor(null)},push:f,sort:c.sort,splice:c.splice},n.extend=n.fn.extend=function(){var a,b,c,d,e,f,g=arguments[0]||{},h=1,i=arguments.length,j=!1;for("boolean"==typeof g&&(j=g,g=arguments[h]||{},h++),"object"==typeof g||n.isFunction(g)||(g={}),h===i&&(g=this,h--);i>h;h++)if(null!=(a=arguments[h]))for(b in a)c=g[b],d=a[b],g!==d&&(j&&d&&(n.isPlainObject(d)||(e=n.isArray(d)))?(e?(e=!1,f=c&&n.isArray(c)?c:[]):f=c&&n.isPlainObject(c)?c:{},g[b]=n.extend(j,f,d)):void 0!==d&&(g[b]=d));return g},n.extend({expando:"jQuery"+(m+Math.random()).replace(/\D/g,""),isReady:!0,error:function(a){throw new Error(a)},noop:function(){},isFunction:function(a){return"function"===n.type(a)},isArray:Array.isArray,isWindow:function(a){return null!=a&&a===a.window},isNumeric:function(a){return!n.isArray(a)&&a-parseFloat(a)>=0},isPlainObject:function(a){return"object"!==n.type(a)||a.nodeType||n.isWindow(a)?!1:a.constructor&&!j.call(a.constructor.prototype,"isPrototypeOf")?!1:!0},isEmptyObject:function(a){var b;for(b in a)return!1;return!0},type:function(a){return null==a?a+"":"object"==typeof a||"function"==typeof a?h[i.call(a)]||"object":typeof a},globalEval:function(a){var b,c=eval;a=n.trim(a),a&&(1===a.indexOf("use strict")?(b=l.createElement("script"),b.text=a,l.head.appendChild(b).parentNode.removeChild(b)):c(a))},camelCase:function(a){return a.replace(p,"ms-").replace(q,r)},nodeName:function(a,b){return a.nodeName&&a.nodeName.toLowerCase()===b.toLowerCase()},each:function(a,b,c){var d,e=0,f=a.length,g=s(a);if(c){if(g){for(;f>e;e++)if(d=b.apply(a[e],c),d===!1)break}else for(e in a)if(d=b.apply(a[e],c),d===!1)break}else if(g){for(;f>e;e++)if(d=b.call(a[e],e,a[e]),d===!1)break}else for(e in a)if(d=b.call(a[e],e,a[e]),d===!1)break;return a},trim:function(a){return null==a?"":(a+"").replace(o,"")},makeArray:function(a,b){var c=b||[];return null!=a&&(s(Object(a))?n.merge(c,"string"==typeof a?[a]:a):f.call(c,a)),c},inArray:function(a,b,c){return null==b?-1:g.call(b,a,c)},merge:function(a,b){for(var c=+b.length,d=0,e=a.length;c>d;d++)a[e++]=b[d];return a.length=e,a},grep:function(a,b,c){for(var d,e=[],f=0,g=a.length,h=!c;g>f;f++)d=!b(a[f],f),d!==h&&e.push(a[f]);return e},map:function(a,b,c){var d,f=0,g=a.length,h=s(a),i=[];if(h)for(;g>f;f++)d=b(a[f],f,c),null!=d&&i.push(d);else for(f in a)d=b(a[f],f,c),null!=d&&i.push(d);return e.apply([],i)},guid:1,proxy:function(a,b){var c,e,f;return"string"==typeof b&&(c=a[b],b=a,a=c),n.isFunction(a)?(e=d.call(arguments,2),f=function(){return a.apply(b||this,e.concat(d.call(arguments)))},f.guid=a.guid=a.guid||n.guid++,f):void 0},now:Date.now,support:k}),n.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(a,b){h["[object "+b+"]"]=b.toLowerCase()});function s(a){var b=a.length,c=n.type(a);return"function"===c||n.isWindow(a)?!1:1===a.nodeType&&b?!0:"array"===c||0===b||"number"==typeof b&&b>0&&b-1 in a}var t=function(a){var b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u="sizzle"+-new Date,v=a.document,w=0,x=0,y=gb(),z=gb(),A=gb(),B=function(a,b){return a===b&&(l=!0),0},C="undefined",D=1<<31,E={}.hasOwnProperty,F=[],G=F.pop,H=F.push,I=F.push,J=F.slice,K=F.indexOf||function(a){for(var b=0,c=this.length;c>b;b++)if(this[b]===a)return b;return-1},L="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",M="[\\x20\\t\\r\\n\\f]",N="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",O=N.replace("w","w#"),P="\\["+M+"*("+N+")(?:"+M+"*([*^$|!~]?=)"+M+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+O+"))|)"+M+"*\\]",Q=":("+N+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+P+")*)|.*)\\)|)",R=new RegExp("^"+M+"+|((?:^|[^\\\\])(?:\\\\.)*)"+M+"+$","g"),S=new RegExp("^"+M+"*,"+M+"*"),T=new RegExp("^"+M+"*([>+~]|"+M+")"+M+"*"),U=new RegExp("="+M+"*([^\\]'\"]*?)"+M+"*\\]","g"),V=new RegExp(Q),W=new RegExp("^"+O+"$"),X={ID:new RegExp("^#("+N+")"),CLASS:new RegExp("^\\.("+N+")"),TAG:new RegExp("^("+N.replace("w","w*")+")"),ATTR:new RegExp("^"+P),PSEUDO:new RegExp("^"+Q),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+M+"*(even|odd|(([+-]|)(\\d*)n|)"+M+"*(?:([+-]|)"+M+"*(\\d+)|))"+M+"*\\)|)","i"),bool:new RegExp("^(?:"+L+")$","i"),needsContext:new RegExp("^"+M+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+M+"*((?:-\\d)?\\d*)"+M+"*\\)|)(?=[^-]|$)","i")},Y=/^(?:input|select|textarea|button)$/i,Z=/^h\d$/i,$=/^[^{]+\{\s*\[native \w/,_=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,ab=/[+~]/,bb=/'|\\/g,cb=new RegExp("\\\\([\\da-f]{1,6}"+M+"?|("+M+")|.)","ig"),db=function(a,b,c){var d="0x"+b-65536;return d!==d||c?b:0>d?String.fromCharCode(d+65536):String.fromCharCode(d>>10|55296,1023&d|56320)};try{I.apply(F=J.call(v.childNodes),v.childNodes),F[v.childNodes.length].nodeType}catch(eb){I={apply:F.length?function(a,b){H.apply(a,J.call(b))}:function(a,b){var c=a.length,d=0;while(a[c++]=b[d++]);a.length=c-1}}}function fb(a,b,d,e){var f,h,j,k,l,o,r,s,w,x;if((b?b.ownerDocument||b:v)!==n&&m(b),b=b||n,d=d||[],!a||"string"!=typeof a)return d;if(1!==(k=b.nodeType)&&9!==k)return[];if(p&&!e){if(f=_.exec(a))if(j=f[1]){if(9===k){if(h=b.getElementById(j),!h||!h.parentNode)return d;if(h.id===j)return d.push(h),d}else if(b.ownerDocument&&(h=b.ownerDocument.getElementById(j))&&t(b,h)&&h.id===j)return d.push(h),d}else{if(f[2])return I.apply(d,b.getElementsByTagName(a)),d;if((j=f[3])&&c.getElementsByClassName&&b.getElementsByClassName)return I.apply(d,b.getElementsByClassName(j)),d}if(c.qsa&&(!q||!q.test(a))){if(s=r=u,w=b,x=9===k&&a,1===k&&"object"!==b.nodeName.toLowerCase()){o=g(a),(r=b.getAttribute("id"))?s=r.replace(bb,"\\$&"):b.setAttribute("id",s),s="[id='"+s+"'] ",l=o.length;while(l--)o[l]=s+qb(o[l]);w=ab.test(a)&&ob(b.parentNode)||b,x=o.join(",")}if(x)try{return I.apply(d,w.querySelectorAll(x)),d}catch(y){}finally{r||b.removeAttribute("id")}}}return i(a.replace(R,"$1"),b,d,e)}function gb(){var a=[];function b(c,e){return a.push(c+" ")>d.cacheLength&&delete b[a.shift()],b[c+" "]=e}return b}function hb(a){return a[u]=!0,a}function ib(a){var b=n.createElement("div");try{return!!a(b)}catch(c){return!1}finally{b.parentNode&&b.parentNode.removeChild(b),b=null}}function jb(a,b){var c=a.split("|"),e=a.length;while(e--)d.attrHandle[c[e]]=b}function kb(a,b){var c=b&&a,d=c&&1===a.nodeType&&1===b.nodeType&&(~b.sourceIndex||D)-(~a.sourceIndex||D);if(d)return d;if(c)while(c=c.nextSibling)if(c===b)return-1;return a?1:-1}function lb(a){return function(b){var c=b.nodeName.toLowerCase();return"input"===c&&b.type===a}}function mb(a){return function(b){var c=b.nodeName.toLowerCase();return("input"===c||"button"===c)&&b.type===a}}function nb(a){return hb(function(b){return b=+b,hb(function(c,d){var e,f=a([],c.length,b),g=f.length;while(g--)c[e=f[g]]&&(c[e]=!(d[e]=c[e]))})})}function ob(a){return a&&typeof a.getElementsByTagName!==C&&a}c=fb.support={},f=fb.isXML=function(a){var b=a&&(a.ownerDocument||a).documentElement;return b?"HTML"!==b.nodeName:!1},m=fb.setDocument=function(a){var b,e=a?a.ownerDocument||a:v,g=e.defaultView;return e!==n&&9===e.nodeType&&e.documentElement?(n=e,o=e.documentElement,p=!f(e),g&&g!==g.top&&(g.addEventListener?g.addEventListener("unload",function(){m()},!1):g.attachEvent&&g.attachEvent("onunload",function(){m()})),c.attributes=ib(function(a){return a.className="i",!a.getAttribute("className")}),c.getElementsByTagName=ib(function(a){return a.appendChild(e.createComment("")),!a.getElementsByTagName("*").length}),c.getElementsByClassName=$.test(e.getElementsByClassName)&&ib(function(a){return a.innerHTML="<div class='a'></div><div class='a i'></div>",a.firstChild.className="i",2===a.getElementsByClassName("i").length}),c.getById=ib(function(a){return o.appendChild(a).id=u,!e.getElementsByName||!e.getElementsByName(u).length}),c.getById?(d.find.ID=function(a,b){if(typeof b.getElementById!==C&&p){var c=b.getElementById(a);return c&&c.parentNode?[c]:[]}},d.filter.ID=function(a){var b=a.replace(cb,db);return function(a){return a.getAttribute("id")===b}}):(delete d.find.ID,d.filter.ID=function(a){var b=a.replace(cb,db);return function(a){var c=typeof a.getAttributeNode!==C&&a.getAttributeNode("id");return c&&c.value===b}}),d.find.TAG=c.getElementsByTagName?function(a,b){return typeof b.getElementsByTagName!==C?b.getElementsByTagName(a):void 0}:function(a,b){var c,d=[],e=0,f=b.getElementsByTagName(a);if("*"===a){while(c=f[e++])1===c.nodeType&&d.push(c);return d}return f},d.find.CLASS=c.getElementsByClassName&&function(a,b){return typeof b.getElementsByClassName!==C&&p?b.getElementsByClassName(a):void 0},r=[],q=[],(c.qsa=$.test(e.querySelectorAll))&&(ib(function(a){a.innerHTML="<select msallowclip=''><option selected=''></option></select>",a.querySelectorAll("[msallowclip^='']").length&&q.push("[*^$]="+M+"*(?:''|\"\")"),a.querySelectorAll("[selected]").length||q.push("\\["+M+"*(?:value|"+L+")"),a.querySelectorAll(":checked").length||q.push(":checked")}),ib(function(a){var b=e.createElement("input");b.setAttribute("type","hidden"),a.appendChild(b).setAttribute("name","D"),a.querySelectorAll("[name=d]").length&&q.push("name"+M+"*[*^$|!~]?="),a.querySelectorAll(":enabled").length||q.push(":enabled",":disabled"),a.querySelectorAll("*,:x"),q.push(",.*:")})),(c.matchesSelector=$.test(s=o.matches||o.webkitMatchesSelector||o.mozMatchesSelector||o.oMatchesSelector||o.msMatchesSelector))&&ib(function(a){c.disconnectedMatch=s.call(a,"div"),s.call(a,"[s!='']:x"),r.push("!=",Q)}),q=q.length&&new RegExp(q.join("|")),r=r.length&&new RegExp(r.join("|")),b=$.test(o.compareDocumentPosition),t=b||$.test(o.contains)?function(a,b){var c=9===a.nodeType?a.documentElement:a,d=b&&b.parentNode;return a===d||!(!d||1!==d.nodeType||!(c.contains?c.contains(d):a.compareDocumentPosition&&16&a.compareDocumentPosition(d)))}:function(a,b){if(b)while(b=b.parentNode)if(b===a)return!0;return!1},B=b?function(a,b){if(a===b)return l=!0,0;var d=!a.compareDocumentPosition-!b.compareDocumentPosition;return d?d:(d=(a.ownerDocument||a)===(b.ownerDocument||b)?a.compareDocumentPosition(b):1,1&d||!c.sortDetached&&b.compareDocumentPosition(a)===d?a===e||a.ownerDocument===v&&t(v,a)?-1:b===e||b.ownerDocument===v&&t(v,b)?1:k?K.call(k,a)-K.call(k,b):0:4&d?-1:1)}:function(a,b){if(a===b)return l=!0,0;var c,d=0,f=a.parentNode,g=b.parentNode,h=[a],i=[b];if(!f||!g)return a===e?-1:b===e?1:f?-1:g?1:k?K.call(k,a)-K.call(k,b):0;if(f===g)return kb(a,b);c=a;while(c=c.parentNode)h.unshift(c);c=b;while(c=c.parentNode)i.unshift(c);while(h[d]===i[d])d++;return d?kb(h[d],i[d]):h[d]===v?-1:i[d]===v?1:0},e):n},fb.matches=function(a,b){return fb(a,null,null,b)},fb.matchesSelector=function(a,b){if((a.ownerDocument||a)!==n&&m(a),b=b.replace(U,"='$1']"),!(!c.matchesSelector||!p||r&&r.test(b)||q&&q.test(b)))try{var d=s.call(a,b);if(d||c.disconnectedMatch||a.document&&11!==a.document.nodeType)return d}catch(e){}return fb(b,n,null,[a]).length>0},fb.contains=function(a,b){return(a.ownerDocument||a)!==n&&m(a),t(a,b)},fb.attr=function(a,b){(a.ownerDocument||a)!==n&&m(a);var e=d.attrHandle[b.toLowerCase()],f=e&&E.call(d.attrHandle,b.toLowerCase())?e(a,b,!p):void 0;return void 0!==f?f:c.attributes||!p?a.getAttribute(b):(f=a.getAttributeNode(b))&&f.specified?f.value:null},fb.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)},fb.uniqueSort=function(a){var b,d=[],e=0,f=0;if(l=!c.detectDuplicates,k=!c.sortStable&&a.slice(0),a.sort(B),l){while(b=a[f++])b===a[f]&&(e=d.push(f));while(e--)a.splice(d[e],1)}return k=null,a},e=fb.getText=function(a){var b,c="",d=0,f=a.nodeType;if(f){if(1===f||9===f||11===f){if("string"==typeof a.textContent)return a.textContent;for(a=a.firstChild;a;a=a.nextSibling)c+=e(a)}else if(3===f||4===f)return a.nodeValue}else while(b=a[d++])c+=e(b);return c},d=fb.selectors={cacheLength:50,createPseudo:hb,match:X,attrHandle:{},find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(a){return a[1]=a[1].replace(cb,db),a[3]=(a[3]||a[4]||a[5]||"").replace(cb,db),"~="===a[2]&&(a[3]=" "+a[3]+" "),a.slice(0,4)},CHILD:function(a){return a[1]=a[1].toLowerCase(),"nth"===a[1].slice(0,3)?(a[3]||fb.error(a[0]),a[4]=+(a[4]?a[5]+(a[6]||1):2*("even"===a[3]||"odd"===a[3])),a[5]=+(a[7]+a[8]||"odd"===a[3])):a[3]&&fb.error(a[0]),a},PSEUDO:function(a){var b,c=!a[6]&&a[2];return X.CHILD.test(a[0])?null:(a[3]?a[2]=a[4]||a[5]||"":c&&V.test(c)&&(b=g(c,!0))&&(b=c.indexOf(")",c.length-b)-c.length)&&(a[0]=a[0].slice(0,b),a[2]=c.slice(0,b)),a.slice(0,3))}},filter:{TAG:function(a){var b=a.replace(cb,db).toLowerCase();return"*"===a?function(){return!0}:function(a){return a.nodeName&&a.nodeName.toLowerCase()===b}},CLASS:function(a){var b=y[a+" "];return b||(b=new RegExp("(^|"+M+")"+a+"("+M+"|$)"))&&y(a,function(a){return b.test("string"==typeof a.className&&a.className||typeof a.getAttribute!==C&&a.getAttribute("class")||"")})},ATTR:function(a,b,c){return function(d){var e=fb.attr(d,a);return null==e?"!="===b:b?(e+="","="===b?e===c:"!="===b?e!==c:"^="===b?c&&0===e.indexOf(c):"*="===b?c&&e.indexOf(c)>-1:"$="===b?c&&e.slice(-c.length)===c:"~="===b?(" "+e+" ").indexOf(c)>-1:"|="===b?e===c||e.slice(0,c.length+1)===c+"-":!1):!0}},CHILD:function(a,b,c,d,e){var f="nth"!==a.slice(0,3),g="last"!==a.slice(-4),h="of-type"===b;return 1===d&&0===e?function(a){return!!a.parentNode}:function(b,c,i){var j,k,l,m,n,o,p=f!==g?"nextSibling":"previousSibling",q=b.parentNode,r=h&&b.nodeName.toLowerCase(),s=!i&&!h;if(q){if(f){while(p){l=b;while(l=l[p])if(h?l.nodeName.toLowerCase()===r:1===l.nodeType)return!1;o=p="only"===a&&!o&&"nextSibling"}return!0}if(o=[g?q.firstChild:q.lastChild],g&&s){k=q[u]||(q[u]={}),j=k[a]||[],n=j[0]===w&&j[1],m=j[0]===w&&j[2],l=n&&q.childNodes[n];while(l=++n&&l&&l[p]||(m=n=0)||o.pop())if(1===l.nodeType&&++m&&l===b){k[a]=[w,n,m];break}}else if(s&&(j=(b[u]||(b[u]={}))[a])&&j[0]===w)m=j[1];else while(l=++n&&l&&l[p]||(m=n=0)||o.pop())if((h?l.nodeName.toLowerCase()===r:1===l.nodeType)&&++m&&(s&&((l[u]||(l[u]={}))[a]=[w,m]),l===b))break;return m-=e,m===d||m%d===0&&m/d>=0}}},PSEUDO:function(a,b){var c,e=d.pseudos[a]||d.setFilters[a.toLowerCase()]||fb.error("unsupported pseudo: "+a);return e[u]?e(b):e.length>1?(c=[a,a,"",b],d.setFilters.hasOwnProperty(a.toLowerCase())?hb(function(a,c){var d,f=e(a,b),g=f.length;while(g--)d=K.call(a,f[g]),a[d]=!(c[d]=f[g])}):function(a){return e(a,0,c)}):e}},pseudos:{not:hb(function(a){var b=[],c=[],d=h(a.replace(R,"$1"));return d[u]?hb(function(a,b,c,e){var f,g=d(a,null,e,[]),h=a.length;while(h--)(f=g[h])&&(a[h]=!(b[h]=f))}):function(a,e,f){return b[0]=a,d(b,null,f,c),!c.pop()}}),has:hb(function(a){return function(b){return fb(a,b).length>0}}),contains:hb(function(a){return function(b){return(b.textContent||b.innerText||e(b)).indexOf(a)>-1}}),lang:hb(function(a){return W.test(a||"")||fb.error("unsupported lang: "+a),a=a.replace(cb,db).toLowerCase(),function(b){var c;do if(c=p?b.lang:b.getAttribute("xml:lang")||b.getAttribute("lang"))return c=c.toLowerCase(),c===a||0===c.indexOf(a+"-");while((b=b.parentNode)&&1===b.nodeType);return!1}}),target:function(b){var c=a.location&&a.location.hash;return c&&c.slice(1)===b.id},root:function(a){return a===o},focus:function(a){return a===n.activeElement&&(!n.hasFocus||n.hasFocus())&&!!(a.type||a.href||~a.tabIndex)},enabled:function(a){return a.disabled===!1},disabled:function(a){return a.disabled===!0},checked:function(a){var b=a.nodeName.toLowerCase();return"input"===b&&!!a.checked||"option"===b&&!!a.selected},selected:function(a){return a.parentNode&&a.parentNode.selectedIndex,a.selected===!0},empty:function(a){for(a=a.firstChild;a;a=a.nextSibling)if(a.nodeType<6)return!1;return!0},parent:function(a){return!d.pseudos.empty(a)},header:function(a){return Z.test(a.nodeName)},input:function(a){return Y.test(a.nodeName)},button:function(a){var b=a.nodeName.toLowerCase();return"input"===b&&"button"===a.type||"button"===b},text:function(a){var b;return"input"===a.nodeName.toLowerCase()&&"text"===a.type&&(null==(b=a.getAttribute("type"))||"text"===b.toLowerCase())},first:nb(function(){return[0]}),last:nb(function(a,b){return[b-1]}),eq:nb(function(a,b,c){return[0>c?c+b:c]}),even:nb(function(a,b){for(var c=0;b>c;c+=2)a.push(c);return a}),odd:nb(function(a,b){for(var c=1;b>c;c+=2)a.push(c);return a}),lt:nb(function(a,b,c){for(var d=0>c?c+b:c;--d>=0;)a.push(d);return a}),gt:nb(function(a,b,c){for(var d=0>c?c+b:c;++d<b;)a.push(d);return a})}},d.pseudos.nth=d.pseudos.eq;for(b in{radio:!0,checkbox:!0,file:!0,password:!0,image:!0})d.pseudos[b]=lb(b);for(b in{submit:!0,reset:!0})d.pseudos[b]=mb(b);function pb(){}pb.prototype=d.filters=d.pseudos,d.setFilters=new pb,g=fb.tokenize=function(a,b){var c,e,f,g,h,i,j,k=z[a+" "];if(k)return b?0:k.slice(0);h=a,i=[],j=d.preFilter;while(h){(!c||(e=S.exec(h)))&&(e&&(h=h.slice(e[0].length)||h),i.push(f=[])),c=!1,(e=T.exec(h))&&(c=e.shift(),f.push({value:c,type:e[0].replace(R," ")}),h=h.slice(c.length));for(g in d.filter)!(e=X[g].exec(h))||j[g]&&!(e=j[g](e))||(c=e.shift(),f.push({value:c,type:g,matches:e}),h=h.slice(c.length));if(!c)break}return b?h.length:h?fb.error(a):z(a,i).slice(0)};function qb(a){for(var b=0,c=a.length,d="";c>b;b++)d+=a[b].value;return d}function rb(a,b,c){var d=b.dir,e=c&&"parentNode"===d,f=x++;return b.first?function(b,c,f){while(b=b[d])if(1===b.nodeType||e)return a(b,c,f)}:function(b,c,g){var h,i,j=[w,f];if(g){while(b=b[d])if((1===b.nodeType||e)&&a(b,c,g))return!0}else while(b=b[d])if(1===b.nodeType||e){if(i=b[u]||(b[u]={}),(h=i[d])&&h[0]===w&&h[1]===f)return j[2]=h[2];if(i[d]=j,j[2]=a(b,c,g))return!0}}}function sb(a){return a.length>1?function(b,c,d){var e=a.length;while(e--)if(!a[e](b,c,d))return!1;return!0}:a[0]}function tb(a,b,c){for(var d=0,e=b.length;e>d;d++)fb(a,b[d],c);return c}function ub(a,b,c,d,e){for(var f,g=[],h=0,i=a.length,j=null!=b;i>h;h++)(f=a[h])&&(!c||c(f,d,e))&&(g.push(f),j&&b.push(h));return g}function vb(a,b,c,d,e,f){return d&&!d[u]&&(d=vb(d)),e&&!e[u]&&(e=vb(e,f)),hb(function(f,g,h,i){var j,k,l,m=[],n=[],o=g.length,p=f||tb(b||"*",h.nodeType?[h]:h,[]),q=!a||!f&&b?p:ub(p,m,a,h,i),r=c?e||(f?a:o||d)?[]:g:q;if(c&&c(q,r,h,i),d){j=ub(r,n),d(j,[],h,i),k=j.length;while(k--)(l=j[k])&&(r[n[k]]=!(q[n[k]]=l))}if(f){if(e||a){if(e){j=[],k=r.length;while(k--)(l=r[k])&&j.push(q[k]=l);e(null,r=[],j,i)}k=r.length;while(k--)(l=r[k])&&(j=e?K.call(f,l):m[k])>-1&&(f[j]=!(g[j]=l))}}else r=ub(r===g?r.splice(o,r.length):r),e?e(null,g,r,i):I.apply(g,r)})}function wb(a){for(var b,c,e,f=a.length,g=d.relative[a[0].type],h=g||d.relative[" "],i=g?1:0,k=rb(function(a){return a===b},h,!0),l=rb(function(a){return K.call(b,a)>-1},h,!0),m=[function(a,c,d){return!g&&(d||c!==j)||((b=c).nodeType?k(a,c,d):l(a,c,d))}];f>i;i++)if(c=d.relative[a[i].type])m=[rb(sb(m),c)];else{if(c=d.filter[a[i].type].apply(null,a[i].matches),c[u]){for(e=++i;f>e;e++)if(d.relative[a[e].type])break;return vb(i>1&&sb(m),i>1&&qb(a.slice(0,i-1).concat({value:" "===a[i-2].type?"*":""})).replace(R,"$1"),c,e>i&&wb(a.slice(i,e)),f>e&&wb(a=a.slice(e)),f>e&&qb(a))}m.push(c)}return sb(m)}function xb(a,b){var c=b.length>0,e=a.length>0,f=function(f,g,h,i,k){var l,m,o,p=0,q="0",r=f&&[],s=[],t=j,u=f||e&&d.find.TAG("*",k),v=w+=null==t?1:Math.random()||.1,x=u.length;for(k&&(j=g!==n&&g);q!==x&&null!=(l=u[q]);q++){if(e&&l){m=0;while(o=a[m++])if(o(l,g,h)){i.push(l);break}k&&(w=v)}c&&((l=!o&&l)&&p--,f&&r.push(l))}if(p+=q,c&&q!==p){m=0;while(o=b[m++])o(r,s,g,h);if(f){if(p>0)while(q--)r[q]||s[q]||(s[q]=G.call(i));s=ub(s)}I.apply(i,s),k&&!f&&s.length>0&&p+b.length>1&&fb.uniqueSort(i)}return k&&(w=v,j=t),r};return c?hb(f):f}return h=fb.compile=function(a,b){var c,d=[],e=[],f=A[a+" "];if(!f){b||(b=g(a)),c=b.length;while(c--)f=wb(b[c]),f[u]?d.push(f):e.push(f);f=A(a,xb(e,d)),f.selector=a}return f},i=fb.select=function(a,b,e,f){var i,j,k,l,m,n="function"==typeof a&&a,o=!f&&g(a=n.selector||a);if(e=e||[],1===o.length){if(j=o[0]=o[0].slice(0),j.length>2&&"ID"===(k=j[0]).type&&c.getById&&9===b.nodeType&&p&&d.relative[j[1].type]){if(b=(d.find.ID(k.matches[0].replace(cb,db),b)||[])[0],!b)return e;n&&(b=b.parentNode),a=a.slice(j.shift().value.length)}i=X.needsContext.test(a)?0:j.length;while(i--){if(k=j[i],d.relative[l=k.type])break;if((m=d.find[l])&&(f=m(k.matches[0].replace(cb,db),ab.test(j[0].type)&&ob(b.parentNode)||b))){if(j.splice(i,1),a=f.length&&qb(j),!a)return I.apply(e,f),e;break}}}return(n||h(a,o))(f,b,!p,e,ab.test(a)&&ob(b.parentNode)||b),e},c.sortStable=u.split("").sort(B).join("")===u,c.detectDuplicates=!!l,m(),c.sortDetached=ib(function(a){return 1&a.compareDocumentPosition(n.createElement("div"))}),ib(function(a){return a.innerHTML="<a href='#'></a>","#"===a.firstChild.getAttribute("href")})||jb("type|href|height|width",function(a,b,c){return c?void 0:a.getAttribute(b,"type"===b.toLowerCase()?1:2)}),c.attributes&&ib(function(a){return a.innerHTML="<input/>",a.firstChild.setAttribute("value",""),""===a.firstChild.getAttribute("value")})||jb("value",function(a,b,c){return c||"input"!==a.nodeName.toLowerCase()?void 0:a.defaultValue}),ib(function(a){return null==a.getAttribute("disabled")})||jb(L,function(a,b,c){var d;return c?void 0:a[b]===!0?b.toLowerCase():(d=a.getAttributeNode(b))&&d.specified?d.value:null}),fb}(a);n.find=t,n.expr=t.selectors,n.expr[":"]=n.expr.pseudos,n.unique=t.uniqueSort,n.text=t.getText,n.isXMLDoc=t.isXML,n.contains=t.contains;var u=n.expr.match.needsContext,v=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,w=/^.[^:#\[\.,]*$/;function x(a,b,c){if(n.isFunction(b))return n.grep(a,function(a,d){return!!b.call(a,d,a)!==c});if(b.nodeType)return n.grep(a,function(a){return a===b!==c});if("string"==typeof b){if(w.test(b))return n.filter(b,a,c);b=n.filter(b,a)}return n.grep(a,function(a){return g.call(b,a)>=0!==c})}n.filter=function(a,b,c){var d=b[0];return c&&(a=":not("+a+")"),1===b.length&&1===d.nodeType?n.find.matchesSelector(d,a)?[d]:[]:n.find.matches(a,n.grep(b,function(a){return 1===a.nodeType}))},n.fn.extend({find:function(a){var b,c=this.length,d=[],e=this;if("string"!=typeof a)return this.pushStack(n(a).filter(function(){for(b=0;c>b;b++)if(n.contains(e[b],this))return!0}));for(b=0;c>b;b++)n.find(a,e[b],d);return d=this.pushStack(c>1?n.unique(d):d),d.selector=this.selector?this.selector+" "+a:a,d},filter:function(a){return this.pushStack(x(this,a||[],!1))},not:function(a){return this.pushStack(x(this,a||[],!0))},is:function(a){return!!x(this,"string"==typeof a&&u.test(a)?n(a):a||[],!1).length}});var y,z=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,A=n.fn.init=function(a,b){var c,d;if(!a)return this;if("string"==typeof a){if(c="<"===a[0]&&">"===a[a.length-1]&&a.length>=3?[null,a,null]:z.exec(a),!c||!c[1]&&b)return!b||b.jquery?(b||y).find(a):this.constructor(b).find(a);if(c[1]){if(b=b instanceof n?b[0]:b,n.merge(this,n.parseHTML(c[1],b&&b.nodeType?b.ownerDocument||b:l,!0)),v.test(c[1])&&n.isPlainObject(b))for(c in b)n.isFunction(this[c])?this[c](b[c]):this.attr(c,b[c]);return this}return d=l.getElementById(c[2]),d&&d.parentNode&&(this.length=1,this[0]=d),this.context=l,this.selector=a,this}return a.nodeType?(this.context=this[0]=a,this.length=1,this):n.isFunction(a)?"undefined"!=typeof y.ready?y.ready(a):a(n):(void 0!==a.selector&&(this.selector=a.selector,this.context=a.context),n.makeArray(a,this))};A.prototype=n.fn,y=n(l);var B=/^(?:parents|prev(?:Until|All))/,C={children:!0,contents:!0,next:!0,prev:!0};n.extend({dir:function(a,b,c){var d=[],e=void 0!==c;while((a=a[b])&&9!==a.nodeType)if(1===a.nodeType){if(e&&n(a).is(c))break;d.push(a)}return d},sibling:function(a,b){for(var c=[];a;a=a.nextSibling)1===a.nodeType&&a!==b&&c.push(a);return c}}),n.fn.extend({has:function(a){var b=n(a,this),c=b.length;return this.filter(function(){for(var a=0;c>a;a++)if(n.contains(this,b[a]))return!0})},closest:function(a,b){for(var c,d=0,e=this.length,f=[],g=u.test(a)||"string"!=typeof a?n(a,b||this.context):0;e>d;d++)for(c=this[d];c&&c!==b;c=c.parentNode)if(c.nodeType<11&&(g?g.index(c)>-1:1===c.nodeType&&n.find.matchesSelector(c,a))){f.push(c);break}return this.pushStack(f.length>1?n.unique(f):f)},index:function(a){return a?"string"==typeof a?g.call(n(a),this[0]):g.call(this,a.jquery?a[0]:a):this[0]&&this[0].parentNode?this.first().prevAll().length:-1},add:function(a,b){return this.pushStack(n.unique(n.merge(this.get(),n(a,b))))},addBack:function(a){return this.add(null==a?this.prevObject:this.prevObject.filter(a))}});function D(a,b){while((a=a[b])&&1!==a.nodeType);return a}n.each({parent:function(a){var b=a.parentNode;return b&&11!==b.nodeType?b:null},parents:function(a){return n.dir(a,"parentNode")},parentsUntil:function(a,b,c){return n.dir(a,"parentNode",c)},next:function(a){return D(a,"nextSibling")},prev:function(a){return D(a,"previousSibling")},nextAll:function(a){return n.dir(a,"nextSibling")},prevAll:function(a){return n.dir(a,"previousSibling")},nextUntil:function(a,b,c){return n.dir(a,"nextSibling",c)},prevUntil:function(a,b,c){return n.dir(a,"previousSibling",c)},siblings:function(a){return n.sibling((a.parentNode||{}).firstChild,a)},children:function(a){return n.sibling(a.firstChild)},contents:function(a){return a.contentDocument||n.merge([],a.childNodes)}},function(a,b){n.fn[a]=function(c,d){var e=n.map(this,b,c);return"Until"!==a.slice(-5)&&(d=c),d&&"string"==typeof d&&(e=n.filter(d,e)),this.length>1&&(C[a]||n.unique(e),B.test(a)&&e.reverse()),this.pushStack(e)}});var E=/\S+/g,F={};function G(a){var b=F[a]={};return n.each(a.match(E)||[],function(a,c){b[c]=!0}),b}n.Callbacks=function(a){a="string"==typeof a?F[a]||G(a):n.extend({},a);var b,c,d,e,f,g,h=[],i=!a.once&&[],j=function(l){for(b=a.memory&&l,c=!0,g=e||0,e=0,f=h.length,d=!0;h&&f>g;g++)if(h[g].apply(l[0],l[1])===!1&&a.stopOnFalse){b=!1;break}d=!1,h&&(i?i.length&&j(i.shift()):b?h=[]:k.disable())},k={add:function(){if(h){var c=h.length;!function g(b){n.each(b,function(b,c){var d=n.type(c);"function"===d?a.unique&&k.has(c)||h.push(c):c&&c.length&&"string"!==d&&g(c)})}(arguments),d?f=h.length:b&&(e=c,j(b))}return this},remove:function(){return h&&n.each(arguments,function(a,b){var c;while((c=n.inArray(b,h,c))>-1)h.splice(c,1),d&&(f>=c&&f--,g>=c&&g--)}),this},has:function(a){return a?n.inArray(a,h)>-1:!(!h||!h.length)},empty:function(){return h=[],f=0,this},disable:function(){return h=i=b=void 0,this},disabled:function(){return!h},lock:function(){return i=void 0,b||k.disable(),this},locked:function(){return!i},fireWith:function(a,b){return!h||c&&!i||(b=b||[],b=[a,b.slice?b.slice():b],d?i.push(b):j(b)),this},fire:function(){return k.fireWith(this,arguments),this},fired:function(){return!!c}};return k},n.extend({Deferred:function(a){var b=[["resolve","done",n.Callbacks("once memory"),"resolved"],["reject","fail",n.Callbacks("once memory"),"rejected"],["notify","progress",n.Callbacks("memory")]],c="pending",d={state:function(){return c},always:function(){return e.done(arguments).fail(arguments),this},then:function(){var a=arguments;return n.Deferred(function(c){n.each(b,function(b,f){var g=n.isFunction(a[b])&&a[b];e[f[1]](function(){var a=g&&g.apply(this,arguments);a&&n.isFunction(a.promise)?a.promise().done(c.resolve).fail(c.reject).progress(c.notify):c[f[0]+"With"](this===d?c.promise():this,g?[a]:arguments)})}),a=null}).promise()},promise:function(a){return null!=a?n.extend(a,d):d}},e={};return d.pipe=d.then,n.each(b,function(a,f){var g=f[2],h=f[3];d[f[1]]=g.add,h&&g.add(function(){c=h},b[1^a][2].disable,b[2][2].lock),e[f[0]]=function(){return e[f[0]+"With"](this===e?d:this,arguments),this},e[f[0]+"With"]=g.fireWith}),d.promise(e),a&&a.call(e,e),e},when:function(a){var b=0,c=d.call(arguments),e=c.length,f=1!==e||a&&n.isFunction(a.promise)?e:0,g=1===f?a:n.Deferred(),h=function(a,b,c){return function(e){b[a]=this,c[a]=arguments.length>1?d.call(arguments):e,c===i?g.notifyWith(b,c):--f||g.resolveWith(b,c)}},i,j,k;if(e>1)for(i=new Array(e),j=new Array(e),k=new Array(e);e>b;b++)c[b]&&n.isFunction(c[b].promise)?c[b].promise().done(h(b,k,c)).fail(g.reject).progress(h(b,j,i)):--f;return f||g.resolveWith(k,c),g.promise()}});var H;n.fn.ready=function(a){return n.ready.promise().done(a),this},n.extend({isReady:!1,readyWait:1,holdReady:function(a){a?n.readyWait++:n.ready(!0)},ready:function(a){(a===!0?--n.readyWait:n.isReady)||(n.isReady=!0,a!==!0&&--n.readyWait>0||(H.resolveWith(l,[n]),n.fn.triggerHandler&&(n(l).triggerHandler("ready"),n(l).off("ready"))))}});function I(){l.removeEventListener("DOMContentLoaded",I,!1),a.removeEventListener("load",I,!1),n.ready()}n.ready.promise=function(b){return H||(H=n.Deferred(),"complete"===l.readyState?setTimeout(n.ready):(l.addEventListener("DOMContentLoaded",I,!1),a.addEventListener("load",I,!1))),H.promise(b)},n.ready.promise();var J=n.access=function(a,b,c,d,e,f,g){var h=0,i=a.length,j=null==c;if("object"===n.type(c)){e=!0;for(h in c)n.access(a,b,h,c[h],!0,f,g)}else if(void 0!==d&&(e=!0,n.isFunction(d)||(g=!0),j&&(g?(b.call(a,d),b=null):(j=b,b=function(a,b,c){return j.call(n(a),c)})),b))for(;i>h;h++)b(a[h],c,g?d:d.call(a[h],h,b(a[h],c)));return e?a:j?b.call(a):i?b(a[0],c):f};n.acceptData=function(a){return 1===a.nodeType||9===a.nodeType||!+a.nodeType};function K(){Object.defineProperty(this.cache={},0,{get:function(){return{}}}),this.expando=n.expando+Math.random()}K.uid=1,K.accepts=n.acceptData,K.prototype={key:function(a){if(!K.accepts(a))return 0;var b={},c=a[this.expando];if(!c){c=K.uid++;try{b[this.expando]={value:c},Object.defineProperties(a,b)}catch(d){b[this.expando]=c,n.extend(a,b)}}return this.cache[c]||(this.cache[c]={}),c},set:function(a,b,c){var d,e=this.key(a),f=this.cache[e];if("string"==typeof b)f[b]=c;else if(n.isEmptyObject(f))n.extend(this.cache[e],b);else for(d in b)f[d]=b[d];return f},get:function(a,b){var c=this.cache[this.key(a)];return void 0===b?c:c[b]},access:function(a,b,c){var d;return void 0===b||b&&"string"==typeof b&&void 0===c?(d=this.get(a,b),void 0!==d?d:this.get(a,n.camelCase(b))):(this.set(a,b,c),void 0!==c?c:b)},remove:function(a,b){var c,d,e,f=this.key(a),g=this.cache[f];if(void 0===b)this.cache[f]={};else{n.isArray(b)?d=b.concat(b.map(n.camelCase)):(e=n.camelCase(b),b in g?d=[b,e]:(d=e,d=d in g?[d]:d.match(E)||[])),c=d.length;while(c--)delete g[d[c]]}},hasData:function(a){return!n.isEmptyObject(this.cache[a[this.expando]]||{})},discard:function(a){a[this.expando]&&delete this.cache[a[this.expando]]}};var L=new K,M=new K,N=/^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,O=/([A-Z])/g;function P(a,b,c){var d;if(void 0===c&&1===a.nodeType)if(d="data-"+b.replace(O,"-$1").toLowerCase(),c=a.getAttribute(d),"string"==typeof c){try{c="true"===c?!0:"false"===c?!1:"null"===c?null:+c+""===c?+c:N.test(c)?n.parseJSON(c):c}catch(e){}M.set(a,b,c)}else c=void 0;return c}n.extend({hasData:function(a){return M.hasData(a)||L.hasData(a)},data:function(a,b,c){return M.access(a,b,c)},removeData:function(a,b){M.remove(a,b)
/* 3 */ },_data:function(a,b,c){return L.access(a,b,c)},_removeData:function(a,b){L.remove(a,b)}}),n.fn.extend({data:function(a,b){var c,d,e,f=this[0],g=f&&f.attributes;if(void 0===a){if(this.length&&(e=M.get(f),1===f.nodeType&&!L.get(f,"hasDataAttrs"))){c=g.length;while(c--)g[c]&&(d=g[c].name,0===d.indexOf("data-")&&(d=n.camelCase(d.slice(5)),P(f,d,e[d])));L.set(f,"hasDataAttrs",!0)}return e}return"object"==typeof a?this.each(function(){M.set(this,a)}):J(this,function(b){var c,d=n.camelCase(a);if(f&&void 0===b){if(c=M.get(f,a),void 0!==c)return c;if(c=M.get(f,d),void 0!==c)return c;if(c=P(f,d,void 0),void 0!==c)return c}else this.each(function(){var c=M.get(this,d);M.set(this,d,b),-1!==a.indexOf("-")&&void 0!==c&&M.set(this,a,b)})},null,b,arguments.length>1,null,!0)},removeData:function(a){return this.each(function(){M.remove(this,a)})}}),n.extend({queue:function(a,b,c){var d;return a?(b=(b||"fx")+"queue",d=L.get(a,b),c&&(!d||n.isArray(c)?d=L.access(a,b,n.makeArray(c)):d.push(c)),d||[]):void 0},dequeue:function(a,b){b=b||"fx";var c=n.queue(a,b),d=c.length,e=c.shift(),f=n._queueHooks(a,b),g=function(){n.dequeue(a,b)};"inprogress"===e&&(e=c.shift(),d--),e&&("fx"===b&&c.unshift("inprogress"),delete f.stop,e.call(a,g,f)),!d&&f&&f.empty.fire()},_queueHooks:function(a,b){var c=b+"queueHooks";return L.get(a,c)||L.access(a,c,{empty:n.Callbacks("once memory").add(function(){L.remove(a,[b+"queue",c])})})}}),n.fn.extend({queue:function(a,b){var c=2;return"string"!=typeof a&&(b=a,a="fx",c--),arguments.length<c?n.queue(this[0],a):void 0===b?this:this.each(function(){var c=n.queue(this,a,b);n._queueHooks(this,a),"fx"===a&&"inprogress"!==c[0]&&n.dequeue(this,a)})},dequeue:function(a){return this.each(function(){n.dequeue(this,a)})},clearQueue:function(a){return this.queue(a||"fx",[])},promise:function(a,b){var c,d=1,e=n.Deferred(),f=this,g=this.length,h=function(){--d||e.resolveWith(f,[f])};"string"!=typeof a&&(b=a,a=void 0),a=a||"fx";while(g--)c=L.get(f[g],a+"queueHooks"),c&&c.empty&&(d++,c.empty.add(h));return h(),e.promise(b)}});var Q=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,R=["Top","Right","Bottom","Left"],S=function(a,b){return a=b||a,"none"===n.css(a,"display")||!n.contains(a.ownerDocument,a)},T=/^(?:checkbox|radio)$/i;!function(){var a=l.createDocumentFragment(),b=a.appendChild(l.createElement("div")),c=l.createElement("input");c.setAttribute("type","radio"),c.setAttribute("checked","checked"),c.setAttribute("name","t"),b.appendChild(c),k.checkClone=b.cloneNode(!0).cloneNode(!0).lastChild.checked,b.innerHTML="<textarea>x</textarea>",k.noCloneChecked=!!b.cloneNode(!0).lastChild.defaultValue}();var U="undefined";k.focusinBubbles="onfocusin"in a;var V=/^key/,W=/^(?:mouse|pointer|contextmenu)|click/,X=/^(?:focusinfocus|focusoutblur)$/,Y=/^([^.]*)(?:\.(.+)|)$/;function Z(){return!0}function $(){return!1}function _(){try{return l.activeElement}catch(a){}}n.event={global:{},add:function(a,b,c,d,e){var f,g,h,i,j,k,l,m,o,p,q,r=L.get(a);if(r){c.handler&&(f=c,c=f.handler,e=f.selector),c.guid||(c.guid=n.guid++),(i=r.events)||(i=r.events={}),(g=r.handle)||(g=r.handle=function(b){return typeof n!==U&&n.event.triggered!==b.type?n.event.dispatch.apply(a,arguments):void 0}),b=(b||"").match(E)||[""],j=b.length;while(j--)h=Y.exec(b[j])||[],o=q=h[1],p=(h[2]||"").split(".").sort(),o&&(l=n.event.special[o]||{},o=(e?l.delegateType:l.bindType)||o,l=n.event.special[o]||{},k=n.extend({type:o,origType:q,data:d,handler:c,guid:c.guid,selector:e,needsContext:e&&n.expr.match.needsContext.test(e),namespace:p.join(".")},f),(m=i[o])||(m=i[o]=[],m.delegateCount=0,l.setup&&l.setup.call(a,d,p,g)!==!1||a.addEventListener&&a.addEventListener(o,g,!1)),l.add&&(l.add.call(a,k),k.handler.guid||(k.handler.guid=c.guid)),e?m.splice(m.delegateCount++,0,k):m.push(k),n.event.global[o]=!0)}},remove:function(a,b,c,d,e){var f,g,h,i,j,k,l,m,o,p,q,r=L.hasData(a)&&L.get(a);if(r&&(i=r.events)){b=(b||"").match(E)||[""],j=b.length;while(j--)if(h=Y.exec(b[j])||[],o=q=h[1],p=(h[2]||"").split(".").sort(),o){l=n.event.special[o]||{},o=(d?l.delegateType:l.bindType)||o,m=i[o]||[],h=h[2]&&new RegExp("(^|\\.)"+p.join("\\.(?:.*\\.|)")+"(\\.|$)"),g=f=m.length;while(f--)k=m[f],!e&&q!==k.origType||c&&c.guid!==k.guid||h&&!h.test(k.namespace)||d&&d!==k.selector&&("**"!==d||!k.selector)||(m.splice(f,1),k.selector&&m.delegateCount--,l.remove&&l.remove.call(a,k));g&&!m.length&&(l.teardown&&l.teardown.call(a,p,r.handle)!==!1||n.removeEvent(a,o,r.handle),delete i[o])}else for(o in i)n.event.remove(a,o+b[j],c,d,!0);n.isEmptyObject(i)&&(delete r.handle,L.remove(a,"events"))}},trigger:function(b,c,d,e){var f,g,h,i,k,m,o,p=[d||l],q=j.call(b,"type")?b.type:b,r=j.call(b,"namespace")?b.namespace.split("."):[];if(g=h=d=d||l,3!==d.nodeType&&8!==d.nodeType&&!X.test(q+n.event.triggered)&&(q.indexOf(".")>=0&&(r=q.split("."),q=r.shift(),r.sort()),k=q.indexOf(":")<0&&"on"+q,b=b[n.expando]?b:new n.Event(q,"object"==typeof b&&b),b.isTrigger=e?2:3,b.namespace=r.join("."),b.namespace_re=b.namespace?new RegExp("(^|\\.)"+r.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,b.result=void 0,b.target||(b.target=d),c=null==c?[b]:n.makeArray(c,[b]),o=n.event.special[q]||{},e||!o.trigger||o.trigger.apply(d,c)!==!1)){if(!e&&!o.noBubble&&!n.isWindow(d)){for(i=o.delegateType||q,X.test(i+q)||(g=g.parentNode);g;g=g.parentNode)p.push(g),h=g;h===(d.ownerDocument||l)&&p.push(h.defaultView||h.parentWindow||a)}f=0;while((g=p[f++])&&!b.isPropagationStopped())b.type=f>1?i:o.bindType||q,m=(L.get(g,"events")||{})[b.type]&&L.get(g,"handle"),m&&m.apply(g,c),m=k&&g[k],m&&m.apply&&n.acceptData(g)&&(b.result=m.apply(g,c),b.result===!1&&b.preventDefault());return b.type=q,e||b.isDefaultPrevented()||o._default&&o._default.apply(p.pop(),c)!==!1||!n.acceptData(d)||k&&n.isFunction(d[q])&&!n.isWindow(d)&&(h=d[k],h&&(d[k]=null),n.event.triggered=q,d[q](),n.event.triggered=void 0,h&&(d[k]=h)),b.result}},dispatch:function(a){a=n.event.fix(a);var b,c,e,f,g,h=[],i=d.call(arguments),j=(L.get(this,"events")||{})[a.type]||[],k=n.event.special[a.type]||{};if(i[0]=a,a.delegateTarget=this,!k.preDispatch||k.preDispatch.call(this,a)!==!1){h=n.event.handlers.call(this,a,j),b=0;while((f=h[b++])&&!a.isPropagationStopped()){a.currentTarget=f.elem,c=0;while((g=f.handlers[c++])&&!a.isImmediatePropagationStopped())(!a.namespace_re||a.namespace_re.test(g.namespace))&&(a.handleObj=g,a.data=g.data,e=((n.event.special[g.origType]||{}).handle||g.handler).apply(f.elem,i),void 0!==e&&(a.result=e)===!1&&(a.preventDefault(),a.stopPropagation()))}return k.postDispatch&&k.postDispatch.call(this,a),a.result}},handlers:function(a,b){var c,d,e,f,g=[],h=b.delegateCount,i=a.target;if(h&&i.nodeType&&(!a.button||"click"!==a.type))for(;i!==this;i=i.parentNode||this)if(i.disabled!==!0||"click"!==a.type){for(d=[],c=0;h>c;c++)f=b[c],e=f.selector+" ",void 0===d[e]&&(d[e]=f.needsContext?n(e,this).index(i)>=0:n.find(e,this,null,[i]).length),d[e]&&d.push(f);d.length&&g.push({elem:i,handlers:d})}return h<b.length&&g.push({elem:this,handlers:b.slice(h)}),g},props:"altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){return null==a.which&&(a.which=null!=b.charCode?b.charCode:b.keyCode),a}},mouseHooks:{props:"button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,b){var c,d,e,f=b.button;return null==a.pageX&&null!=b.clientX&&(c=a.target.ownerDocument||l,d=c.documentElement,e=c.body,a.pageX=b.clientX+(d&&d.scrollLeft||e&&e.scrollLeft||0)-(d&&d.clientLeft||e&&e.clientLeft||0),a.pageY=b.clientY+(d&&d.scrollTop||e&&e.scrollTop||0)-(d&&d.clientTop||e&&e.clientTop||0)),a.which||void 0===f||(a.which=1&f?1:2&f?3:4&f?2:0),a}},fix:function(a){if(a[n.expando])return a;var b,c,d,e=a.type,f=a,g=this.fixHooks[e];g||(this.fixHooks[e]=g=W.test(e)?this.mouseHooks:V.test(e)?this.keyHooks:{}),d=g.props?this.props.concat(g.props):this.props,a=new n.Event(f),b=d.length;while(b--)c=d[b],a[c]=f[c];return a.target||(a.target=l),3===a.target.nodeType&&(a.target=a.target.parentNode),g.filter?g.filter(a,f):a},special:{load:{noBubble:!0},focus:{trigger:function(){return this!==_()&&this.focus?(this.focus(),!1):void 0},delegateType:"focusin"},blur:{trigger:function(){return this===_()&&this.blur?(this.blur(),!1):void 0},delegateType:"focusout"},click:{trigger:function(){return"checkbox"===this.type&&this.click&&n.nodeName(this,"input")?(this.click(),!1):void 0},_default:function(a){return n.nodeName(a.target,"a")}},beforeunload:{postDispatch:function(a){void 0!==a.result&&a.originalEvent&&(a.originalEvent.returnValue=a.result)}}},simulate:function(a,b,c,d){var e=n.extend(new n.Event,c,{type:a,isSimulated:!0,originalEvent:{}});d?n.event.trigger(e,null,b):n.event.dispatch.call(b,e),e.isDefaultPrevented()&&c.preventDefault()}},n.removeEvent=function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c,!1)},n.Event=function(a,b){return this instanceof n.Event?(a&&a.type?(this.originalEvent=a,this.type=a.type,this.isDefaultPrevented=a.defaultPrevented||void 0===a.defaultPrevented&&a.returnValue===!1?Z:$):this.type=a,b&&n.extend(this,b),this.timeStamp=a&&a.timeStamp||n.now(),void(this[n.expando]=!0)):new n.Event(a,b)},n.Event.prototype={isDefaultPrevented:$,isPropagationStopped:$,isImmediatePropagationStopped:$,preventDefault:function(){var a=this.originalEvent;this.isDefaultPrevented=Z,a&&a.preventDefault&&a.preventDefault()},stopPropagation:function(){var a=this.originalEvent;this.isPropagationStopped=Z,a&&a.stopPropagation&&a.stopPropagation()},stopImmediatePropagation:function(){var a=this.originalEvent;this.isImmediatePropagationStopped=Z,a&&a.stopImmediatePropagation&&a.stopImmediatePropagation(),this.stopPropagation()}},n.each({mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"},function(a,b){n.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c,d=this,e=a.relatedTarget,f=a.handleObj;return(!e||e!==d&&!n.contains(d,e))&&(a.type=f.origType,c=f.handler.apply(this,arguments),a.type=b),c}}}),k.focusinBubbles||n.each({focus:"focusin",blur:"focusout"},function(a,b){var c=function(a){n.event.simulate(b,a.target,n.event.fix(a),!0)};n.event.special[b]={setup:function(){var d=this.ownerDocument||this,e=L.access(d,b);e||d.addEventListener(a,c,!0),L.access(d,b,(e||0)+1)},teardown:function(){var d=this.ownerDocument||this,e=L.access(d,b)-1;e?L.access(d,b,e):(d.removeEventListener(a,c,!0),L.remove(d,b))}}}),n.fn.extend({on:function(a,b,c,d,e){var f,g;if("object"==typeof a){"string"!=typeof b&&(c=c||b,b=void 0);for(g in a)this.on(g,b,c,a[g],e);return this}if(null==c&&null==d?(d=b,c=b=void 0):null==d&&("string"==typeof b?(d=c,c=void 0):(d=c,c=b,b=void 0)),d===!1)d=$;else if(!d)return this;return 1===e&&(f=d,d=function(a){return n().off(a),f.apply(this,arguments)},d.guid=f.guid||(f.guid=n.guid++)),this.each(function(){n.event.add(this,a,d,c,b)})},one:function(a,b,c,d){return this.on(a,b,c,d,1)},off:function(a,b,c){var d,e;if(a&&a.preventDefault&&a.handleObj)return d=a.handleObj,n(a.delegateTarget).off(d.namespace?d.origType+"."+d.namespace:d.origType,d.selector,d.handler),this;if("object"==typeof a){for(e in a)this.off(e,b,a[e]);return this}return(b===!1||"function"==typeof b)&&(c=b,b=void 0),c===!1&&(c=$),this.each(function(){n.event.remove(this,a,c,b)})},trigger:function(a,b){return this.each(function(){n.event.trigger(a,b,this)})},triggerHandler:function(a,b){var c=this[0];return c?n.event.trigger(a,b,c,!0):void 0}});var ab=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,bb=/<([\w:]+)/,cb=/<|&#?\w+;/,db=/<(?:script|style|link)/i,eb=/checked\s*(?:[^=]|=\s*.checked.)/i,fb=/^$|\/(?:java|ecma)script/i,gb=/^true\/(.*)/,hb=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,ib={option:[1,"<select multiple='multiple'>","</select>"],thead:[1,"<table>","</table>"],col:[2,"<table><colgroup>","</colgroup></table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:[0,"",""]};ib.optgroup=ib.option,ib.tbody=ib.tfoot=ib.colgroup=ib.caption=ib.thead,ib.th=ib.td;function jb(a,b){return n.nodeName(a,"table")&&n.nodeName(11!==b.nodeType?b:b.firstChild,"tr")?a.getElementsByTagName("tbody")[0]||a.appendChild(a.ownerDocument.createElement("tbody")):a}function kb(a){return a.type=(null!==a.getAttribute("type"))+"/"+a.type,a}function lb(a){var b=gb.exec(a.type);return b?a.type=b[1]:a.removeAttribute("type"),a}function mb(a,b){for(var c=0,d=a.length;d>c;c++)L.set(a[c],"globalEval",!b||L.get(b[c],"globalEval"))}function nb(a,b){var c,d,e,f,g,h,i,j;if(1===b.nodeType){if(L.hasData(a)&&(f=L.access(a),g=L.set(b,f),j=f.events)){delete g.handle,g.events={};for(e in j)for(c=0,d=j[e].length;d>c;c++)n.event.add(b,e,j[e][c])}M.hasData(a)&&(h=M.access(a),i=n.extend({},h),M.set(b,i))}}function ob(a,b){var c=a.getElementsByTagName?a.getElementsByTagName(b||"*"):a.querySelectorAll?a.querySelectorAll(b||"*"):[];return void 0===b||b&&n.nodeName(a,b)?n.merge([a],c):c}function pb(a,b){var c=b.nodeName.toLowerCase();"input"===c&&T.test(a.type)?b.checked=a.checked:("input"===c||"textarea"===c)&&(b.defaultValue=a.defaultValue)}n.extend({clone:function(a,b,c){var d,e,f,g,h=a.cloneNode(!0),i=n.contains(a.ownerDocument,a);if(!(k.noCloneChecked||1!==a.nodeType&&11!==a.nodeType||n.isXMLDoc(a)))for(g=ob(h),f=ob(a),d=0,e=f.length;e>d;d++)pb(f[d],g[d]);if(b)if(c)for(f=f||ob(a),g=g||ob(h),d=0,e=f.length;e>d;d++)nb(f[d],g[d]);else nb(a,h);return g=ob(h,"script"),g.length>0&&mb(g,!i&&ob(a,"script")),h},buildFragment:function(a,b,c,d){for(var e,f,g,h,i,j,k=b.createDocumentFragment(),l=[],m=0,o=a.length;o>m;m++)if(e=a[m],e||0===e)if("object"===n.type(e))n.merge(l,e.nodeType?[e]:e);else if(cb.test(e)){f=f||k.appendChild(b.createElement("div")),g=(bb.exec(e)||["",""])[1].toLowerCase(),h=ib[g]||ib._default,f.innerHTML=h[1]+e.replace(ab,"<$1></$2>")+h[2],j=h[0];while(j--)f=f.lastChild;n.merge(l,f.childNodes),f=k.firstChild,f.textContent=""}else l.push(b.createTextNode(e));k.textContent="",m=0;while(e=l[m++])if((!d||-1===n.inArray(e,d))&&(i=n.contains(e.ownerDocument,e),f=ob(k.appendChild(e),"script"),i&&mb(f),c)){j=0;while(e=f[j++])fb.test(e.type||"")&&c.push(e)}return k},cleanData:function(a){for(var b,c,d,e,f=n.event.special,g=0;void 0!==(c=a[g]);g++){if(n.acceptData(c)&&(e=c[L.expando],e&&(b=L.cache[e]))){if(b.events)for(d in b.events)f[d]?n.event.remove(c,d):n.removeEvent(c,d,b.handle);L.cache[e]&&delete L.cache[e]}delete M.cache[c[M.expando]]}}}),n.fn.extend({text:function(a){return J(this,function(a){return void 0===a?n.text(this):this.empty().each(function(){(1===this.nodeType||11===this.nodeType||9===this.nodeType)&&(this.textContent=a)})},null,a,arguments.length)},append:function(){return this.domManip(arguments,function(a){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var b=jb(this,a);b.appendChild(a)}})},prepend:function(){return this.domManip(arguments,function(a){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var b=jb(this,a);b.insertBefore(a,b.firstChild)}})},before:function(){return this.domManip(arguments,function(a){this.parentNode&&this.parentNode.insertBefore(a,this)})},after:function(){return this.domManip(arguments,function(a){this.parentNode&&this.parentNode.insertBefore(a,this.nextSibling)})},remove:function(a,b){for(var c,d=a?n.filter(a,this):this,e=0;null!=(c=d[e]);e++)b||1!==c.nodeType||n.cleanData(ob(c)),c.parentNode&&(b&&n.contains(c.ownerDocument,c)&&mb(ob(c,"script")),c.parentNode.removeChild(c));return this},empty:function(){for(var a,b=0;null!=(a=this[b]);b++)1===a.nodeType&&(n.cleanData(ob(a,!1)),a.textContent="");return this},clone:function(a,b){return a=null==a?!1:a,b=null==b?a:b,this.map(function(){return n.clone(this,a,b)})},html:function(a){return J(this,function(a){var b=this[0]||{},c=0,d=this.length;if(void 0===a&&1===b.nodeType)return b.innerHTML;if("string"==typeof a&&!db.test(a)&&!ib[(bb.exec(a)||["",""])[1].toLowerCase()]){a=a.replace(ab,"<$1></$2>");try{for(;d>c;c++)b=this[c]||{},1===b.nodeType&&(n.cleanData(ob(b,!1)),b.innerHTML=a);b=0}catch(e){}}b&&this.empty().append(a)},null,a,arguments.length)},replaceWith:function(){var a=arguments[0];return this.domManip(arguments,function(b){a=this.parentNode,n.cleanData(ob(this)),a&&a.replaceChild(b,this)}),a&&(a.length||a.nodeType)?this:this.remove()},detach:function(a){return this.remove(a,!0)},domManip:function(a,b){a=e.apply([],a);var c,d,f,g,h,i,j=0,l=this.length,m=this,o=l-1,p=a[0],q=n.isFunction(p);if(q||l>1&&"string"==typeof p&&!k.checkClone&&eb.test(p))return this.each(function(c){var d=m.eq(c);q&&(a[0]=p.call(this,c,d.html())),d.domManip(a,b)});if(l&&(c=n.buildFragment(a,this[0].ownerDocument,!1,this),d=c.firstChild,1===c.childNodes.length&&(c=d),d)){for(f=n.map(ob(c,"script"),kb),g=f.length;l>j;j++)h=c,j!==o&&(h=n.clone(h,!0,!0),g&&n.merge(f,ob(h,"script"))),b.call(this[j],h,j);if(g)for(i=f[f.length-1].ownerDocument,n.map(f,lb),j=0;g>j;j++)h=f[j],fb.test(h.type||"")&&!L.access(h,"globalEval")&&n.contains(i,h)&&(h.src?n._evalUrl&&n._evalUrl(h.src):n.globalEval(h.textContent.replace(hb,"")))}return this}}),n.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){n.fn[a]=function(a){for(var c,d=[],e=n(a),g=e.length-1,h=0;g>=h;h++)c=h===g?this:this.clone(!0),n(e[h])[b](c),f.apply(d,c.get());return this.pushStack(d)}});var qb,rb={};function sb(b,c){var d,e=n(c.createElement(b)).appendTo(c.body),f=a.getDefaultComputedStyle&&(d=a.getDefaultComputedStyle(e[0]))?d.display:n.css(e[0],"display");return e.detach(),f}function tb(a){var b=l,c=rb[a];return c||(c=sb(a,b),"none"!==c&&c||(qb=(qb||n("<iframe frameborder='0' width='0' height='0'/>")).appendTo(b.documentElement),b=qb[0].contentDocument,b.write(),b.close(),c=sb(a,b),qb.detach()),rb[a]=c),c}var ub=/^margin/,vb=new RegExp("^("+Q+")(?!px)[a-z%]+$","i"),wb=function(a){return a.ownerDocument.defaultView.getComputedStyle(a,null)};function xb(a,b,c){var d,e,f,g,h=a.style;return c=c||wb(a),c&&(g=c.getPropertyValue(b)||c[b]),c&&(""!==g||n.contains(a.ownerDocument,a)||(g=n.style(a,b)),vb.test(g)&&ub.test(b)&&(d=h.width,e=h.minWidth,f=h.maxWidth,h.minWidth=h.maxWidth=h.width=g,g=c.width,h.width=d,h.minWidth=e,h.maxWidth=f)),void 0!==g?g+"":g}function yb(a,b){return{get:function(){return a()?void delete this.get:(this.get=b).apply(this,arguments)}}}!function(){var b,c,d=l.documentElement,e=l.createElement("div"),f=l.createElement("div");if(f.style){f.style.backgroundClip="content-box",f.cloneNode(!0).style.backgroundClip="",k.clearCloneStyle="content-box"===f.style.backgroundClip,e.style.cssText="border:0;width:0;height:0;top:0;left:-9999px;margin-top:1px;position:absolute",e.appendChild(f);function g(){f.style.cssText="-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute",f.innerHTML="",d.appendChild(e);var g=a.getComputedStyle(f,null);b="1%"!==g.top,c="4px"===g.width,d.removeChild(e)}a.getComputedStyle&&n.extend(k,{pixelPosition:function(){return g(),b},boxSizingReliable:function(){return null==c&&g(),c},reliableMarginRight:function(){var b,c=f.appendChild(l.createElement("div"));return c.style.cssText=f.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0",c.style.marginRight=c.style.width="0",f.style.width="1px",d.appendChild(e),b=!parseFloat(a.getComputedStyle(c,null).marginRight),d.removeChild(e),b}})}}(),n.swap=function(a,b,c,d){var e,f,g={};for(f in b)g[f]=a.style[f],a.style[f]=b[f];e=c.apply(a,d||[]);for(f in b)a.style[f]=g[f];return e};var zb=/^(none|table(?!-c[ea]).+)/,Ab=new RegExp("^("+Q+")(.*)$","i"),Bb=new RegExp("^([+-])=("+Q+")","i"),Cb={position:"absolute",visibility:"hidden",display:"block"},Db={letterSpacing:"0",fontWeight:"400"},Eb=["Webkit","O","Moz","ms"];function Fb(a,b){if(b in a)return b;var c=b[0].toUpperCase()+b.slice(1),d=b,e=Eb.length;while(e--)if(b=Eb[e]+c,b in a)return b;return d}function Gb(a,b,c){var d=Ab.exec(b);return d?Math.max(0,d[1]-(c||0))+(d[2]||"px"):b}function Hb(a,b,c,d,e){for(var f=c===(d?"border":"content")?4:"width"===b?1:0,g=0;4>f;f+=2)"margin"===c&&(g+=n.css(a,c+R[f],!0,e)),d?("content"===c&&(g-=n.css(a,"padding"+R[f],!0,e)),"margin"!==c&&(g-=n.css(a,"border"+R[f]+"Width",!0,e))):(g+=n.css(a,"padding"+R[f],!0,e),"padding"!==c&&(g+=n.css(a,"border"+R[f]+"Width",!0,e)));return g}function Ib(a,b,c){var d=!0,e="width"===b?a.offsetWidth:a.offsetHeight,f=wb(a),g="border-box"===n.css(a,"boxSizing",!1,f);if(0>=e||null==e){if(e=xb(a,b,f),(0>e||null==e)&&(e=a.style[b]),vb.test(e))return e;d=g&&(k.boxSizingReliable()||e===a.style[b]),e=parseFloat(e)||0}return e+Hb(a,b,c||(g?"border":"content"),d,f)+"px"}function Jb(a,b){for(var c,d,e,f=[],g=0,h=a.length;h>g;g++)d=a[g],d.style&&(f[g]=L.get(d,"olddisplay"),c=d.style.display,b?(f[g]||"none"!==c||(d.style.display=""),""===d.style.display&&S(d)&&(f[g]=L.access(d,"olddisplay",tb(d.nodeName)))):(e=S(d),"none"===c&&e||L.set(d,"olddisplay",e?c:n.css(d,"display"))));for(g=0;h>g;g++)d=a[g],d.style&&(b&&"none"!==d.style.display&&""!==d.style.display||(d.style.display=b?f[g]||"":"none"));return a}n.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=xb(a,"opacity");return""===c?"1":c}}}},cssNumber:{columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":"cssFloat"},style:function(a,b,c,d){if(a&&3!==a.nodeType&&8!==a.nodeType&&a.style){var e,f,g,h=n.camelCase(b),i=a.style;return b=n.cssProps[h]||(n.cssProps[h]=Fb(i,h)),g=n.cssHooks[b]||n.cssHooks[h],void 0===c?g&&"get"in g&&void 0!==(e=g.get(a,!1,d))?e:i[b]:(f=typeof c,"string"===f&&(e=Bb.exec(c))&&(c=(e[1]+1)*e[2]+parseFloat(n.css(a,b)),f="number"),null!=c&&c===c&&("number"!==f||n.cssNumber[h]||(c+="px"),k.clearCloneStyle||""!==c||0!==b.indexOf("background")||(i[b]="inherit"),g&&"set"in g&&void 0===(c=g.set(a,c,d))||(i[b]=c)),void 0)}},css:function(a,b,c,d){var e,f,g,h=n.camelCase(b);return b=n.cssProps[h]||(n.cssProps[h]=Fb(a.style,h)),g=n.cssHooks[b]||n.cssHooks[h],g&&"get"in g&&(e=g.get(a,!0,c)),void 0===e&&(e=xb(a,b,d)),"normal"===e&&b in Db&&(e=Db[b]),""===c||c?(f=parseFloat(e),c===!0||n.isNumeric(f)?f||0:e):e}}),n.each(["height","width"],function(a,b){n.cssHooks[b]={get:function(a,c,d){return c?zb.test(n.css(a,"display"))&&0===a.offsetWidth?n.swap(a,Cb,function(){return Ib(a,b,d)}):Ib(a,b,d):void 0},set:function(a,c,d){var e=d&&wb(a);return Gb(a,c,d?Hb(a,b,d,"border-box"===n.css(a,"boxSizing",!1,e),e):0)}}}),n.cssHooks.marginRight=yb(k.reliableMarginRight,function(a,b){return b?n.swap(a,{display:"inline-block"},xb,[a,"marginRight"]):void 0}),n.each({margin:"",padding:"",border:"Width"},function(a,b){n.cssHooks[a+b]={expand:function(c){for(var d=0,e={},f="string"==typeof c?c.split(" "):[c];4>d;d++)e[a+R[d]+b]=f[d]||f[d-2]||f[0];return e}},ub.test(a)||(n.cssHooks[a+b].set=Gb)}),n.fn.extend({css:function(a,b){return J(this,function(a,b,c){var d,e,f={},g=0;if(n.isArray(b)){for(d=wb(a),e=b.length;e>g;g++)f[b[g]]=n.css(a,b[g],!1,d);return f}return void 0!==c?n.style(a,b,c):n.css(a,b)},a,b,arguments.length>1)},show:function(){return Jb(this,!0)},hide:function(){return Jb(this)},toggle:function(a){return"boolean"==typeof a?a?this.show():this.hide():this.each(function(){S(this)?n(this).show():n(this).hide()})}});function Kb(a,b,c,d,e){return new Kb.prototype.init(a,b,c,d,e)}n.Tween=Kb,Kb.prototype={constructor:Kb,init:function(a,b,c,d,e,f){this.elem=a,this.prop=c,this.easing=e||"swing",this.options=b,this.start=this.now=this.cur(),this.end=d,this.unit=f||(n.cssNumber[c]?"":"px")},cur:function(){var a=Kb.propHooks[this.prop];return a&&a.get?a.get(this):Kb.propHooks._default.get(this)},run:function(a){var b,c=Kb.propHooks[this.prop];return this.pos=b=this.options.duration?n.easing[this.easing](a,this.options.duration*a,0,1,this.options.duration):a,this.now=(this.end-this.start)*b+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),c&&c.set?c.set(this):Kb.propHooks._default.set(this),this}},Kb.prototype.init.prototype=Kb.prototype,Kb.propHooks={_default:{get:function(a){var b;return null==a.elem[a.prop]||a.elem.style&&null!=a.elem.style[a.prop]?(b=n.css(a.elem,a.prop,""),b&&"auto"!==b?b:0):a.elem[a.prop]},set:function(a){n.fx.step[a.prop]?n.fx.step[a.prop](a):a.elem.style&&(null!=a.elem.style[n.cssProps[a.prop]]||n.cssHooks[a.prop])?n.style(a.elem,a.prop,a.now+a.unit):a.elem[a.prop]=a.now}}},Kb.propHooks.scrollTop=Kb.propHooks.scrollLeft={set:function(a){a.elem.nodeType&&a.elem.parentNode&&(a.elem[a.prop]=a.now)}},n.easing={linear:function(a){return a},swing:function(a){return.5-Math.cos(a*Math.PI)/2}},n.fx=Kb.prototype.init,n.fx.step={};var Lb,Mb,Nb=/^(?:toggle|show|hide)$/,Ob=new RegExp("^(?:([+-])=|)("+Q+")([a-z%]*)$","i"),Pb=/queueHooks$/,Qb=[Vb],Rb={"*":[function(a,b){var c=this.createTween(a,b),d=c.cur(),e=Ob.exec(b),f=e&&e[3]||(n.cssNumber[a]?"":"px"),g=(n.cssNumber[a]||"px"!==f&&+d)&&Ob.exec(n.css(c.elem,a)),h=1,i=20;if(g&&g[3]!==f){f=f||g[3],e=e||[],g=+d||1;do h=h||".5",g/=h,n.style(c.elem,a,g+f);while(h!==(h=c.cur()/d)&&1!==h&&--i)}return e&&(g=c.start=+g||+d||0,c.unit=f,c.end=e[1]?g+(e[1]+1)*e[2]:+e[2]),c}]};function Sb(){return setTimeout(function(){Lb=void 0}),Lb=n.now()}function Tb(a,b){var c,d=0,e={height:a};for(b=b?1:0;4>d;d+=2-b)c=R[d],e["margin"+c]=e["padding"+c]=a;return b&&(e.opacity=e.width=a),e}function Ub(a,b,c){for(var d,e=(Rb[b]||[]).concat(Rb["*"]),f=0,g=e.length;g>f;f++)if(d=e[f].call(c,b,a))return d}function Vb(a,b,c){var d,e,f,g,h,i,j,k,l=this,m={},o=a.style,p=a.nodeType&&S(a),q=L.get(a,"fxshow");c.queue||(h=n._queueHooks(a,"fx"),null==h.unqueued&&(h.unqueued=0,i=h.empty.fire,h.empty.fire=function(){h.unqueued||i()}),h.unqueued++,l.always(function(){l.always(function(){h.unqueued--,n.queue(a,"fx").length||h.empty.fire()})})),1===a.nodeType&&("height"in b||"width"in b)&&(c.overflow=[o.overflow,o.overflowX,o.overflowY],j=n.css(a,"display"),k="none"===j?L.get(a,"olddisplay")||tb(a.nodeName):j,"inline"===k&&"none"===n.css(a,"float")&&(o.display="inline-block")),c.overflow&&(o.overflow="hidden",l.always(function(){o.overflow=c.overflow[0],o.overflowX=c.overflow[1],o.overflowY=c.overflow[2]}));for(d in b)if(e=b[d],Nb.exec(e)){if(delete b[d],f=f||"toggle"===e,e===(p?"hide":"show")){if("show"!==e||!q||void 0===q[d])continue;p=!0}m[d]=q&&q[d]||n.style(a,d)}else j=void 0;if(n.isEmptyObject(m))"inline"===("none"===j?tb(a.nodeName):j)&&(o.display=j);else{q?"hidden"in q&&(p=q.hidden):q=L.access(a,"fxshow",{}),f&&(q.hidden=!p),p?n(a).show():l.done(function(){n(a).hide()}),l.done(function(){var b;L.remove(a,"fxshow");for(b in m)n.style(a,b,m[b])});for(d in m)g=Ub(p?q[d]:0,d,l),d in q||(q[d]=g.start,p&&(g.end=g.start,g.start="width"===d||"height"===d?1:0))}}function Wb(a,b){var c,d,e,f,g;for(c in a)if(d=n.camelCase(c),e=b[d],f=a[c],n.isArray(f)&&(e=f[1],f=a[c]=f[0]),c!==d&&(a[d]=f,delete a[c]),g=n.cssHooks[d],g&&"expand"in g){f=g.expand(f),delete a[d];for(c in f)c in a||(a[c]=f[c],b[c]=e)}else b[d]=e}function Xb(a,b,c){var d,e,f=0,g=Qb.length,h=n.Deferred().always(function(){delete i.elem}),i=function(){if(e)return!1;for(var b=Lb||Sb(),c=Math.max(0,j.startTime+j.duration-b),d=c/j.duration||0,f=1-d,g=0,i=j.tweens.length;i>g;g++)j.tweens[g].run(f);return h.notifyWith(a,[j,f,c]),1>f&&i?c:(h.resolveWith(a,[j]),!1)},j=h.promise({elem:a,props:n.extend({},b),opts:n.extend(!0,{specialEasing:{}},c),originalProperties:b,originalOptions:c,startTime:Lb||Sb(),duration:c.duration,tweens:[],createTween:function(b,c){var d=n.Tween(a,j.opts,b,c,j.opts.specialEasing[b]||j.opts.easing);return j.tweens.push(d),d},stop:function(b){var c=0,d=b?j.tweens.length:0;if(e)return this;for(e=!0;d>c;c++)j.tweens[c].run(1);return b?h.resolveWith(a,[j,b]):h.rejectWith(a,[j,b]),this}}),k=j.props;for(Wb(k,j.opts.specialEasing);g>f;f++)if(d=Qb[f].call(j,a,k,j.opts))return d;return n.map(k,Ub,j),n.isFunction(j.opts.start)&&j.opts.start.call(a,j),n.fx.timer(n.extend(i,{elem:a,anim:j,queue:j.opts.queue})),j.progress(j.opts.progress).done(j.opts.done,j.opts.complete).fail(j.opts.fail).always(j.opts.always)}n.Animation=n.extend(Xb,{tweener:function(a,b){n.isFunction(a)?(b=a,a=["*"]):a=a.split(" ");for(var c,d=0,e=a.length;e>d;d++)c=a[d],Rb[c]=Rb[c]||[],Rb[c].unshift(b)},prefilter:function(a,b){b?Qb.unshift(a):Qb.push(a)}}),n.speed=function(a,b,c){var d=a&&"object"==typeof a?n.extend({},a):{complete:c||!c&&b||n.isFunction(a)&&a,duration:a,easing:c&&b||b&&!n.isFunction(b)&&b};return d.duration=n.fx.off?0:"number"==typeof d.duration?d.duration:d.duration in n.fx.speeds?n.fx.speeds[d.duration]:n.fx.speeds._default,(null==d.queue||d.queue===!0)&&(d.queue="fx"),d.old=d.complete,d.complete=function(){n.isFunction(d.old)&&d.old.call(this),d.queue&&n.dequeue(this,d.queue)},d},n.fn.extend({fadeTo:function(a,b,c,d){return this.filter(S).css("opacity",0).show().end().animate({opacity:b},a,c,d)},animate:function(a,b,c,d){var e=n.isEmptyObject(a),f=n.speed(b,c,d),g=function(){var b=Xb(this,n.extend({},a),f);(e||L.get(this,"finish"))&&b.stop(!0)};return g.finish=g,e||f.queue===!1?this.each(g):this.queue(f.queue,g)},stop:function(a,b,c){var d=function(a){var b=a.stop;delete a.stop,b(c)};return"string"!=typeof a&&(c=b,b=a,a=void 0),b&&a!==!1&&this.queue(a||"fx",[]),this.each(function(){var b=!0,e=null!=a&&a+"queueHooks",f=n.timers,g=L.get(this);if(e)g[e]&&g[e].stop&&d(g[e]);else for(e in g)g[e]&&g[e].stop&&Pb.test(e)&&d(g[e]);for(e=f.length;e--;)f[e].elem!==this||null!=a&&f[e].queue!==a||(f[e].anim.stop(c),b=!1,f.splice(e,1));(b||!c)&&n.dequeue(this,a)})},finish:function(a){return a!==!1&&(a=a||"fx"),this.each(function(){var b,c=L.get(this),d=c[a+"queue"],e=c[a+"queueHooks"],f=n.timers,g=d?d.length:0;for(c.finish=!0,n.queue(this,a,[]),e&&e.stop&&e.stop.call(this,!0),b=f.length;b--;)f[b].elem===this&&f[b].queue===a&&(f[b].anim.stop(!0),f.splice(b,1));for(b=0;g>b;b++)d[b]&&d[b].finish&&d[b].finish.call(this);delete c.finish})}}),n.each(["toggle","show","hide"],function(a,b){var c=n.fn[b];n.fn[b]=function(a,d,e){return null==a||"boolean"==typeof a?c.apply(this,arguments):this.animate(Tb(b,!0),a,d,e)}}),n.each({slideDown:Tb("show"),slideUp:Tb("hide"),slideToggle:Tb("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){n.fn[a]=function(a,c,d){return this.animate(b,a,c,d)}}),n.timers=[],n.fx.tick=function(){var a,b=0,c=n.timers;for(Lb=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length||n.fx.stop(),Lb=void 0},n.fx.timer=function(a){n.timers.push(a),a()?n.fx.start():n.timers.pop()},n.fx.interval=13,n.fx.start=function(){Mb||(Mb=setInterval(n.fx.tick,n.fx.interval))},n.fx.stop=function(){clearInterval(Mb),Mb=null},n.fx.speeds={slow:600,fast:200,_default:400},n.fn.delay=function(a,b){return a=n.fx?n.fx.speeds[a]||a:a,b=b||"fx",this.queue(b,function(b,c){var d=setTimeout(b,a);c.stop=function(){clearTimeout(d)}})},function(){var a=l.createElement("input"),b=l.createElement("select"),c=b.appendChild(l.createElement("option"));a.type="checkbox",k.checkOn=""!==a.value,k.optSelected=c.selected,b.disabled=!0,k.optDisabled=!c.disabled,a=l.createElement("input"),a.value="t",a.type="radio",k.radioValue="t"===a.value}();var Yb,Zb,$b=n.expr.attrHandle;n.fn.extend({attr:function(a,b){return J(this,n.attr,a,b,arguments.length>1)},removeAttr:function(a){return this.each(function(){n.removeAttr(this,a)})}}),n.extend({attr:function(a,b,c){var d,e,f=a.nodeType;if(a&&3!==f&&8!==f&&2!==f)return typeof a.getAttribute===U?n.prop(a,b,c):(1===f&&n.isXMLDoc(a)||(b=b.toLowerCase(),d=n.attrHooks[b]||(n.expr.match.bool.test(b)?Zb:Yb)),void 0===c?d&&"get"in d&&null!==(e=d.get(a,b))?e:(e=n.find.attr(a,b),null==e?void 0:e):null!==c?d&&"set"in d&&void 0!==(e=d.set(a,c,b))?e:(a.setAttribute(b,c+""),c):void n.removeAttr(a,b))
/* 4 */ },removeAttr:function(a,b){var c,d,e=0,f=b&&b.match(E);if(f&&1===a.nodeType)while(c=f[e++])d=n.propFix[c]||c,n.expr.match.bool.test(c)&&(a[d]=!1),a.removeAttribute(c)},attrHooks:{type:{set:function(a,b){if(!k.radioValue&&"radio"===b&&n.nodeName(a,"input")){var c=a.value;return a.setAttribute("type",b),c&&(a.value=c),b}}}}}),Zb={set:function(a,b,c){return b===!1?n.removeAttr(a,c):a.setAttribute(c,c),c}},n.each(n.expr.match.bool.source.match(/\w+/g),function(a,b){var c=$b[b]||n.find.attr;$b[b]=function(a,b,d){var e,f;return d||(f=$b[b],$b[b]=e,e=null!=c(a,b,d)?b.toLowerCase():null,$b[b]=f),e}});var _b=/^(?:input|select|textarea|button)$/i;n.fn.extend({prop:function(a,b){return J(this,n.prop,a,b,arguments.length>1)},removeProp:function(a){return this.each(function(){delete this[n.propFix[a]||a]})}}),n.extend({propFix:{"for":"htmlFor","class":"className"},prop:function(a,b,c){var d,e,f,g=a.nodeType;if(a&&3!==g&&8!==g&&2!==g)return f=1!==g||!n.isXMLDoc(a),f&&(b=n.propFix[b]||b,e=n.propHooks[b]),void 0!==c?e&&"set"in e&&void 0!==(d=e.set(a,c,b))?d:a[b]=c:e&&"get"in e&&null!==(d=e.get(a,b))?d:a[b]},propHooks:{tabIndex:{get:function(a){return a.hasAttribute("tabindex")||_b.test(a.nodeName)||a.href?a.tabIndex:-1}}}}),k.optSelected||(n.propHooks.selected={get:function(a){var b=a.parentNode;return b&&b.parentNode&&b.parentNode.selectedIndex,null}}),n.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],function(){n.propFix[this.toLowerCase()]=this});var ac=/[\t\r\n\f]/g;n.fn.extend({addClass:function(a){var b,c,d,e,f,g,h="string"==typeof a&&a,i=0,j=this.length;if(n.isFunction(a))return this.each(function(b){n(this).addClass(a.call(this,b,this.className))});if(h)for(b=(a||"").match(E)||[];j>i;i++)if(c=this[i],d=1===c.nodeType&&(c.className?(" "+c.className+" ").replace(ac," "):" ")){f=0;while(e=b[f++])d.indexOf(" "+e+" ")<0&&(d+=e+" ");g=n.trim(d),c.className!==g&&(c.className=g)}return this},removeClass:function(a){var b,c,d,e,f,g,h=0===arguments.length||"string"==typeof a&&a,i=0,j=this.length;if(n.isFunction(a))return this.each(function(b){n(this).removeClass(a.call(this,b,this.className))});if(h)for(b=(a||"").match(E)||[];j>i;i++)if(c=this[i],d=1===c.nodeType&&(c.className?(" "+c.className+" ").replace(ac," "):"")){f=0;while(e=b[f++])while(d.indexOf(" "+e+" ")>=0)d=d.replace(" "+e+" "," ");g=a?n.trim(d):"",c.className!==g&&(c.className=g)}return this},toggleClass:function(a,b){var c=typeof a;return"boolean"==typeof b&&"string"===c?b?this.addClass(a):this.removeClass(a):this.each(n.isFunction(a)?function(c){n(this).toggleClass(a.call(this,c,this.className,b),b)}:function(){if("string"===c){var b,d=0,e=n(this),f=a.match(E)||[];while(b=f[d++])e.hasClass(b)?e.removeClass(b):e.addClass(b)}else(c===U||"boolean"===c)&&(this.className&&L.set(this,"__className__",this.className),this.className=this.className||a===!1?"":L.get(this,"__className__")||"")})},hasClass:function(a){for(var b=" "+a+" ",c=0,d=this.length;d>c;c++)if(1===this[c].nodeType&&(" "+this[c].className+" ").replace(ac," ").indexOf(b)>=0)return!0;return!1}});var bc=/\r/g;n.fn.extend({val:function(a){var b,c,d,e=this[0];{if(arguments.length)return d=n.isFunction(a),this.each(function(c){var e;1===this.nodeType&&(e=d?a.call(this,c,n(this).val()):a,null==e?e="":"number"==typeof e?e+="":n.isArray(e)&&(e=n.map(e,function(a){return null==a?"":a+""})),b=n.valHooks[this.type]||n.valHooks[this.nodeName.toLowerCase()],b&&"set"in b&&void 0!==b.set(this,e,"value")||(this.value=e))});if(e)return b=n.valHooks[e.type]||n.valHooks[e.nodeName.toLowerCase()],b&&"get"in b&&void 0!==(c=b.get(e,"value"))?c:(c=e.value,"string"==typeof c?c.replace(bc,""):null==c?"":c)}}}),n.extend({valHooks:{option:{get:function(a){var b=n.find.attr(a,"value");return null!=b?b:n.trim(n.text(a))}},select:{get:function(a){for(var b,c,d=a.options,e=a.selectedIndex,f="select-one"===a.type||0>e,g=f?null:[],h=f?e+1:d.length,i=0>e?h:f?e:0;h>i;i++)if(c=d[i],!(!c.selected&&i!==e||(k.optDisabled?c.disabled:null!==c.getAttribute("disabled"))||c.parentNode.disabled&&n.nodeName(c.parentNode,"optgroup"))){if(b=n(c).val(),f)return b;g.push(b)}return g},set:function(a,b){var c,d,e=a.options,f=n.makeArray(b),g=e.length;while(g--)d=e[g],(d.selected=n.inArray(d.value,f)>=0)&&(c=!0);return c||(a.selectedIndex=-1),f}}}}),n.each(["radio","checkbox"],function(){n.valHooks[this]={set:function(a,b){return n.isArray(b)?a.checked=n.inArray(n(a).val(),b)>=0:void 0}},k.checkOn||(n.valHooks[this].get=function(a){return null===a.getAttribute("value")?"on":a.value})}),n.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(a,b){n.fn[b]=function(a,c){return arguments.length>0?this.on(b,null,a,c):this.trigger(b)}}),n.fn.extend({hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)},bind:function(a,b,c){return this.on(a,null,b,c)},unbind:function(a,b){return this.off(a,null,b)},delegate:function(a,b,c,d){return this.on(b,a,c,d)},undelegate:function(a,b,c){return 1===arguments.length?this.off(a,"**"):this.off(b,a||"**",c)}});var cc=n.now(),dc=/\?/;n.parseJSON=function(a){return JSON.parse(a+"")},n.parseXML=function(a){var b,c;if(!a||"string"!=typeof a)return null;try{c=new DOMParser,b=c.parseFromString(a,"text/xml")}catch(d){b=void 0}return(!b||b.getElementsByTagName("parsererror").length)&&n.error("Invalid XML: "+a),b};var ec,fc,gc=/#.*$/,hc=/([?&])_=[^&]*/,ic=/^(.*?):[ \t]*([^\r\n]*)$/gm,jc=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,kc=/^(?:GET|HEAD)$/,lc=/^\/\//,mc=/^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,nc={},oc={},pc="*/".concat("*");try{fc=location.href}catch(qc){fc=l.createElement("a"),fc.href="",fc=fc.href}ec=mc.exec(fc.toLowerCase())||[];function rc(a){return function(b,c){"string"!=typeof b&&(c=b,b="*");var d,e=0,f=b.toLowerCase().match(E)||[];if(n.isFunction(c))while(d=f[e++])"+"===d[0]?(d=d.slice(1)||"*",(a[d]=a[d]||[]).unshift(c)):(a[d]=a[d]||[]).push(c)}}function sc(a,b,c,d){var e={},f=a===oc;function g(h){var i;return e[h]=!0,n.each(a[h]||[],function(a,h){var j=h(b,c,d);return"string"!=typeof j||f||e[j]?f?!(i=j):void 0:(b.dataTypes.unshift(j),g(j),!1)}),i}return g(b.dataTypes[0])||!e["*"]&&g("*")}function tc(a,b){var c,d,e=n.ajaxSettings.flatOptions||{};for(c in b)void 0!==b[c]&&((e[c]?a:d||(d={}))[c]=b[c]);return d&&n.extend(!0,a,d),a}function uc(a,b,c){var d,e,f,g,h=a.contents,i=a.dataTypes;while("*"===i[0])i.shift(),void 0===d&&(d=a.mimeType||b.getResponseHeader("Content-Type"));if(d)for(e in h)if(h[e]&&h[e].test(d)){i.unshift(e);break}if(i[0]in c)f=i[0];else{for(e in c){if(!i[0]||a.converters[e+" "+i[0]]){f=e;break}g||(g=e)}f=f||g}return f?(f!==i[0]&&i.unshift(f),c[f]):void 0}function vc(a,b,c,d){var e,f,g,h,i,j={},k=a.dataTypes.slice();if(k[1])for(g in a.converters)j[g.toLowerCase()]=a.converters[g];f=k.shift();while(f)if(a.responseFields[f]&&(c[a.responseFields[f]]=b),!i&&d&&a.dataFilter&&(b=a.dataFilter(b,a.dataType)),i=f,f=k.shift())if("*"===f)f=i;else if("*"!==i&&i!==f){if(g=j[i+" "+f]||j["* "+f],!g)for(e in j)if(h=e.split(" "),h[1]===f&&(g=j[i+" "+h[0]]||j["* "+h[0]])){g===!0?g=j[e]:j[e]!==!0&&(f=h[0],k.unshift(h[1]));break}if(g!==!0)if(g&&a["throws"])b=g(b);else try{b=g(b)}catch(l){return{state:"parsererror",error:g?l:"No conversion from "+i+" to "+f}}}return{state:"success",data:b}}n.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:fc,type:"GET",isLocal:jc.test(ec[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":pc,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText",json:"responseJSON"},converters:{"* text":String,"text html":!0,"text json":n.parseJSON,"text xml":n.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(a,b){return b?tc(tc(a,n.ajaxSettings),b):tc(n.ajaxSettings,a)},ajaxPrefilter:rc(nc),ajaxTransport:rc(oc),ajax:function(a,b){"object"==typeof a&&(b=a,a=void 0),b=b||{};var c,d,e,f,g,h,i,j,k=n.ajaxSetup({},b),l=k.context||k,m=k.context&&(l.nodeType||l.jquery)?n(l):n.event,o=n.Deferred(),p=n.Callbacks("once memory"),q=k.statusCode||{},r={},s={},t=0,u="canceled",v={readyState:0,getResponseHeader:function(a){var b;if(2===t){if(!f){f={};while(b=ic.exec(e))f[b[1].toLowerCase()]=b[2]}b=f[a.toLowerCase()]}return null==b?null:b},getAllResponseHeaders:function(){return 2===t?e:null},setRequestHeader:function(a,b){var c=a.toLowerCase();return t||(a=s[c]=s[c]||a,r[a]=b),this},overrideMimeType:function(a){return t||(k.mimeType=a),this},statusCode:function(a){var b;if(a)if(2>t)for(b in a)q[b]=[q[b],a[b]];else v.always(a[v.status]);return this},abort:function(a){var b=a||u;return c&&c.abort(b),x(0,b),this}};if(o.promise(v).complete=p.add,v.success=v.done,v.error=v.fail,k.url=((a||k.url||fc)+"").replace(gc,"").replace(lc,ec[1]+"//"),k.type=b.method||b.type||k.method||k.type,k.dataTypes=n.trim(k.dataType||"*").toLowerCase().match(E)||[""],null==k.crossDomain&&(h=mc.exec(k.url.toLowerCase()),k.crossDomain=!(!h||h[1]===ec[1]&&h[2]===ec[2]&&(h[3]||("http:"===h[1]?"80":"443"))===(ec[3]||("http:"===ec[1]?"80":"443")))),k.data&&k.processData&&"string"!=typeof k.data&&(k.data=n.param(k.data,k.traditional)),sc(nc,k,b,v),2===t)return v;i=k.global,i&&0===n.active++&&n.event.trigger("ajaxStart"),k.type=k.type.toUpperCase(),k.hasContent=!kc.test(k.type),d=k.url,k.hasContent||(k.data&&(d=k.url+=(dc.test(d)?"&":"?")+k.data,delete k.data),k.cache===!1&&(k.url=hc.test(d)?d.replace(hc,"$1_="+cc++):d+(dc.test(d)?"&":"?")+"_="+cc++)),k.ifModified&&(n.lastModified[d]&&v.setRequestHeader("If-Modified-Since",n.lastModified[d]),n.etag[d]&&v.setRequestHeader("If-None-Match",n.etag[d])),(k.data&&k.hasContent&&k.contentType!==!1||b.contentType)&&v.setRequestHeader("Content-Type",k.contentType),v.setRequestHeader("Accept",k.dataTypes[0]&&k.accepts[k.dataTypes[0]]?k.accepts[k.dataTypes[0]]+("*"!==k.dataTypes[0]?", "+pc+"; q=0.01":""):k.accepts["*"]);for(j in k.headers)v.setRequestHeader(j,k.headers[j]);if(k.beforeSend&&(k.beforeSend.call(l,v,k)===!1||2===t))return v.abort();u="abort";for(j in{success:1,error:1,complete:1})v[j](k[j]);if(c=sc(oc,k,b,v)){v.readyState=1,i&&m.trigger("ajaxSend",[v,k]),k.async&&k.timeout>0&&(g=setTimeout(function(){v.abort("timeout")},k.timeout));try{t=1,c.send(r,x)}catch(w){if(!(2>t))throw w;x(-1,w)}}else x(-1,"No Transport");function x(a,b,f,h){var j,r,s,u,w,x=b;2!==t&&(t=2,g&&clearTimeout(g),c=void 0,e=h||"",v.readyState=a>0?4:0,j=a>=200&&300>a||304===a,f&&(u=uc(k,v,f)),u=vc(k,u,v,j),j?(k.ifModified&&(w=v.getResponseHeader("Last-Modified"),w&&(n.lastModified[d]=w),w=v.getResponseHeader("etag"),w&&(n.etag[d]=w)),204===a||"HEAD"===k.type?x="nocontent":304===a?x="notmodified":(x=u.state,r=u.data,s=u.error,j=!s)):(s=x,(a||!x)&&(x="error",0>a&&(a=0))),v.status=a,v.statusText=(b||x)+"",j?o.resolveWith(l,[r,x,v]):o.rejectWith(l,[v,x,s]),v.statusCode(q),q=void 0,i&&m.trigger(j?"ajaxSuccess":"ajaxError",[v,k,j?r:s]),p.fireWith(l,[v,x]),i&&(m.trigger("ajaxComplete",[v,k]),--n.active||n.event.trigger("ajaxStop")))}return v},getJSON:function(a,b,c){return n.get(a,b,c,"json")},getScript:function(a,b){return n.get(a,void 0,b,"script")}}),n.each(["get","post"],function(a,b){n[b]=function(a,c,d,e){return n.isFunction(c)&&(e=e||d,d=c,c=void 0),n.ajax({url:a,type:b,dataType:e,data:c,success:d})}}),n.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(a,b){n.fn[b]=function(a){return this.on(b,a)}}),n._evalUrl=function(a){return n.ajax({url:a,type:"GET",dataType:"script",async:!1,global:!1,"throws":!0})},n.fn.extend({wrapAll:function(a){var b;return n.isFunction(a)?this.each(function(b){n(this).wrapAll(a.call(this,b))}):(this[0]&&(b=n(a,this[0].ownerDocument).eq(0).clone(!0),this[0].parentNode&&b.insertBefore(this[0]),b.map(function(){var a=this;while(a.firstElementChild)a=a.firstElementChild;return a}).append(this)),this)},wrapInner:function(a){return this.each(n.isFunction(a)?function(b){n(this).wrapInner(a.call(this,b))}:function(){var b=n(this),c=b.contents();c.length?c.wrapAll(a):b.append(a)})},wrap:function(a){var b=n.isFunction(a);return this.each(function(c){n(this).wrapAll(b?a.call(this,c):a)})},unwrap:function(){return this.parent().each(function(){n.nodeName(this,"body")||n(this).replaceWith(this.childNodes)}).end()}}),n.expr.filters.hidden=function(a){return a.offsetWidth<=0&&a.offsetHeight<=0},n.expr.filters.visible=function(a){return!n.expr.filters.hidden(a)};var wc=/%20/g,xc=/\[\]$/,yc=/\r?\n/g,zc=/^(?:submit|button|image|reset|file)$/i,Ac=/^(?:input|select|textarea|keygen)/i;function Bc(a,b,c,d){var e;if(n.isArray(b))n.each(b,function(b,e){c||xc.test(a)?d(a,e):Bc(a+"["+("object"==typeof e?b:"")+"]",e,c,d)});else if(c||"object"!==n.type(b))d(a,b);else for(e in b)Bc(a+"["+e+"]",b[e],c,d)}n.param=function(a,b){var c,d=[],e=function(a,b){b=n.isFunction(b)?b():null==b?"":b,d[d.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)};if(void 0===b&&(b=n.ajaxSettings&&n.ajaxSettings.traditional),n.isArray(a)||a.jquery&&!n.isPlainObject(a))n.each(a,function(){e(this.name,this.value)});else for(c in a)Bc(c,a[c],b,e);return d.join("&").replace(wc,"+")},n.fn.extend({serialize:function(){return n.param(this.serializeArray())},serializeArray:function(){return this.map(function(){var a=n.prop(this,"elements");return a?n.makeArray(a):this}).filter(function(){var a=this.type;return this.name&&!n(this).is(":disabled")&&Ac.test(this.nodeName)&&!zc.test(a)&&(this.checked||!T.test(a))}).map(function(a,b){var c=n(this).val();return null==c?null:n.isArray(c)?n.map(c,function(a){return{name:b.name,value:a.replace(yc,"\r\n")}}):{name:b.name,value:c.replace(yc,"\r\n")}}).get()}}),n.ajaxSettings.xhr=function(){try{return new XMLHttpRequest}catch(a){}};var Cc=0,Dc={},Ec={0:200,1223:204},Fc=n.ajaxSettings.xhr();a.ActiveXObject&&n(a).on("unload",function(){for(var a in Dc)Dc[a]()}),k.cors=!!Fc&&"withCredentials"in Fc,k.ajax=Fc=!!Fc,n.ajaxTransport(function(a){var b;return k.cors||Fc&&!a.crossDomain?{send:function(c,d){var e,f=a.xhr(),g=++Cc;if(f.open(a.type,a.url,a.async,a.username,a.password),a.xhrFields)for(e in a.xhrFields)f[e]=a.xhrFields[e];a.mimeType&&f.overrideMimeType&&f.overrideMimeType(a.mimeType),a.crossDomain||c["X-Requested-With"]||(c["X-Requested-With"]="XMLHttpRequest");for(e in c)f.setRequestHeader(e,c[e]);b=function(a){return function(){b&&(delete Dc[g],b=f.onload=f.onerror=null,"abort"===a?f.abort():"error"===a?d(f.status,f.statusText):d(Ec[f.status]||f.status,f.statusText,"string"==typeof f.responseText?{text:f.responseText}:void 0,f.getAllResponseHeaders()))}},f.onload=b(),f.onerror=b("error"),b=Dc[g]=b("abort");try{f.send(a.hasContent&&a.data||null)}catch(h){if(b)throw h}},abort:function(){b&&b()}}:void 0}),n.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/(?:java|ecma)script/},converters:{"text script":function(a){return n.globalEval(a),a}}}),n.ajaxPrefilter("script",function(a){void 0===a.cache&&(a.cache=!1),a.crossDomain&&(a.type="GET")}),n.ajaxTransport("script",function(a){if(a.crossDomain){var b,c;return{send:function(d,e){b=n("<script>").prop({async:!0,charset:a.scriptCharset,src:a.url}).on("load error",c=function(a){b.remove(),c=null,a&&e("error"===a.type?404:200,a.type)}),l.head.appendChild(b[0])},abort:function(){c&&c()}}}});var Gc=[],Hc=/(=)\?(?=&|$)|\?\?/;n.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var a=Gc.pop()||n.expando+"_"+cc++;return this[a]=!0,a}}),n.ajaxPrefilter("json jsonp",function(b,c,d){var e,f,g,h=b.jsonp!==!1&&(Hc.test(b.url)?"url":"string"==typeof b.data&&!(b.contentType||"").indexOf("application/x-www-form-urlencoded")&&Hc.test(b.data)&&"data");return h||"jsonp"===b.dataTypes[0]?(e=b.jsonpCallback=n.isFunction(b.jsonpCallback)?b.jsonpCallback():b.jsonpCallback,h?b[h]=b[h].replace(Hc,"$1"+e):b.jsonp!==!1&&(b.url+=(dc.test(b.url)?"&":"?")+b.jsonp+"="+e),b.converters["script json"]=function(){return g||n.error(e+" was not called"),g[0]},b.dataTypes[0]="json",f=a[e],a[e]=function(){g=arguments},d.always(function(){a[e]=f,b[e]&&(b.jsonpCallback=c.jsonpCallback,Gc.push(e)),g&&n.isFunction(f)&&f(g[0]),g=f=void 0}),"script"):void 0}),n.parseHTML=function(a,b,c){if(!a||"string"!=typeof a)return null;"boolean"==typeof b&&(c=b,b=!1),b=b||l;var d=v.exec(a),e=!c&&[];return d?[b.createElement(d[1])]:(d=n.buildFragment([a],b,e),e&&e.length&&n(e).remove(),n.merge([],d.childNodes))};var Ic=n.fn.load;n.fn.load=function(a,b,c){if("string"!=typeof a&&Ic)return Ic.apply(this,arguments);var d,e,f,g=this,h=a.indexOf(" ");return h>=0&&(d=n.trim(a.slice(h)),a=a.slice(0,h)),n.isFunction(b)?(c=b,b=void 0):b&&"object"==typeof b&&(e="POST"),g.length>0&&n.ajax({url:a,type:e,dataType:"html",data:b}).done(function(a){f=arguments,g.html(d?n("<div>").append(n.parseHTML(a)).find(d):a)}).complete(c&&function(a,b){g.each(c,f||[a.responseText,b,a])}),this},n.expr.filters.animated=function(a){return n.grep(n.timers,function(b){return a===b.elem}).length};var Jc=a.document.documentElement;function Kc(a){return n.isWindow(a)?a:9===a.nodeType&&a.defaultView}n.offset={setOffset:function(a,b,c){var d,e,f,g,h,i,j,k=n.css(a,"position"),l=n(a),m={};"static"===k&&(a.style.position="relative"),h=l.offset(),f=n.css(a,"top"),i=n.css(a,"left"),j=("absolute"===k||"fixed"===k)&&(f+i).indexOf("auto")>-1,j?(d=l.position(),g=d.top,e=d.left):(g=parseFloat(f)||0,e=parseFloat(i)||0),n.isFunction(b)&&(b=b.call(a,c,h)),null!=b.top&&(m.top=b.top-h.top+g),null!=b.left&&(m.left=b.left-h.left+e),"using"in b?b.using.call(a,m):l.css(m)}},n.fn.extend({offset:function(a){if(arguments.length)return void 0===a?this:this.each(function(b){n.offset.setOffset(this,a,b)});var b,c,d=this[0],e={top:0,left:0},f=d&&d.ownerDocument;if(f)return b=f.documentElement,n.contains(b,d)?(typeof d.getBoundingClientRect!==U&&(e=d.getBoundingClientRect()),c=Kc(f),{top:e.top+c.pageYOffset-b.clientTop,left:e.left+c.pageXOffset-b.clientLeft}):e},position:function(){if(this[0]){var a,b,c=this[0],d={top:0,left:0};return"fixed"===n.css(c,"position")?b=c.getBoundingClientRect():(a=this.offsetParent(),b=this.offset(),n.nodeName(a[0],"html")||(d=a.offset()),d.top+=n.css(a[0],"borderTopWidth",!0),d.left+=n.css(a[0],"borderLeftWidth",!0)),{top:b.top-d.top-n.css(c,"marginTop",!0),left:b.left-d.left-n.css(c,"marginLeft",!0)}}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||Jc;while(a&&!n.nodeName(a,"html")&&"static"===n.css(a,"position"))a=a.offsetParent;return a||Jc})}}),n.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(b,c){var d="pageYOffset"===c;n.fn[b]=function(e){return J(this,function(b,e,f){var g=Kc(b);return void 0===f?g?g[c]:b[e]:void(g?g.scrollTo(d?a.pageXOffset:f,d?f:a.pageYOffset):b[e]=f)},b,e,arguments.length,null)}}),n.each(["top","left"],function(a,b){n.cssHooks[b]=yb(k.pixelPosition,function(a,c){return c?(c=xb(a,b),vb.test(c)?n(a).position()[b]+"px":c):void 0})}),n.each({Height:"height",Width:"width"},function(a,b){n.each({padding:"inner"+a,content:b,"":"outer"+a},function(c,d){n.fn[d]=function(d,e){var f=arguments.length&&(c||"boolean"!=typeof d),g=c||(d===!0||e===!0?"margin":"border");return J(this,function(b,c,d){var e;return n.isWindow(b)?b.document.documentElement["client"+a]:9===b.nodeType?(e=b.documentElement,Math.max(b.body["scroll"+a],e["scroll"+a],b.body["offset"+a],e["offset"+a],e["client"+a])):void 0===d?n.css(b,c,g):n.style(b,c,d,g)},b,f?d:void 0,f,null)}})}),n.fn.size=function(){return this.length},n.fn.andSelf=n.fn.addBack,"function"==typeof define&&define.amd&&define("jquery",[],function(){return n});var Lc=a.jQuery,Mc=a.$;return n.noConflict=function(b){return a.$===n&&(a.$=Mc),b&&a.jQuery===n&&(a.jQuery=Lc),n},typeof b===U&&(a.jQuery=a.$=n),n});
/* 5 */ 

;
/* bootstrap.min.js */

/* 1 */ /*!
/* 2 *|  * Bootstrap v3.3.2 (http://getbootstrap.com)
/* 3 *|  * Copyright 2011-2015 Twitter, Inc.
/* 4 *|  * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
/* 5 *|  */
/* 6 */ if("undefined"==typeof jQuery)throw new Error("Bootstrap's JavaScript requires jQuery");+function(a){"use strict";var b=a.fn.jquery.split(" ")[0].split(".");if(b[0]<2&&b[1]<9||1==b[0]&&9==b[1]&&b[2]<1)throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher")}(jQuery),+function(a){"use strict";function b(){var a=document.createElement("bootstrap"),b={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"};for(var c in b)if(void 0!==a.style[c])return{end:b[c]};return!1}a.fn.emulateTransitionEnd=function(b){var c=!1,d=this;a(this).one("bsTransitionEnd",function(){c=!0});var e=function(){c||a(d).trigger(a.support.transition.end)};return setTimeout(e,b),this},a(function(){a.support.transition=b(),a.support.transition&&(a.event.special.bsTransitionEnd={bindType:a.support.transition.end,delegateType:a.support.transition.end,handle:function(b){return a(b.target).is(this)?b.handleObj.handler.apply(this,arguments):void 0}})})}(jQuery),+function(a){"use strict";function b(b){return this.each(function(){var c=a(this),e=c.data("bs.alert");e||c.data("bs.alert",e=new d(this)),"string"==typeof b&&e[b].call(c)})}var c='[data-dismiss="alert"]',d=function(b){a(b).on("click",c,this.close)};d.VERSION="3.3.2",d.TRANSITION_DURATION=150,d.prototype.close=function(b){function c(){g.detach().trigger("closed.bs.alert").remove()}var e=a(this),f=e.attr("data-target");f||(f=e.attr("href"),f=f&&f.replace(/.*(?=#[^\s]*$)/,""));var g=a(f);b&&b.preventDefault(),g.length||(g=e.closest(".alert")),g.trigger(b=a.Event("close.bs.alert")),b.isDefaultPrevented()||(g.removeClass("in"),a.support.transition&&g.hasClass("fade")?g.one("bsTransitionEnd",c).emulateTransitionEnd(d.TRANSITION_DURATION):c())};var e=a.fn.alert;a.fn.alert=b,a.fn.alert.Constructor=d,a.fn.alert.noConflict=function(){return a.fn.alert=e,this},a(document).on("click.bs.alert.data-api",c,d.prototype.close)}(jQuery),+function(a){"use strict";function b(b){return this.each(function(){var d=a(this),e=d.data("bs.button"),f="object"==typeof b&&b;e||d.data("bs.button",e=new c(this,f)),"toggle"==b?e.toggle():b&&e.setState(b)})}var c=function(b,d){this.$element=a(b),this.options=a.extend({},c.DEFAULTS,d),this.isLoading=!1};c.VERSION="3.3.2",c.DEFAULTS={loadingText:"loading..."},c.prototype.setState=function(b){var c="disabled",d=this.$element,e=d.is("input")?"val":"html",f=d.data();b+="Text",null==f.resetText&&d.data("resetText",d[e]()),setTimeout(a.proxy(function(){d[e](null==f[b]?this.options[b]:f[b]),"loadingText"==b?(this.isLoading=!0,d.addClass(c).attr(c,c)):this.isLoading&&(this.isLoading=!1,d.removeClass(c).removeAttr(c))},this),0)},c.prototype.toggle=function(){var a=!0,b=this.$element.closest('[data-toggle="buttons"]');if(b.length){var c=this.$element.find("input");"radio"==c.prop("type")&&(c.prop("checked")&&this.$element.hasClass("active")?a=!1:b.find(".active").removeClass("active")),a&&c.prop("checked",!this.$element.hasClass("active")).trigger("change")}else this.$element.attr("aria-pressed",!this.$element.hasClass("active"));a&&this.$element.toggleClass("active")};var d=a.fn.button;a.fn.button=b,a.fn.button.Constructor=c,a.fn.button.noConflict=function(){return a.fn.button=d,this},a(document).on("click.bs.button.data-api",'[data-toggle^="button"]',function(c){var d=a(c.target);d.hasClass("btn")||(d=d.closest(".btn")),b.call(d,"toggle"),c.preventDefault()}).on("focus.bs.button.data-api blur.bs.button.data-api",'[data-toggle^="button"]',function(b){a(b.target).closest(".btn").toggleClass("focus",/^focus(in)?$/.test(b.type))})}(jQuery),+function(a){"use strict";function b(b){return this.each(function(){var d=a(this),e=d.data("bs.carousel"),f=a.extend({},c.DEFAULTS,d.data(),"object"==typeof b&&b),g="string"==typeof b?b:f.slide;e||d.data("bs.carousel",e=new c(this,f)),"number"==typeof b?e.to(b):g?e[g]():f.interval&&e.pause().cycle()})}var c=function(b,c){this.$element=a(b),this.$indicators=this.$element.find(".carousel-indicators"),this.options=c,this.paused=this.sliding=this.interval=this.$active=this.$items=null,this.options.keyboard&&this.$element.on("keydown.bs.carousel",a.proxy(this.keydown,this)),"hover"==this.options.pause&&!("ontouchstart"in document.documentElement)&&this.$element.on("mouseenter.bs.carousel",a.proxy(this.pause,this)).on("mouseleave.bs.carousel",a.proxy(this.cycle,this))};c.VERSION="3.3.2",c.TRANSITION_DURATION=600,c.DEFAULTS={interval:5e3,pause:"hover",wrap:!0,keyboard:!0},c.prototype.keydown=function(a){if(!/input|textarea/i.test(a.target.tagName)){switch(a.which){case 37:this.prev();break;case 39:this.next();break;default:return}a.preventDefault()}},c.prototype.cycle=function(b){return b||(this.paused=!1),this.interval&&clearInterval(this.interval),this.options.interval&&!this.paused&&(this.interval=setInterval(a.proxy(this.next,this),this.options.interval)),this},c.prototype.getItemIndex=function(a){return this.$items=a.parent().children(".item"),this.$items.index(a||this.$active)},c.prototype.getItemForDirection=function(a,b){var c=this.getItemIndex(b),d="prev"==a&&0===c||"next"==a&&c==this.$items.length-1;if(d&&!this.options.wrap)return b;var e="prev"==a?-1:1,f=(c+e)%this.$items.length;return this.$items.eq(f)},c.prototype.to=function(a){var b=this,c=this.getItemIndex(this.$active=this.$element.find(".item.active"));return a>this.$items.length-1||0>a?void 0:this.sliding?this.$element.one("slid.bs.carousel",function(){b.to(a)}):c==a?this.pause().cycle():this.slide(a>c?"next":"prev",this.$items.eq(a))},c.prototype.pause=function(b){return b||(this.paused=!0),this.$element.find(".next, .prev").length&&a.support.transition&&(this.$element.trigger(a.support.transition.end),this.cycle(!0)),this.interval=clearInterval(this.interval),this},c.prototype.next=function(){return this.sliding?void 0:this.slide("next")},c.prototype.prev=function(){return this.sliding?void 0:this.slide("prev")},c.prototype.slide=function(b,d){var e=this.$element.find(".item.active"),f=d||this.getItemForDirection(b,e),g=this.interval,h="next"==b?"left":"right",i=this;if(f.hasClass("active"))return this.sliding=!1;var j=f[0],k=a.Event("slide.bs.carousel",{relatedTarget:j,direction:h});if(this.$element.trigger(k),!k.isDefaultPrevented()){if(this.sliding=!0,g&&this.pause(),this.$indicators.length){this.$indicators.find(".active").removeClass("active");var l=a(this.$indicators.children()[this.getItemIndex(f)]);l&&l.addClass("active")}var m=a.Event("slid.bs.carousel",{relatedTarget:j,direction:h});return a.support.transition&&this.$element.hasClass("slide")?(f.addClass(b),f[0].offsetWidth,e.addClass(h),f.addClass(h),e.one("bsTransitionEnd",function(){f.removeClass([b,h].join(" ")).addClass("active"),e.removeClass(["active",h].join(" ")),i.sliding=!1,setTimeout(function(){i.$element.trigger(m)},0)}).emulateTransitionEnd(c.TRANSITION_DURATION)):(e.removeClass("active"),f.addClass("active"),this.sliding=!1,this.$element.trigger(m)),g&&this.cycle(),this}};var d=a.fn.carousel;a.fn.carousel=b,a.fn.carousel.Constructor=c,a.fn.carousel.noConflict=function(){return a.fn.carousel=d,this};var e=function(c){var d,e=a(this),f=a(e.attr("data-target")||(d=e.attr("href"))&&d.replace(/.*(?=#[^\s]+$)/,""));if(f.hasClass("carousel")){var g=a.extend({},f.data(),e.data()),h=e.attr("data-slide-to");h&&(g.interval=!1),b.call(f,g),h&&f.data("bs.carousel").to(h),c.preventDefault()}};a(document).on("click.bs.carousel.data-api","[data-slide]",e).on("click.bs.carousel.data-api","[data-slide-to]",e),a(window).on("load",function(){a('[data-ride="carousel"]').each(function(){var c=a(this);b.call(c,c.data())})})}(jQuery),+function(a){"use strict";function b(b){var c,d=b.attr("data-target")||(c=b.attr("href"))&&c.replace(/.*(?=#[^\s]+$)/,"");return a(d)}function c(b){return this.each(function(){var c=a(this),e=c.data("bs.collapse"),f=a.extend({},d.DEFAULTS,c.data(),"object"==typeof b&&b);!e&&f.toggle&&"show"==b&&(f.toggle=!1),e||c.data("bs.collapse",e=new d(this,f)),"string"==typeof b&&e[b]()})}var d=function(b,c){this.$element=a(b),this.options=a.extend({},d.DEFAULTS,c),this.$trigger=a(this.options.trigger).filter('[href="#'+b.id+'"], [data-target="#'+b.id+'"]'),this.transitioning=null,this.options.parent?this.$parent=this.getParent():this.addAriaAndCollapsedClass(this.$element,this.$trigger),this.options.toggle&&this.toggle()};d.VERSION="3.3.2",d.TRANSITION_DURATION=350,d.DEFAULTS={toggle:!0,trigger:'[data-toggle="collapse"]'},d.prototype.dimension=function(){var a=this.$element.hasClass("width");return a?"width":"height"},d.prototype.show=function(){if(!this.transitioning&&!this.$element.hasClass("in")){var b,e=this.$parent&&this.$parent.children(".panel").children(".in, .collapsing");if(!(e&&e.length&&(b=e.data("bs.collapse"),b&&b.transitioning))){var f=a.Event("show.bs.collapse");if(this.$element.trigger(f),!f.isDefaultPrevented()){e&&e.length&&(c.call(e,"hide"),b||e.data("bs.collapse",null));var g=this.dimension();this.$element.removeClass("collapse").addClass("collapsing")[g](0).attr("aria-expanded",!0),this.$trigger.removeClass("collapsed").attr("aria-expanded",!0),this.transitioning=1;var h=function(){this.$element.removeClass("collapsing").addClass("collapse in")[g](""),this.transitioning=0,this.$element.trigger("shown.bs.collapse")};if(!a.support.transition)return h.call(this);var i=a.camelCase(["scroll",g].join("-"));this.$element.one("bsTransitionEnd",a.proxy(h,this)).emulateTransitionEnd(d.TRANSITION_DURATION)[g](this.$element[0][i])}}}},d.prototype.hide=function(){if(!this.transitioning&&this.$element.hasClass("in")){var b=a.Event("hide.bs.collapse");if(this.$element.trigger(b),!b.isDefaultPrevented()){var c=this.dimension();this.$element[c](this.$element[c]())[0].offsetHeight,this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded",!1),this.$trigger.addClass("collapsed").attr("aria-expanded",!1),this.transitioning=1;var e=function(){this.transitioning=0,this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")};return a.support.transition?void this.$element[c](0).one("bsTransitionEnd",a.proxy(e,this)).emulateTransitionEnd(d.TRANSITION_DURATION):e.call(this)}}},d.prototype.toggle=function(){this[this.$element.hasClass("in")?"hide":"show"]()},d.prototype.getParent=function(){return a(this.options.parent).find('[data-toggle="collapse"][data-parent="'+this.options.parent+'"]').each(a.proxy(function(c,d){var e=a(d);this.addAriaAndCollapsedClass(b(e),e)},this)).end()},d.prototype.addAriaAndCollapsedClass=function(a,b){var c=a.hasClass("in");a.attr("aria-expanded",c),b.toggleClass("collapsed",!c).attr("aria-expanded",c)};var e=a.fn.collapse;a.fn.collapse=c,a.fn.collapse.Constructor=d,a.fn.collapse.noConflict=function(){return a.fn.collapse=e,this},a(document).on("click.bs.collapse.data-api",'[data-toggle="collapse"]',function(d){var e=a(this);e.attr("data-target")||d.preventDefault();var f=b(e),g=f.data("bs.collapse"),h=g?"toggle":a.extend({},e.data(),{trigger:this});c.call(f,h)})}(jQuery),+function(a){"use strict";function b(b){b&&3===b.which||(a(e).remove(),a(f).each(function(){var d=a(this),e=c(d),f={relatedTarget:this};e.hasClass("open")&&(e.trigger(b=a.Event("hide.bs.dropdown",f)),b.isDefaultPrevented()||(d.attr("aria-expanded","false"),e.removeClass("open").trigger("hidden.bs.dropdown",f)))}))}function c(b){var c=b.attr("data-target");c||(c=b.attr("href"),c=c&&/#[A-Za-z]/.test(c)&&c.replace(/.*(?=#[^\s]*$)/,""));var d=c&&a(c);return d&&d.length?d:b.parent()}function d(b){return this.each(function(){var c=a(this),d=c.data("bs.dropdown");d||c.data("bs.dropdown",d=new g(this)),"string"==typeof b&&d[b].call(c)})}var e=".dropdown-backdrop",f='[data-toggle="dropdown"]',g=function(b){a(b).on("click.bs.dropdown",this.toggle)};g.VERSION="3.3.2",g.prototype.toggle=function(d){var e=a(this);if(!e.is(".disabled, :disabled")){var f=c(e),g=f.hasClass("open");if(b(),!g){"ontouchstart"in document.documentElement&&!f.closest(".navbar-nav").length&&a('<div class="dropdown-backdrop"/>').insertAfter(a(this)).on("click",b);var h={relatedTarget:this};if(f.trigger(d=a.Event("show.bs.dropdown",h)),d.isDefaultPrevented())return;e.trigger("focus").attr("aria-expanded","true"),f.toggleClass("open").trigger("shown.bs.dropdown",h)}return!1}},g.prototype.keydown=function(b){if(/(38|40|27|32)/.test(b.which)&&!/input|textarea/i.test(b.target.tagName)){var d=a(this);if(b.preventDefault(),b.stopPropagation(),!d.is(".disabled, :disabled")){var e=c(d),g=e.hasClass("open");if(!g&&27!=b.which||g&&27==b.which)return 27==b.which&&e.find(f).trigger("focus"),d.trigger("click");var h=" li:not(.divider):visible a",i=e.find('[role="menu"]'+h+', [role="listbox"]'+h);if(i.length){var j=i.index(b.target);38==b.which&&j>0&&j--,40==b.which&&j<i.length-1&&j++,~j||(j=0),i.eq(j).trigger("focus")}}}};var h=a.fn.dropdown;a.fn.dropdown=d,a.fn.dropdown.Constructor=g,a.fn.dropdown.noConflict=function(){return a.fn.dropdown=h,this},a(document).on("click.bs.dropdown.data-api",b).on("click.bs.dropdown.data-api",".dropdown form",function(a){a.stopPropagation()}).on("click.bs.dropdown.data-api",f,g.prototype.toggle).on("keydown.bs.dropdown.data-api",f,g.prototype.keydown).on("keydown.bs.dropdown.data-api",'[role="menu"]',g.prototype.keydown).on("keydown.bs.dropdown.data-api",'[role="listbox"]',g.prototype.keydown)}(jQuery),+function(a){"use strict";function b(b,d){return this.each(function(){var e=a(this),f=e.data("bs.modal"),g=a.extend({},c.DEFAULTS,e.data(),"object"==typeof b&&b);f||e.data("bs.modal",f=new c(this,g)),"string"==typeof b?f[b](d):g.show&&f.show(d)})}var c=function(b,c){this.options=c,this.$body=a(document.body),this.$element=a(b),this.$backdrop=this.isShown=null,this.scrollbarWidth=0,this.options.remote&&this.$element.find(".modal-content").load(this.options.remote,a.proxy(function(){this.$element.trigger("loaded.bs.modal")},this))};c.VERSION="3.3.2",c.TRANSITION_DURATION=300,c.BACKDROP_TRANSITION_DURATION=150,c.DEFAULTS={backdrop:!0,keyboard:!0,show:!0},c.prototype.toggle=function(a){return this.isShown?this.hide():this.show(a)},c.prototype.show=function(b){var d=this,e=a.Event("show.bs.modal",{relatedTarget:b});this.$element.trigger(e),this.isShown||e.isDefaultPrevented()||(this.isShown=!0,this.checkScrollbar(),this.setScrollbar(),this.$body.addClass("modal-open"),this.escape(),this.resize(),this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',a.proxy(this.hide,this)),this.backdrop(function(){var e=a.support.transition&&d.$element.hasClass("fade");d.$element.parent().length||d.$element.appendTo(d.$body),d.$element.show().scrollTop(0),d.options.backdrop&&d.adjustBackdrop(),d.adjustDialog(),e&&d.$element[0].offsetWidth,d.$element.addClass("in").attr("aria-hidden",!1),d.enforceFocus();var f=a.Event("shown.bs.modal",{relatedTarget:b});e?d.$element.find(".modal-dialog").one("bsTransitionEnd",function(){d.$element.trigger("focus").trigger(f)}).emulateTransitionEnd(c.TRANSITION_DURATION):d.$element.trigger("focus").trigger(f)}))},c.prototype.hide=function(b){b&&b.preventDefault(),b=a.Event("hide.bs.modal"),this.$element.trigger(b),this.isShown&&!b.isDefaultPrevented()&&(this.isShown=!1,this.escape(),this.resize(),a(document).off("focusin.bs.modal"),this.$element.removeClass("in").attr("aria-hidden",!0).off("click.dismiss.bs.modal"),a.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",a.proxy(this.hideModal,this)).emulateTransitionEnd(c.TRANSITION_DURATION):this.hideModal())},c.prototype.enforceFocus=function(){a(document).off("focusin.bs.modal").on("focusin.bs.modal",a.proxy(function(a){this.$element[0]===a.target||this.$element.has(a.target).length||this.$element.trigger("focus")},this))},c.prototype.escape=function(){this.isShown&&this.options.keyboard?this.$element.on("keydown.dismiss.bs.modal",a.proxy(function(a){27==a.which&&this.hide()},this)):this.isShown||this.$element.off("keydown.dismiss.bs.modal")},c.prototype.resize=function(){this.isShown?a(window).on("resize.bs.modal",a.proxy(this.handleUpdate,this)):a(window).off("resize.bs.modal")},c.prototype.hideModal=function(){var a=this;this.$element.hide(),this.backdrop(function(){a.$body.removeClass("modal-open"),a.resetAdjustments(),a.resetScrollbar(),a.$element.trigger("hidden.bs.modal")})},c.prototype.removeBackdrop=function(){this.$backdrop&&this.$backdrop.remove(),this.$backdrop=null},c.prototype.backdrop=function(b){var d=this,e=this.$element.hasClass("fade")?"fade":"";if(this.isShown&&this.options.backdrop){var f=a.support.transition&&e;if(this.$backdrop=a('<div class="modal-backdrop '+e+'" />').prependTo(this.$element).on("click.dismiss.bs.modal",a.proxy(function(a){a.target===a.currentTarget&&("static"==this.options.backdrop?this.$element[0].focus.call(this.$element[0]):this.hide.call(this))},this)),f&&this.$backdrop[0].offsetWidth,this.$backdrop.addClass("in"),!b)return;f?this.$backdrop.one("bsTransitionEnd",b).emulateTransitionEnd(c.BACKDROP_TRANSITION_DURATION):b()}else if(!this.isShown&&this.$backdrop){this.$backdrop.removeClass("in");var g=function(){d.removeBackdrop(),b&&b()};a.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",g).emulateTransitionEnd(c.BACKDROP_TRANSITION_DURATION):g()}else b&&b()},c.prototype.handleUpdate=function(){this.options.backdrop&&this.adjustBackdrop(),this.adjustDialog()},c.prototype.adjustBackdrop=function(){this.$backdrop.css("height",0).css("height",this.$element[0].scrollHeight)},c.prototype.adjustDialog=function(){var a=this.$element[0].scrollHeight>document.documentElement.clientHeight;this.$element.css({paddingLeft:!this.bodyIsOverflowing&&a?this.scrollbarWidth:"",paddingRight:this.bodyIsOverflowing&&!a?this.scrollbarWidth:""})},c.prototype.resetAdjustments=function(){this.$element.css({paddingLeft:"",paddingRight:""})},c.prototype.checkScrollbar=function(){this.bodyIsOverflowing=document.body.scrollHeight>document.documentElement.clientHeight,this.scrollbarWidth=this.measureScrollbar()},c.prototype.setScrollbar=function(){var a=parseInt(this.$body.css("padding-right")||0,10);this.bodyIsOverflowing&&this.$body.css("padding-right",a+this.scrollbarWidth)},c.prototype.resetScrollbar=function(){this.$body.css("padding-right","")},c.prototype.measureScrollbar=function(){var a=document.createElement("div");a.className="modal-scrollbar-measure",this.$body.append(a);var b=a.offsetWidth-a.clientWidth;return this.$body[0].removeChild(a),b};var d=a.fn.modal;a.fn.modal=b,a.fn.modal.Constructor=c,a.fn.modal.noConflict=function(){return a.fn.modal=d,this},a(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',function(c){var d=a(this),e=d.attr("href"),f=a(d.attr("data-target")||e&&e.replace(/.*(?=#[^\s]+$)/,"")),g=f.data("bs.modal")?"toggle":a.extend({remote:!/#/.test(e)&&e},f.data(),d.data());d.is("a")&&c.preventDefault(),f.one("show.bs.modal",function(a){a.isDefaultPrevented()||f.one("hidden.bs.modal",function(){d.is(":visible")&&d.trigger("focus")})}),b.call(f,g,this)})}(jQuery),+function(a){"use strict";function b(b){return this.each(function(){var d=a(this),e=d.data("bs.tooltip"),f="object"==typeof b&&b;(e||"destroy"!=b)&&(e||d.data("bs.tooltip",e=new c(this,f)),"string"==typeof b&&e[b]())})}var c=function(a,b){this.type=this.options=this.enabled=this.timeout=this.hoverState=this.$element=null,this.init("tooltip",a,b)};c.VERSION="3.3.2",c.TRANSITION_DURATION=150,c.DEFAULTS={animation:!0,placement:"top",selector:!1,template:'<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',trigger:"hover focus",title:"",delay:0,html:!1,container:!1,viewport:{selector:"body",padding:0}},c.prototype.init=function(b,c,d){this.enabled=!0,this.type=b,this.$element=a(c),this.options=this.getOptions(d),this.$viewport=this.options.viewport&&a(this.options.viewport.selector||this.options.viewport);for(var e=this.options.trigger.split(" "),f=e.length;f--;){var g=e[f];if("click"==g)this.$element.on("click."+this.type,this.options.selector,a.proxy(this.toggle,this));else if("manual"!=g){var h="hover"==g?"mouseenter":"focusin",i="hover"==g?"mouseleave":"focusout";this.$element.on(h+"."+this.type,this.options.selector,a.proxy(this.enter,this)),this.$element.on(i+"."+this.type,this.options.selector,a.proxy(this.leave,this))}}this.options.selector?this._options=a.extend({},this.options,{trigger:"manual",selector:""}):this.fixTitle()},c.prototype.getDefaults=function(){return c.DEFAULTS},c.prototype.getOptions=function(b){return b=a.extend({},this.getDefaults(),this.$element.data(),b),b.delay&&"number"==typeof b.delay&&(b.delay={show:b.delay,hide:b.delay}),b},c.prototype.getDelegateOptions=function(){var b={},c=this.getDefaults();return this._options&&a.each(this._options,function(a,d){c[a]!=d&&(b[a]=d)}),b},c.prototype.enter=function(b){var c=b instanceof this.constructor?b:a(b.currentTarget).data("bs."+this.type);return c&&c.$tip&&c.$tip.is(":visible")?void(c.hoverState="in"):(c||(c=new this.constructor(b.currentTarget,this.getDelegateOptions()),a(b.currentTarget).data("bs."+this.type,c)),clearTimeout(c.timeout),c.hoverState="in",c.options.delay&&c.options.delay.show?void(c.timeout=setTimeout(function(){"in"==c.hoverState&&c.show()},c.options.delay.show)):c.show())},c.prototype.leave=function(b){var c=b instanceof this.constructor?b:a(b.currentTarget).data("bs."+this.type);return c||(c=new this.constructor(b.currentTarget,this.getDelegateOptions()),a(b.currentTarget).data("bs."+this.type,c)),clearTimeout(c.timeout),c.hoverState="out",c.options.delay&&c.options.delay.hide?void(c.timeout=setTimeout(function(){"out"==c.hoverState&&c.hide()},c.options.delay.hide)):c.hide()},c.prototype.show=function(){var b=a.Event("show.bs."+this.type);if(this.hasContent()&&this.enabled){this.$element.trigger(b);var d=a.contains(this.$element[0].ownerDocument.documentElement,this.$element[0]);if(b.isDefaultPrevented()||!d)return;var e=this,f=this.tip(),g=this.getUID(this.type);this.setContent(),f.attr("id",g),this.$element.attr("aria-describedby",g),this.options.animation&&f.addClass("fade");var h="function"==typeof this.options.placement?this.options.placement.call(this,f[0],this.$element[0]):this.options.placement,i=/\s?auto?\s?/i,j=i.test(h);j&&(h=h.replace(i,"")||"top"),f.detach().css({top:0,left:0,display:"block"}).addClass(h).data("bs."+this.type,this),this.options.container?f.appendTo(this.options.container):f.insertAfter(this.$element);var k=this.getPosition(),l=f[0].offsetWidth,m=f[0].offsetHeight;if(j){var n=h,o=this.options.container?a(this.options.container):this.$element.parent(),p=this.getPosition(o);h="bottom"==h&&k.bottom+m>p.bottom?"top":"top"==h&&k.top-m<p.top?"bottom":"right"==h&&k.right+l>p.width?"left":"left"==h&&k.left-l<p.left?"right":h,f.removeClass(n).addClass(h)}var q=this.getCalculatedOffset(h,k,l,m);this.applyPlacement(q,h);var r=function(){var a=e.hoverState;e.$element.trigger("shown.bs."+e.type),e.hoverState=null,"out"==a&&e.leave(e)};a.support.transition&&this.$tip.hasClass("fade")?f.one("bsTransitionEnd",r).emulateTransitionEnd(c.TRANSITION_DURATION):r()}},c.prototype.applyPlacement=function(b,c){var d=this.tip(),e=d[0].offsetWidth,f=d[0].offsetHeight,g=parseInt(d.css("margin-top"),10),h=parseInt(d.css("margin-left"),10);isNaN(g)&&(g=0),isNaN(h)&&(h=0),b.top=b.top+g,b.left=b.left+h,a.offset.setOffset(d[0],a.extend({using:function(a){d.css({top:Math.round(a.top),left:Math.round(a.left)})}},b),0),d.addClass("in");var i=d[0].offsetWidth,j=d[0].offsetHeight;"top"==c&&j!=f&&(b.top=b.top+f-j);var k=this.getViewportAdjustedDelta(c,b,i,j);k.left?b.left+=k.left:b.top+=k.top;var l=/top|bottom/.test(c),m=l?2*k.left-e+i:2*k.top-f+j,n=l?"offsetWidth":"offsetHeight";d.offset(b),this.replaceArrow(m,d[0][n],l)},c.prototype.replaceArrow=function(a,b,c){this.arrow().css(c?"left":"top",50*(1-a/b)+"%").css(c?"top":"left","")},c.prototype.setContent=function(){var a=this.tip(),b=this.getTitle();a.find(".tooltip-inner")[this.options.html?"html":"text"](b),a.removeClass("fade in top bottom left right")},c.prototype.hide=function(b){function d(){"in"!=e.hoverState&&f.detach(),e.$element.removeAttr("aria-describedby").trigger("hidden.bs."+e.type),b&&b()}var e=this,f=this.tip(),g=a.Event("hide.bs."+this.type);return this.$element.trigger(g),g.isDefaultPrevented()?void 0:(f.removeClass("in"),a.support.transition&&this.$tip.hasClass("fade")?f.one("bsTransitionEnd",d).emulateTransitionEnd(c.TRANSITION_DURATION):d(),this.hoverState=null,this)},c.prototype.fixTitle=function(){var a=this.$element;(a.attr("title")||"string"!=typeof a.attr("data-original-title"))&&a.attr("data-original-title",a.attr("title")||"").attr("title","")},c.prototype.hasContent=function(){return this.getTitle()},c.prototype.getPosition=function(b){b=b||this.$element;var c=b[0],d="BODY"==c.tagName,e=c.getBoundingClientRect();null==e.width&&(e=a.extend({},e,{width:e.right-e.left,height:e.bottom-e.top}));var f=d?{top:0,left:0}:b.offset(),g={scroll:d?document.documentElement.scrollTop||document.body.scrollTop:b.scrollTop()},h=d?{width:a(window).width(),height:a(window).height()}:null;return a.extend({},e,g,h,f)},c.prototype.getCalculatedOffset=function(a,b,c,d){return"bottom"==a?{top:b.top+b.height,left:b.left+b.width/2-c/2}:"top"==a?{top:b.top-d,left:b.left+b.width/2-c/2}:"left"==a?{top:b.top+b.height/2-d/2,left:b.left-c}:{top:b.top+b.height/2-d/2,left:b.left+b.width}},c.prototype.getViewportAdjustedDelta=function(a,b,c,d){var e={top:0,left:0};if(!this.$viewport)return e;var f=this.options.viewport&&this.options.viewport.padding||0,g=this.getPosition(this.$viewport);if(/right|left/.test(a)){var h=b.top-f-g.scroll,i=b.top+f-g.scroll+d;h<g.top?e.top=g.top-h:i>g.top+g.height&&(e.top=g.top+g.height-i)}else{var j=b.left-f,k=b.left+f+c;j<g.left?e.left=g.left-j:k>g.width&&(e.left=g.left+g.width-k)}return e},c.prototype.getTitle=function(){var a,b=this.$element,c=this.options;return a=b.attr("data-original-title")||("function"==typeof c.title?c.title.call(b[0]):c.title)},c.prototype.getUID=function(a){do a+=~~(1e6*Math.random());while(document.getElementById(a));return a},c.prototype.tip=function(){return this.$tip=this.$tip||a(this.options.template)},c.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".tooltip-arrow")},c.prototype.enable=function(){this.enabled=!0},c.prototype.disable=function(){this.enabled=!1},c.prototype.toggleEnabled=function(){this.enabled=!this.enabled},c.prototype.toggle=function(b){var c=this;b&&(c=a(b.currentTarget).data("bs."+this.type),c||(c=new this.constructor(b.currentTarget,this.getDelegateOptions()),a(b.currentTarget).data("bs."+this.type,c))),c.tip().hasClass("in")?c.leave(c):c.enter(c)},c.prototype.destroy=function(){var a=this;clearTimeout(this.timeout),this.hide(function(){a.$element.off("."+a.type).removeData("bs."+a.type)})};var d=a.fn.tooltip;a.fn.tooltip=b,a.fn.tooltip.Constructor=c,a.fn.tooltip.noConflict=function(){return a.fn.tooltip=d,this}}(jQuery),+function(a){"use strict";function b(b){return this.each(function(){var d=a(this),e=d.data("bs.popover"),f="object"==typeof b&&b;(e||"destroy"!=b)&&(e||d.data("bs.popover",e=new c(this,f)),"string"==typeof b&&e[b]())})}var c=function(a,b){this.init("popover",a,b)};if(!a.fn.tooltip)throw new Error("Popover%20requires%20tooltip.html");c.VERSION="3.3.2",c.DEFAULTS=a.extend({},a.fn.tooltip.Constructor.DEFAULTS,{placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'}),c.prototype=a.extend({},a.fn.tooltip.Constructor.prototype),c.prototype.constructor=c,c.prototype.getDefaults=function(){return c.DEFAULTS},c.prototype.setContent=function(){var a=this.tip(),b=this.getTitle(),c=this.getContent();a.find(".popover-title")[this.options.html?"html":"text"](b),a.find(".popover-content").children().detach().end()[this.options.html?"string"==typeof c?"html":"append":"text"](c),a.removeClass("fade top bottom left right in"),a.find(".popover-title").html()||a.find(".popover-title").hide()},c.prototype.hasContent=function(){return this.getTitle()||this.getContent()},c.prototype.getContent=function(){var a=this.$element,b=this.options;return a.attr("data-content")||("function"==typeof b.content?b.content.call(a[0]):b.content)},c.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".arrow")},c.prototype.tip=function(){return this.$tip||(this.$tip=a(this.options.template)),this.$tip};var d=a.fn.popover;a.fn.popover=b,a.fn.popover.Constructor=c,a.fn.popover.noConflict=function(){return a.fn.popover=d,this}}(jQuery),+function(a){"use strict";function b(c,d){var e=a.proxy(this.process,this);this.$body=a("body"),this.$scrollElement=a(a(c).is("body")?window:c),this.options=a.extend({},b.DEFAULTS,d),this.selector=(this.options.target||"")+" .nav li > a",this.offsets=[],this.targets=[],this.activeTarget=null,this.scrollHeight=0,this.$scrollElement.on("scroll.bs.scrollspy",e),this.refresh(),this.process()}function c(c){return this.each(function(){var d=a(this),e=d.data("bs.scrollspy"),f="object"==typeof c&&c;e||d.data("bs.scrollspy",e=new b(this,f)),"string"==typeof c&&e[c]()})}b.VERSION="3.3.2",b.DEFAULTS={offset:10},b.prototype.getScrollHeight=function(){return this.$scrollElement[0].scrollHeight||Math.max(this.$body[0].scrollHeight,document.documentElement.scrollHeight)},b.prototype.refresh=function(){var b="offset",c=0;a.isWindow(this.$scrollElement[0])||(b="position",c=this.$scrollElement.scrollTop()),this.offsets=[],this.targets=[],this.scrollHeight=this.getScrollHeight();var d=this;this.$body.find(this.selector).map(function(){var d=a(this),e=d.data("target")||d.attr("href"),f=/^#./.test(e)&&a(e);return f&&f.length&&f.is(":visible")&&[[f[b]().top+c,e]]||null}).sort(function(a,b){return a[0]-b[0]}).each(function(){d.offsets.push(this[0]),d.targets.push(this[1])})},b.prototype.process=function(){var a,b=this.$scrollElement.scrollTop()+this.options.offset,c=this.getScrollHeight(),d=this.options.offset+c-this.$scrollElement.height(),e=this.offsets,f=this.targets,g=this.activeTarget;if(this.scrollHeight!=c&&this.refresh(),b>=d)return g!=(a=f[f.length-1])&&this.activate(a);if(g&&b<e[0])return this.activeTarget=null,this.clear();for(a=e.length;a--;)g!=f[a]&&b>=e[a]&&(!e[a+1]||b<=e[a+1])&&this.activate(f[a])},b.prototype.activate=function(b){this.activeTarget=b,this.clear();var c=this.selector+'[data-target="'+b+'"],'+this.selector+'[href="'+b+'"]',d=a(c).parents("li").addClass("active");d.parent(".dropdown-menu").length&&(d=d.closest("li.dropdown").addClass("active")),d.trigger("activate.bs.scrollspy")},b.prototype.clear=function(){a(this.selector).parentsUntil(this.options.target,".active").removeClass("active")};var d=a.fn.scrollspy;a.fn.scrollspy=c,a.fn.scrollspy.Constructor=b,a.fn.scrollspy.noConflict=function(){return a.fn.scrollspy=d,this},a(window).on("load.bs.scrollspy.data-api",function(){a('[data-spy="scroll"]').each(function(){var b=a(this);c.call(b,b.data())})})}(jQuery),+function(a){"use strict";function b(b){return this.each(function(){var d=a(this),e=d.data("bs.tab");e||d.data("bs.tab",e=new c(this)),"string"==typeof b&&e[b]()})}var c=function(b){this.element=a(b)};c.VERSION="3.3.2",c.TRANSITION_DURATION=150,c.prototype.show=function(){var b=this.element,c=b.closest("ul:not(.dropdown-menu)"),d=b.data("target");if(d||(d=b.attr("href"),d=d&&d.replace(/.*(?=#[^\s]*$)/,"")),!b.parent("li").hasClass("active")){var e=c.find(".active:last a"),f=a.Event("hide.bs.tab",{relatedTarget:b[0]}),g=a.Event("show.bs.tab",{relatedTarget:e[0]});if(e.trigger(f),b.trigger(g),!g.isDefaultPrevented()&&!f.isDefaultPrevented()){var h=a(d);this.activate(b.closest("li"),c),this.activate(h,h.parent(),function(){e.trigger({type:"hidden.bs.tab",relatedTarget:b[0]}),b.trigger({type:"shown.bs.tab",relatedTarget:e[0]})})}}},c.prototype.activate=function(b,d,e){function f(){g.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!1),b.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded",!0),h?(b[0].offsetWidth,b.addClass("in")):b.removeClass("fade"),b.parent(".dropdown-menu")&&b.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!0),e&&e()
/* 7 */ }var g=d.find("> .active"),h=e&&a.support.transition&&(g.length&&g.hasClass("fade")||!!d.find("> .fade").length);g.length&&h?g.one("bsTransitionEnd",f).emulateTransitionEnd(c.TRANSITION_DURATION):f(),g.removeClass("in")};var d=a.fn.tab;a.fn.tab=b,a.fn.tab.Constructor=c,a.fn.tab.noConflict=function(){return a.fn.tab=d,this};var e=function(c){c.preventDefault(),b.call(a(this),"show")};a(document).on("click.bs.tab.data-api",'[data-toggle="tab"]',e).on("click.bs.tab.data-api",'[data-toggle="pill"]',e)}(jQuery),+function(a){"use strict";function b(b){return this.each(function(){var d=a(this),e=d.data("bs.affix"),f="object"==typeof b&&b;e||d.data("bs.affix",e=new c(this,f)),"string"==typeof b&&e[b]()})}var c=function(b,d){this.options=a.extend({},c.DEFAULTS,d),this.$target=a(this.options.target).on("scroll.bs.affix.data-api",a.proxy(this.checkPosition,this)).on("click.bs.affix.data-api",a.proxy(this.checkPositionWithEventLoop,this)),this.$element=a(b),this.affixed=this.unpin=this.pinnedOffset=null,this.checkPosition()};c.VERSION="3.3.2",c.RESET="affix affix-top affix-bottom",c.DEFAULTS={offset:0,target:window},c.prototype.getState=function(a,b,c,d){var e=this.$target.scrollTop(),f=this.$element.offset(),g=this.$target.height();if(null!=c&&"top"==this.affixed)return c>e?"top":!1;if("bottom"==this.affixed)return null!=c?e+this.unpin<=f.top?!1:"bottom":a-d>=e+g?!1:"bottom";var h=null==this.affixed,i=h?e:f.top,j=h?g:b;return null!=c&&c>=e?"top":null!=d&&i+j>=a-d?"bottom":!1},c.prototype.getPinnedOffset=function(){if(this.pinnedOffset)return this.pinnedOffset;this.$element.removeClass(c.RESET).addClass("affix");var a=this.$target.scrollTop(),b=this.$element.offset();return this.pinnedOffset=b.top-a},c.prototype.checkPositionWithEventLoop=function(){setTimeout(a.proxy(this.checkPosition,this),1)},c.prototype.checkPosition=function(){if(this.$element.is(":visible")){var b=this.$element.height(),d=this.options.offset,e=d.top,f=d.bottom,g=a("body").height();"object"!=typeof d&&(f=e=d),"function"==typeof e&&(e=d.top(this.$element)),"function"==typeof f&&(f=d.bottom(this.$element));var h=this.getState(g,b,e,f);if(this.affixed!=h){null!=this.unpin&&this.$element.css("top","");var i="affix"+(h?"-"+h:""),j=a.Event(i+".bs.affix");if(this.$element.trigger(j),j.isDefaultPrevented())return;this.affixed=h,this.unpin="bottom"==h?this.getPinnedOffset():null,this.$element.removeClass(c.RESET).addClass(i).trigger(i.replace("affix","affixed")+".bs.affix")}"bottom"==h&&this.$element.offset({top:g-b-f})}};var d=a.fn.affix;a.fn.affix=b,a.fn.affix.Constructor=c,a.fn.affix.noConflict=function(){return a.fn.affix=d,this},a(window).on("load",function(){a('[data-spy="affix"]').each(function(){var c=a(this),d=c.data();d.offset=d.offset||{},null!=d.offsetBottom&&(d.offset.bottom=d.offsetBottom),null!=d.offsetTop&&(d.offset.top=d.offsetTop),b.call(c,d)})})}(jQuery);

;
/* libs.js */

/* 1  */ // jQuery Cookie Plugin v1.4.1 | (c)2014 Klaus Hartl 
/* 2  */ (function(a){if(typeof define==="function"&&define.amd){define(["jquery"],a);}else{if(typeof exports==="object"){a(require("jquery"));}else{a(jQuery);}}}(function(f){var a=/\+/g;function d(i){return b.raw?i:encodeURIComponent(i);}function g(i){return b.raw?i:decodeURIComponent(i);}function h(i){return d(b.json?JSON.stringify(i):String(i));}function c(i){if(i.indexOf('"')===0){i=i.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\");}try{i=decodeURIComponent(i.replace(a," "));return b.json?JSON.parse(i):i;}catch(j){}}function e(j,i){var k=b.raw?j:c(j);return f.isFunction(i)?i(k):k;}var b=f.cookie=function(q,p,v){if(arguments.length>1&&!f.isFunction(p)){v=f.extend({},b.defaults,v);if(typeof v.expires==="number"){var r=v.expires,u=v.expires=new Date();u.setTime(+u+r*86400000);}return(document.cookie=[d(q),"=",h(p),v.expires?"; expires="+v.expires.toUTCString():"",v.path?"; path="+v.path:"",v.domain?"; domain="+v.domain:"",v.secure?"; secure":""].join(""));}var w=q?undefined:{};var s=document.cookie?document.cookie.split("; "):[];for(var o=0,m=s.length;o<m;o++){var n=s[o].split("=");var j=g(n.shift());var k=n.join("=");if(q&&q===j){w=e(k,p);break;}if(!q&&(k=e(k))!==undefined){w[j]=k;}}return w;};b.defaults={};f.removeCookie=function(j,i){if(f.cookie(j)===undefined){return false;}f.cookie(j,"",f.extend({},i,{expires:-1}));return !f.cookie(j);};}));
/* 3  */ 
/* 4  */ //jQuery elevateZoom 3.0.8
/* 5  */ "function"!=typeof Object.create&&(Object.create=function(o){function i(){}return i.prototype=o,new i}),function(o){var i={init:function(i,t){var e=this;e.elem=t,e.$elem=o(t),e.imageSrc=e.$elem.data("zoom-image")?e.$elem.data("zoom-image"):e.$elem.attr("src"),e.options=o.extend({},o.fn.elevateZoom.options,i),e.options.tint&&(e.options.lensColour="none",e.options.lensOpacity="1"),"inner"==e.options.zoomType&&(e.options.showLens=!1),e.$elem.parent().removeAttr("title").removeAttr("alt"),e.zoomImage=e.imageSrc,e.refresh(1),o("#"+e.options.gallery+" a").click(function(i){return e.options.galleryActiveClass&&(o("#"+e.options.gallery+" a").removeClass(e.options.galleryActiveClass),o(this).addClass(e.options.galleryActiveClass)),i.preventDefault(),e.zoomImagePre=o(this).data(o(this).data("zoom-image")?"zoom-image":"image"),e.swaptheimage(o(this).data("image"),e.zoomImagePre),!1})},refresh:function(o){var i=this;setTimeout(function(){i.fetch(i.imageSrc)},o||i.options.refresh)},fetch:function(o){var i=this,t=new Image;t.onload=function(){i.largeWidth=t.width,i.largeHeight=t.height,i.startZoom(),i.currentImage=i.imageSrc,i.options.onZoomedImageLoaded(i.$elem)},t.src=o},startZoom:function(){var i=this;if(i.nzWidth=i.$elem.width(),i.nzHeight=i.$elem.height(),i.isWindowActive=!1,i.isLensActive=!1,i.isTintActive=!1,i.overWindow=!1,i.options.imageCrossfade&&(i.zoomWrap=i.$elem.wrap('<div style="height:'+i.nzHeight+"px;width:"+i.nzWidth+'px;" class="zoomWrapper" />'),i.$elem.css("position","absolute")),i.zoomLock=1,i.scrollingLock=!1,i.changeBgSize=!1,i.currentZoomLevel=i.options.zoomLevel,i.nzOffset=i.$elem.offset(),i.widthRatio=i.largeWidth/i.currentZoomLevel/i.nzWidth,i.heightRatio=i.largeHeight/i.currentZoomLevel/i.nzHeight,"window"==i.options.zoomType&&(i.zoomWindowStyle="overflow: hidden;background-position: 0px 0px;text-align:center;background-color: "+String(i.options.zoomWindowBgColour)+";width: "+String(i.options.zoomWindowWidth)+"px;height: "+String(i.options.zoomWindowHeight)+"px;float: left;background-size: "+i.largeWidth/i.currentZoomLevel+"px "+i.largeHeight/i.currentZoomLevel+"px;display: none;z-index:100;border: "+String(i.options.borderSize)+"px solid "+i.options.borderColour+";background-repeat: no-repeat;position: absolute;"),"inner"==i.options.zoomType){var t=i.$elem.css("border-left-width");i.zoomWindowStyle="overflow: hidden;margin-left: "+String(t)+";margin-top: "+String(t)+";background-position: 0px 0px;width: "+String(i.nzWidth)+"px;height: "+String(i.nzHeight)+"px;float: left;display: none;cursor:"+i.options.cursor+";px solid "+i.options.borderColour+";background-repeat: no-repeat;position: absolute;"}"window"==i.options.zoomType&&(lensHeight=i.nzHeight<i.options.zoomWindowWidth/i.widthRatio?i.nzHeight:String(i.options.zoomWindowHeight/i.heightRatio),lensWidth=i.largeWidth<i.options.zoomWindowWidth?i.nzWidth:i.options.zoomWindowWidth/i.widthRatio,i.lensStyle="background-position: 0px 0px;width: "+String(i.options.zoomWindowWidth/i.widthRatio)+"px;height: "+String(i.options.zoomWindowHeight/i.heightRatio)+"px;float: right;display: none;overflow: hidden;z-index: 999;-webkit-transform: translateZ(0);opacity:"+i.options.lensOpacity+";filter: alpha(opacity = "+100*i.options.lensOpacity+"); zoom:1;width:"+lensWidth+"px;height:"+lensHeight+"px;background-color:"+i.options.lensColour+";cursor:"+i.options.cursor+";border: "+i.options.lensBorderSize+"px solid "+i.options.lensBorderColour+";background-repeat: no-repeat;position: absolute;"),i.tintStyle="display: block;position: absolute;background-color: "+i.options.tintColour+";filter:alpha(opacity=0);opacity: 0;width: "+i.nzWidth+"px;height: "+i.nzHeight+"px;",i.lensRound="","lens"==i.options.zoomType&&(i.lensStyle="background-position: 0px 0px;float: left;display: none;border: "+String(i.options.borderSize)+"px solid "+i.options.borderColour+";width:"+String(i.options.lensSize)+"px;height:"+String(i.options.lensSize)+"px;background-repeat: no-repeat;position: absolute;"),"round"==i.options.lensShape&&(i.lensRound="border-top-left-radius: "+String(i.options.lensSize/2+i.options.borderSize)+"px;border-top-right-radius: "+String(i.options.lensSize/2+i.options.borderSize)+"px;border-bottom-left-radius: "+String(i.options.lensSize/2+i.options.borderSize)+"px;border-bottom-right-radius: "+String(i.options.lensSize/2+i.options.borderSize)+"px;"),i.zoomContainer=o('<div class="zoomContainer" style="-webkit-transform: translateZ(0);position:absolute;left:'+i.nzOffset.left+"px;top:"+i.nzOffset.top+"px;height:"+i.nzHeight+"px;width:"+i.nzWidth+'px;"></div>'),o("body").append(i.zoomContainer),i.options.containLensZoom&&"lens"==i.options.zoomType&&i.zoomContainer.css("overflow","hidden"),"inner"!=i.options.zoomType&&(i.zoomLens=o("<div class='zoomLens' style='"+i.lensStyle+i.lensRound+"'>&nbsp;</div>").appendTo(i.zoomContainer).click(function(){i.$elem.trigger("click")}),i.options.tint&&(i.tintContainer=o("<div/>").addClass("tintContainer"),i.zoomTint=o("<div class='zoomTint' style='"+i.tintStyle+"'></div>"),i.zoomLens.wrap(i.tintContainer),i.zoomTintcss=i.zoomLens.after(i.zoomTint),i.zoomTintImage=o('<img style="position: absolute; left: 0px; top: 0px; max-width: none; width: '+i.nzWidth+"px; height: "+i.nzHeight+'px;" src="'+i.imageSrc+'">').appendTo(i.zoomLens).click(function(){i.$elem.trigger("click")}))),i.zoomWindow=isNaN(i.options.zoomWindowPosition)?o("<div style='z-index:999;left:"+i.windowOffsetLeft+"px;top:"+i.windowOffsetTop+"px;"+i.zoomWindowStyle+"' class='zoomWindow'>&nbsp;</div>").appendTo("body").click(function(){i.$elem.trigger("click")}):o("<div style='z-index:999;left:"+i.windowOffsetLeft+"px;top:"+i.windowOffsetTop+"px;"+i.zoomWindowStyle+"' class='zoomWindow'>&nbsp;</div>").appendTo(i.zoomContainer).click(function(){i.$elem.trigger("click")}),i.zoomWindowContainer=o("<div/>").addClass("zoomWindowContainer").css("width",i.options.zoomWindowWidth),i.zoomWindow.wrap(i.zoomWindowContainer),"lens"==i.options.zoomType&&i.zoomLens.css({backgroundImage:"url('"+i.imageSrc+"')"}),"window"==i.options.zoomType&&i.zoomWindow.css({backgroundImage:"url('"+i.imageSrc+"')"}),"inner"==i.options.zoomType&&i.zoomWindow.css({backgroundImage:"url('"+i.imageSrc+"')"}),i.$elem.bind("touchmove",function(o){o.preventDefault(),i.setPosition(o.originalEvent.touches[0]||o.originalEvent.changedTouches[0])}),i.zoomContainer.bind("touchmove",function(o){"inner"==i.options.zoomType&&i.showHideWindow("show"),o.preventDefault(),i.setPosition(o.originalEvent.touches[0]||o.originalEvent.changedTouches[0])}),i.zoomContainer.bind("touchend",function(){i.showHideWindow("hide"),i.options.showLens&&i.showHideLens("hide"),i.options.tint&&"inner"!=i.options.zoomType&&i.showHideTint("hide")}),i.$elem.bind("touchend",function(){i.showHideWindow("hide"),i.options.showLens&&i.showHideLens("hide"),i.options.tint&&"inner"!=i.options.zoomType&&i.showHideTint("hide")}),i.options.showLens&&(i.zoomLens.bind("touchmove",function(o){o.preventDefault(),i.setPosition(o.originalEvent.touches[0]||o.originalEvent.changedTouches[0])}),i.zoomLens.bind("touchend",function(){i.showHideWindow("hide"),i.options.showLens&&i.showHideLens("hide"),i.options.tint&&"inner"!=i.options.zoomType&&i.showHideTint("hide")})),i.$elem.bind("mousemove",function(o){0==i.overWindow&&i.setElements("show"),(i.lastX!==o.clientX||i.lastY!==o.clientY)&&(i.setPosition(o),i.currentLoc=o),i.lastX=o.clientX,i.lastY=o.clientY}),i.zoomContainer.bind("mousemove",function(o){0==i.overWindow&&i.setElements("show"),(i.lastX!==o.clientX||i.lastY!==o.clientY)&&(i.setPosition(o),i.currentLoc=o),i.lastX=o.clientX,i.lastY=o.clientY}),"inner"!=i.options.zoomType&&i.zoomLens.bind("mousemove",function(o){(i.lastX!==o.clientX||i.lastY!==o.clientY)&&(i.setPosition(o),i.currentLoc=o),i.lastX=o.clientX,i.lastY=o.clientY}),i.options.tint&&"inner"!=i.options.zoomType&&i.zoomTint.bind("mousemove",function(o){(i.lastX!==o.clientX||i.lastY!==o.clientY)&&(i.setPosition(o),i.currentLoc=o),i.lastX=o.clientX,i.lastY=o.clientY}),"inner"==i.options.zoomType&&i.zoomWindow.bind("mousemove",function(o){(i.lastX!==o.clientX||i.lastY!==o.clientY)&&(i.setPosition(o),i.currentLoc=o),i.lastX=o.clientX,i.lastY=o.clientY}),i.zoomContainer.add(i.$elem).mouseenter(function(){0==i.overWindow&&i.setElements("show")}).mouseleave(function(){i.scrollLock||i.setElements("hide")}),"inner"!=i.options.zoomType&&i.zoomWindow.mouseenter(function(){i.overWindow=!0,i.setElements("hide")}).mouseleave(function(){i.overWindow=!1}),i.minZoomLevel=i.options.minZoomLevel?i.options.minZoomLevel:2*i.options.scrollZoomIncrement,i.options.scrollZoom&&i.zoomContainer.add(i.$elem).bind("mousewheel DOMMouseScroll MozMousePixelScroll",function(t){i.scrollLock=!0,clearTimeout(o.data(this,"timer")),o.data(this,"timer",setTimeout(function(){i.scrollLock=!1},250));var e=t.originalEvent.wheelDelta||-1*t.originalEvent.detail;return t.stopImmediatePropagation(),t.stopPropagation(),t.preventDefault(),e/120>0?i.currentZoomLevel>=i.minZoomLevel&&i.changeZoomLevel(i.currentZoomLevel-i.options.scrollZoomIncrement):i.options.maxZoomLevel?i.currentZoomLevel<=i.options.maxZoomLevel&&i.changeZoomLevel(parseFloat(i.currentZoomLevel)+i.options.scrollZoomIncrement):i.changeZoomLevel(parseFloat(i.currentZoomLevel)+i.options.scrollZoomIncrement),!1})},setElements:function(o){return this.options.zoomEnabled?("show"==o&&this.isWindowSet&&("inner"==this.options.zoomType&&this.showHideWindow("show"),"window"==this.options.zoomType&&this.showHideWindow("show"),this.options.showLens&&this.showHideLens("show"),this.options.tint&&"inner"!=this.options.zoomType&&this.showHideTint("show")),void("hide"==o&&("window"==this.options.zoomType&&this.showHideWindow("hide"),this.options.tint||this.showHideWindow("hide"),this.options.showLens&&this.showHideLens("hide"),this.options.tint&&this.showHideTint("hide")))):!1},setPosition:function(o){return this.options.zoomEnabled?(this.nzHeight=this.$elem.height(),this.nzWidth=this.$elem.width(),this.nzOffset=this.$elem.offset(),this.options.tint&&"inner"!=this.options.zoomType&&(this.zoomTint.css({top:0}),this.zoomTint.css({left:0})),this.options.responsive&&!this.options.scrollZoom&&this.options.showLens&&(lensHeight=this.nzHeight<this.options.zoomWindowWidth/this.widthRatio?this.nzHeight:String(this.options.zoomWindowHeight/this.heightRatio),lensWidth=this.largeWidth<this.options.zoomWindowWidth?this.nzWidth:this.options.zoomWindowWidth/this.widthRatio,this.widthRatio=this.largeWidth/this.nzWidth,this.heightRatio=this.largeHeight/this.nzHeight,"lens"!=this.options.zoomType&&(lensHeight=this.nzHeight<this.options.zoomWindowWidth/this.widthRatio?this.nzHeight:String(this.options.zoomWindowHeight/this.heightRatio),lensWidth=this.options.zoomWindowWidth<this.options.zoomWindowWidth?this.nzWidth:this.options.zoomWindowWidth/this.widthRatio,this.zoomLens.css("width",lensWidth),this.zoomLens.css("height",lensHeight),this.options.tint&&(this.zoomTintImage.css("width",this.nzWidth),this.zoomTintImage.css("height",this.nzHeight))),"lens"==this.options.zoomType&&this.zoomLens.css({width:String(this.options.lensSize)+"px",height:String(this.options.lensSize)+"px"})),this.zoomContainer.css({top:this.nzOffset.top}),this.zoomContainer.css({left:this.nzOffset.left}),this.mouseLeft=parseInt(o.pageX-this.nzOffset.left),this.mouseTop=parseInt(o.pageY-this.nzOffset.top),"window"==this.options.zoomType&&(this.Etoppos=this.mouseTop<this.zoomLens.height()/2,this.Eboppos=this.mouseTop>this.nzHeight-this.zoomLens.height()/2-2*this.options.lensBorderSize,this.Eloppos=this.mouseLeft<0+this.zoomLens.width()/2,this.Eroppos=this.mouseLeft>this.nzWidth-this.zoomLens.width()/2-2*this.options.lensBorderSize),"inner"==this.options.zoomType&&(this.Etoppos=this.mouseTop<this.nzHeight/2/this.heightRatio,this.Eboppos=this.mouseTop>this.nzHeight-this.nzHeight/2/this.heightRatio,this.Eloppos=this.mouseLeft<0+this.nzWidth/2/this.widthRatio,this.Eroppos=this.mouseLeft>this.nzWidth-this.nzWidth/2/this.widthRatio-2*this.options.lensBorderSize),void(0>=this.mouseLeft||0>this.mouseTop||this.mouseLeft>this.nzWidth||this.mouseTop>this.nzHeight?this.setElements("hide"):(this.options.showLens&&(this.lensLeftPos=String(this.mouseLeft-this.zoomLens.width()/2),this.lensTopPos=String(this.mouseTop-this.zoomLens.height()/2)),this.Etoppos&&(this.lensTopPos=0),this.Eloppos&&(this.tintpos=this.lensLeftPos=this.windowLeftPos=0),"window"==this.options.zoomType&&(this.Eboppos&&(this.lensTopPos=Math.max(this.nzHeight-this.zoomLens.height()-2*this.options.lensBorderSize,0)),this.Eroppos&&(this.lensLeftPos=this.nzWidth-this.zoomLens.width()-2*this.options.lensBorderSize)),"inner"==this.options.zoomType&&(this.Eboppos&&(this.lensTopPos=Math.max(this.nzHeight-2*this.options.lensBorderSize,0)),this.Eroppos&&(this.lensLeftPos=this.nzWidth-this.nzWidth-2*this.options.lensBorderSize)),"lens"==this.options.zoomType&&(this.windowLeftPos=String(-1*((o.pageX-this.nzOffset.left)*this.widthRatio-this.zoomLens.width()/2)),this.windowTopPos=String(-1*((o.pageY-this.nzOffset.top)*this.heightRatio-this.zoomLens.height()/2)),this.zoomLens.css({backgroundPosition:this.windowLeftPos+"px "+this.windowTopPos+"px"}),this.changeBgSize&&(this.nzHeight>this.nzWidth?("lens"==this.options.zoomType&&this.zoomLens.css({"background-size":this.largeWidth/this.newvalueheight+"px "+this.largeHeight/this.newvalueheight+"px"}),this.zoomWindow.css({"background-size":this.largeWidth/this.newvalueheight+"px "+this.largeHeight/this.newvalueheight+"px"})):("lens"==this.options.zoomType&&this.zoomLens.css({"background-size":this.largeWidth/this.newvaluewidth+"px "+this.largeHeight/this.newvaluewidth+"px"}),this.zoomWindow.css({"background-size":this.largeWidth/this.newvaluewidth+"px "+this.largeHeight/this.newvaluewidth+"px"})),this.changeBgSize=!1),this.setWindowPostition(o)),this.options.tint&&"inner"!=this.options.zoomType&&this.setTintPosition(o),"window"==this.options.zoomType&&this.setWindowPostition(o),"inner"==this.options.zoomType&&this.setWindowPostition(o),this.options.showLens&&(this.fullwidth&&"lens"!=this.options.zoomType&&(this.lensLeftPos=0),this.zoomLens.css({left:this.lensLeftPos+"px",top:this.lensTopPos+"px"}))))):!1},showHideWindow:function(o){"show"!=o||this.isWindowActive||(this.options.zoomWindowFadeIn?this.zoomWindow.stop(!0,!0,!1).fadeIn(this.options.zoomWindowFadeIn):this.zoomWindow.show(),this.isWindowActive=!0),"hide"==o&&this.isWindowActive&&(this.options.zoomWindowFadeOut?this.zoomWindow.stop(!0,!0).fadeOut(this.options.zoomWindowFadeOut):this.zoomWindow.hide(),this.isWindowActive=!1)},showHideLens:function(o){"show"!=o||this.isLensActive||(this.options.lensFadeIn?this.zoomLens.stop(!0,!0,!1).fadeIn(this.options.lensFadeIn):this.zoomLens.show(),this.isLensActive=!0),"hide"==o&&this.isLensActive&&(this.options.lensFadeOut?this.zoomLens.stop(!0,!0).fadeOut(this.options.lensFadeOut):this.zoomLens.hide(),this.isLensActive=!1)},showHideTint:function(o){"show"!=o||this.isTintActive||(this.options.zoomTintFadeIn?this.zoomTint.css({opacity:this.options.tintOpacity}).animate().stop(!0,!0).fadeIn("slow"):(this.zoomTint.css({opacity:this.options.tintOpacity}).animate(),this.zoomTint.show()),this.isTintActive=!0),"hide"==o&&this.isTintActive&&(this.options.zoomTintFadeOut?this.zoomTint.stop(!0,!0).fadeOut(this.options.zoomTintFadeOut):this.zoomTint.hide(),this.isTintActive=!1)},setLensPostition:function(){},setWindowPostition:function(i){var t=this;if(isNaN(t.options.zoomWindowPosition))t.externalContainer=o("#"+t.options.zoomWindowPosition),t.externalContainerWidth=t.externalContainer.width(),t.externalContainerHeight=t.externalContainer.height(),t.externalContainerOffset=t.externalContainer.offset(),t.windowOffsetTop=t.externalContainerOffset.top,t.windowOffsetLeft=t.externalContainerOffset.left;else switch(t.options.zoomWindowPosition){case 1:t.windowOffsetTop=t.options.zoomWindowOffety,t.windowOffsetLeft=+t.nzWidth;break;case 2:t.options.zoomWindowHeight>t.nzHeight&&(t.windowOffsetTop=-1*(t.options.zoomWindowHeight/2-t.nzHeight/2),t.windowOffsetLeft=t.nzWidth);break;case 3:t.windowOffsetTop=t.nzHeight-t.zoomWindow.height()-2*t.options.borderSize,t.windowOffsetLeft=t.nzWidth;break;case 4:t.windowOffsetTop=t.nzHeight,t.windowOffsetLeft=t.nzWidth;break;case 5:t.windowOffsetTop=t.nzHeight,t.windowOffsetLeft=t.nzWidth-t.zoomWindow.width()-2*t.options.borderSize;break;case 6:t.options.zoomWindowHeight>t.nzHeight&&(t.windowOffsetTop=t.nzHeight,t.windowOffsetLeft=-1*(t.options.zoomWindowWidth/2-t.nzWidth/2+2*t.options.borderSize));break;case 7:t.windowOffsetTop=t.nzHeight,t.windowOffsetLeft=0;break;case 8:t.windowOffsetTop=t.nzHeight,t.windowOffsetLeft=-1*(t.zoomWindow.width()+2*t.options.borderSize);break;case 9:t.windowOffsetTop=t.nzHeight-t.zoomWindow.height()-2*t.options.borderSize,t.windowOffsetLeft=-1*(t.zoomWindow.width()+2*t.options.borderSize);break;case 10:t.options.zoomWindowHeight>t.nzHeight&&(t.windowOffsetTop=-1*(t.options.zoomWindowHeight/2-t.nzHeight/2),t.windowOffsetLeft=-1*(t.zoomWindow.width()+2*t.options.borderSize));break;case 11:t.windowOffsetTop=t.options.zoomWindowOffety,t.windowOffsetLeft=-1*(t.zoomWindow.width()+2*t.options.borderSize);break;case 12:t.windowOffsetTop=-1*(t.zoomWindow.height()+2*t.options.borderSize),t.windowOffsetLeft=-1*(t.zoomWindow.width()+2*t.options.borderSize);break;case 13:t.windowOffsetTop=-1*(t.zoomWindow.height()+2*t.options.borderSize),t.windowOffsetLeft=0;break;case 14:t.options.zoomWindowHeight>t.nzHeight&&(t.windowOffsetTop=-1*(t.zoomWindow.height()+2*t.options.borderSize),t.windowOffsetLeft=-1*(t.options.zoomWindowWidth/2-t.nzWidth/2+2*t.options.borderSize));break;case 15:t.windowOffsetTop=-1*(t.zoomWindow.height()+2*t.options.borderSize),t.windowOffsetLeft=t.nzWidth-t.zoomWindow.width()-2*t.options.borderSize;break;case 16:t.windowOffsetTop=-1*(t.zoomWindow.height()+2*t.options.borderSize),t.windowOffsetLeft=t.nzWidth;break;default:t.windowOffsetTop=t.options.zoomWindowOffety,t.windowOffsetLeft=t.nzWidth}t.isWindowSet=!0,t.windowOffsetTop+=t.options.zoomWindowOffety,t.windowOffsetLeft+=t.options.zoomWindowOffetx,t.zoomWindow.css({top:t.windowOffsetTop}),t.zoomWindow.css({left:t.windowOffsetLeft}),"inner"==t.options.zoomType&&(t.zoomWindow.css({top:0}),t.zoomWindow.css({left:0})),t.windowLeftPos=String(-1*((i.pageX-t.nzOffset.left)*t.widthRatio-t.zoomWindow.width()/2)),t.windowTopPos=String(-1*((i.pageY-t.nzOffset.top)*t.heightRatio-t.zoomWindow.height()/2)),t.Etoppos&&(t.windowTopPos=0),t.Eloppos&&(t.windowLeftPos=0),t.Eboppos&&(t.windowTopPos=-1*(t.largeHeight/t.currentZoomLevel-t.zoomWindow.height())),t.Eroppos&&(t.windowLeftPos=-1*(t.largeWidth/t.currentZoomLevel-t.zoomWindow.width())),t.fullheight&&(t.windowTopPos=0),t.fullwidth&&(t.windowLeftPos=0),("window"==t.options.zoomType||"inner"==t.options.zoomType)&&(1==t.zoomLock&&(1>=t.widthRatio&&(t.windowLeftPos=0),1>=t.heightRatio&&(t.windowTopPos=0)),t.largeHeight<t.options.zoomWindowHeight&&(t.windowTopPos=0),t.largeWidth<t.options.zoomWindowWidth&&(t.windowLeftPos=0),t.options.easing?(t.xp||(t.xp=0),t.yp||(t.yp=0),t.loop||(t.loop=setInterval(function(){t.xp+=(t.windowLeftPos-t.xp)/t.options.easingAmount,t.yp+=(t.windowTopPos-t.yp)/t.options.easingAmount,t.scrollingLock?(clearInterval(t.loop),t.xp=t.windowLeftPos,t.yp=t.windowTopPos,t.xp=-1*((i.pageX-t.nzOffset.left)*t.widthRatio-t.zoomWindow.width()/2),t.yp=-1*((i.pageY-t.nzOffset.top)*t.heightRatio-t.zoomWindow.height()/2),t.changeBgSize&&(t.nzHeight>t.nzWidth?("lens"==t.options.zoomType&&t.zoomLens.css({"background-size":t.largeWidth/t.newvalueheight+"px "+t.largeHeight/t.newvalueheight+"px"}),t.zoomWindow.css({"background-size":t.largeWidth/t.newvalueheight+"px "+t.largeHeight/t.newvalueheight+"px"})):("lens"!=t.options.zoomType&&t.zoomLens.css({"background-size":t.largeWidth/t.newvaluewidth+"px "+t.largeHeight/t.newvalueheight+"px"}),t.zoomWindow.css({"background-size":t.largeWidth/t.newvaluewidth+"px "+t.largeHeight/t.newvaluewidth+"px"})),t.changeBgSize=!1),t.zoomWindow.css({backgroundPosition:t.windowLeftPos+"px "+t.windowTopPos+"px"}),t.scrollingLock=!1,t.loop=!1):(t.changeBgSize&&(t.nzHeight>t.nzWidth?("lens"==t.options.zoomType&&t.zoomLens.css({"background-size":t.largeWidth/t.newvalueheight+"px "+t.largeHeight/t.newvalueheight+"px"}),t.zoomWindow.css({"background-size":t.largeWidth/t.newvalueheight+"px "+t.largeHeight/t.newvalueheight+"px"})):("lens"!=t.options.zoomType&&t.zoomLens.css({"background-size":t.largeWidth/t.newvaluewidth+"px "+t.largeHeight/t.newvaluewidth+"px"}),t.zoomWindow.css({"background-size":t.largeWidth/t.newvaluewidth+"px "+t.largeHeight/t.newvaluewidth+"px"})),t.changeBgSize=!1),t.zoomWindow.css({backgroundPosition:t.xp+"px "+t.yp+"px"}))},16))):(t.changeBgSize&&(t.nzHeight>t.nzWidth?("lens"==t.options.zoomType&&t.zoomLens.css({"background-size":t.largeWidth/t.newvalueheight+"px "+t.largeHeight/t.newvalueheight+"px"}),t.zoomWindow.css({"background-size":t.largeWidth/t.newvalueheight+"px "+t.largeHeight/t.newvalueheight+"px"})):("lens"==t.options.zoomType&&t.zoomLens.css({"background-size":t.largeWidth/t.newvaluewidth+"px "+t.largeHeight/t.newvaluewidth+"px"}),t.zoomWindow.css(t.largeHeight/t.newvaluewidth<t.options.zoomWindowHeight?{"background-size":t.largeWidth/t.newvaluewidth+"px "+t.largeHeight/t.newvaluewidth+"px"}:{"background-size":t.largeWidth/t.newvalueheight+"px "+t.largeHeight/t.newvalueheight+"px"})),t.changeBgSize=!1),t.zoomWindow.css({backgroundPosition:t.windowLeftPos+"px "+t.windowTopPos+"px"})))},setTintPosition:function(o){this.nzOffset=this.$elem.offset(),this.tintpos=String(-1*(o.pageX-this.nzOffset.left-this.zoomLens.width()/2)),this.tintposy=String(-1*(o.pageY-this.nzOffset.top-this.zoomLens.height()/2)),this.Etoppos&&(this.tintposy=0),this.Eloppos&&(this.tintpos=0),this.Eboppos&&(this.tintposy=-1*(this.nzHeight-this.zoomLens.height()-2*this.options.lensBorderSize)),this.Eroppos&&(this.tintpos=-1*(this.nzWidth-this.zoomLens.width()-2*this.options.lensBorderSize)),this.options.tint&&(this.fullheight&&(this.tintposy=0),this.fullwidth&&(this.tintpos=0),this.zoomTintImage.css({left:this.tintpos+"px"}),this.zoomTintImage.css({top:this.tintposy+"px"}))},swaptheimage:function(i,t){var e=this,n=new Image;e.options.loadingIcon&&(e.spinner=o("<div style=\"background: url('"+e.options.loadingIcon+"') no-repeat center;height:"+e.nzHeight+"px;width:"+e.nzWidth+'px;z-index: 2000;position: absolute; background-position: center center;"></div>'),e.$elem.after(e.spinner)),e.options.onImageSwap(e.$elem),n.onload=function(){e.largeWidth=n.width,e.largeHeight=n.height,e.zoomImage=t,e.zoomWindow.css({"background-size":e.largeWidth+"px "+e.largeHeight+"px"}),e.zoomWindow.css({"background-size":e.largeWidth+"px "+e.largeHeight+"px"}),e.swapAction(i,t)},n.src=t},swapAction:function(i,t){var e=this,n=new Image;if(n.onload=function(){e.nzHeight=n.height,e.nzWidth=n.width,e.options.onImageSwapComplete(e.$elem),e.doneCallback()},n.src=i,e.currentZoomLevel=e.options.zoomLevel,e.options.maxZoomLevel=!1,"lens"==e.options.zoomType&&e.zoomLens.css({backgroundImage:"url('"+t+"')"}),"window"==e.options.zoomType&&e.zoomWindow.css({backgroundImage:"url('"+t+"')"}),"inner"==e.options.zoomType&&e.zoomWindow.css({backgroundImage:"url('"+t+"')"}),e.currentImage=t,e.options.imageCrossfade){var s=e.$elem,h=s.clone();e.$elem.attr("src",i),e.$elem.after(h),h.stop(!0).fadeOut(e.options.imageCrossfade,function(){o(this).remove()}),e.$elem.width("auto").removeAttr("width"),e.$elem.height("auto").removeAttr("height"),s.fadeIn(e.options.imageCrossfade),e.options.tint&&"inner"!=e.options.zoomType&&(s=e.zoomTintImage,h=s.clone(),e.zoomTintImage.attr("src",t),e.zoomTintImage.after(h),h.stop(!0).fadeOut(e.options.imageCrossfade,function(){o(this).remove()}),s.fadeIn(e.options.imageCrossfade),e.zoomTint.css({height:e.$elem.height()}),e.zoomTint.css({width:e.$elem.width()})),e.zoomContainer.css("height",e.$elem.height()),e.zoomContainer.css("width",e.$elem.width()),"inner"!=e.options.zoomType||e.options.constrainType||(e.zoomWrap.parent().css("height",e.$elem.height()),e.zoomWrap.parent().css("width",e.$elem.width()),e.zoomWindow.css("height",e.$elem.height()),e.zoomWindow.css("width",e.$elem.width()))}else e.$elem.attr("src",i),e.options.tint&&(e.zoomTintImage.attr("src",t),e.zoomTintImage.attr("height",e.$elem.height()),e.zoomTintImage.css({height:e.$elem.height()}),e.zoomTint.css({height:e.$elem.height()})),e.zoomContainer.css("height",e.$elem.height()),e.zoomContainer.css("width",e.$elem.width());e.options.imageCrossfade&&(e.zoomWrap.css("height",e.$elem.height()),e.zoomWrap.css("width",e.$elem.width())),e.options.constrainType&&("height"==e.options.constrainType&&(e.zoomContainer.css("height",e.options.constrainSize),e.zoomContainer.css("width","auto"),e.options.imageCrossfade?(e.zoomWrap.css("height",e.options.constrainSize),e.zoomWrap.css("width","auto"),e.constwidth=e.zoomWrap.width()):(e.$elem.css("height",e.options.constrainSize),e.$elem.css("width","auto"),e.constwidth=e.$elem.width()),"inner"==e.options.zoomType&&(e.zoomWrap.parent().css("height",e.options.constrainSize),e.zoomWrap.parent().css("width",e.constwidth),e.zoomWindow.css("height",e.options.constrainSize),e.zoomWindow.css("width",e.constwidth)),e.options.tint&&(e.tintContainer.css("height",e.options.constrainSize),e.tintContainer.css("width",e.constwidth),e.zoomTint.css("height",e.options.constrainSize),e.zoomTint.css("width",e.constwidth),e.zoomTintImage.css("height",e.options.constrainSize),e.zoomTintImage.css("width",e.constwidth))),"width"==e.options.constrainType&&(e.zoomContainer.css("height","auto"),e.zoomContainer.css("width",e.options.constrainSize),e.options.imageCrossfade?(e.zoomWrap.css("height","auto"),e.zoomWrap.css("width",e.options.constrainSize),e.constheight=e.zoomWrap.height()):(e.$elem.css("height","auto"),e.$elem.css("width",e.options.constrainSize),e.constheight=e.$elem.height()),"inner"==e.options.zoomType&&(e.zoomWrap.parent().css("height",e.constheight),e.zoomWrap.parent().css("width",e.options.constrainSize),e.zoomWindow.css("height",e.constheight),e.zoomWindow.css("width",e.options.constrainSize)),e.options.tint&&(e.tintContainer.css("height",e.constheight),e.tintContainer.css("width",e.options.constrainSize),e.zoomTint.css("height",e.constheight),e.zoomTint.css("width",e.options.constrainSize),e.zoomTintImage.css("height",e.constheight),e.zoomTintImage.css("width",e.options.constrainSize))))},doneCallback:function(){this.options.loadingIcon&&this.spinner.hide(),this.nzOffset=this.$elem.offset(),this.nzWidth=this.$elem.width(),this.nzHeight=this.$elem.height(),this.currentZoomLevel=this.options.zoomLevel,this.widthRatio=this.largeWidth/this.nzWidth,this.heightRatio=this.largeHeight/this.nzHeight,"window"==this.options.zoomType&&(lensHeight=this.nzHeight<this.options.zoomWindowWidth/this.widthRatio?this.nzHeight:String(this.options.zoomWindowHeight/this.heightRatio),lensWidth=this.options.zoomWindowWidth<this.options.zoomWindowWidth?this.nzWidth:this.options.zoomWindowWidth/this.widthRatio,this.zoomLens&&(this.zoomLens.css("width",lensWidth),this.zoomLens.css("height",lensHeight)))},getCurrentImage:function(){return this.zoomImage},getGalleryList:function(){var i=this;return i.gallerylist=[],i.options.gallery?o("#"+i.options.gallery+" a").each(function(){var t="";o(this).data("zoom-image")?t=o(this).data("zoom-image"):o(this).data("image")&&(t=o(this).data("image")),t==i.zoomImage?i.gallerylist.unshift({href:""+t,title:o(this).find("img").attr("title")}):i.gallerylist.push({href:""+t,title:o(this).find("img").attr("title")})}):i.gallerylist.push({href:""+i.zoomImage,title:o(this).find("img").attr("title")}),i.gallerylist},changeZoomLevel:function(o){this.scrollingLock=!0,this.newvalue=parseFloat(o).toFixed(2),newvalue=parseFloat(o).toFixed(2),maxheightnewvalue=this.largeHeight/(this.options.zoomWindowHeight/this.nzHeight*this.nzHeight),maxwidthtnewvalue=this.largeWidth/(this.options.zoomWindowWidth/this.nzWidth*this.nzWidth),"inner"!=this.options.zoomType&&(maxheightnewvalue<=newvalue?(this.heightRatio=this.largeHeight/maxheightnewvalue/this.nzHeight,this.newvalueheight=maxheightnewvalue,this.fullheight=!0):(this.heightRatio=this.largeHeight/newvalue/this.nzHeight,this.newvalueheight=newvalue,this.fullheight=!1),maxwidthtnewvalue<=newvalue?(this.widthRatio=this.largeWidth/maxwidthtnewvalue/this.nzWidth,this.newvaluewidth=maxwidthtnewvalue,this.fullwidth=!0):(this.widthRatio=this.largeWidth/newvalue/this.nzWidth,this.newvaluewidth=newvalue,this.fullwidth=!1),"lens"==this.options.zoomType&&(maxheightnewvalue<=newvalue?(this.fullwidth=!0,this.newvaluewidth=maxheightnewvalue):(this.widthRatio=this.largeWidth/newvalue/this.nzWidth,this.newvaluewidth=newvalue,this.fullwidth=!1))),"inner"==this.options.zoomType&&(maxheightnewvalue=parseFloat(this.largeHeight/this.nzHeight).toFixed(2),maxwidthtnewvalue=parseFloat(this.largeWidth/this.nzWidth).toFixed(2),newvalue>maxheightnewvalue&&(newvalue=maxheightnewvalue),newvalue>maxwidthtnewvalue&&(newvalue=maxwidthtnewvalue),maxheightnewvalue<=newvalue?(this.heightRatio=this.largeHeight/newvalue/this.nzHeight,this.newvalueheight=newvalue>maxheightnewvalue?maxheightnewvalue:newvalue,this.fullheight=!0):(this.heightRatio=this.largeHeight/newvalue/this.nzHeight,this.newvalueheight=newvalue>maxheightnewvalue?maxheightnewvalue:newvalue,this.fullheight=!1),maxwidthtnewvalue<=newvalue?(this.widthRatio=this.largeWidth/newvalue/this.nzWidth,this.newvaluewidth=newvalue>maxwidthtnewvalue?maxwidthtnewvalue:newvalue,this.fullwidth=!0):(this.widthRatio=this.largeWidth/newvalue/this.nzWidth,this.newvaluewidth=newvalue,this.fullwidth=!1)),scrcontinue=!1,"inner"==this.options.zoomType&&(this.nzWidth>this.nzHeight&&(this.newvaluewidth<=maxwidthtnewvalue?scrcontinue=!0:(scrcontinue=!1,this.fullwidth=this.fullheight=!0)),this.nzHeight>this.nzWidth&&(this.newvaluewidth<=maxwidthtnewvalue?scrcontinue=!0:(scrcontinue=!1,this.fullwidth=this.fullheight=!0))),"inner"!=this.options.zoomType&&(scrcontinue=!0),scrcontinue&&(this.zoomLock=0,this.changeZoom=!0,this.options.zoomWindowHeight/this.heightRatio<=this.nzHeight&&(this.currentZoomLevel=this.newvalueheight,"lens"!=this.options.zoomType&&"inner"!=this.options.zoomType&&(this.changeBgSize=!0,this.zoomLens.css({height:String(this.options.zoomWindowHeight/this.heightRatio)+"px"})),"lens"==this.options.zoomType||"inner"==this.options.zoomType)&&(this.changeBgSize=!0),this.options.zoomWindowWidth/this.widthRatio<=this.nzWidth&&("inner"!=this.options.zoomType&&this.newvaluewidth>this.newvalueheight&&(this.currentZoomLevel=this.newvaluewidth),"lens"!=this.options.zoomType&&"inner"!=this.options.zoomType&&(this.changeBgSize=!0,this.zoomLens.css({width:String(this.options.zoomWindowWidth/this.widthRatio)+"px"})),"lens"==this.options.zoomType||"inner"==this.options.zoomType)&&(this.changeBgSize=!0),"inner"==this.options.zoomType&&(this.changeBgSize=!0,this.nzWidth>this.nzHeight&&(this.currentZoomLevel=this.newvaluewidth),this.nzHeight>this.nzWidth&&(this.currentZoomLevel=this.newvaluewidth))),this.setPosition(this.currentLoc)},closeAll:function(){self.zoomWindow&&self.zoomWindow.hide(),self.zoomLens&&self.zoomLens.hide(),self.zoomTint&&self.zoomTint.hide()},changeState:function(o){"enable"==o&&(this.options.zoomEnabled=!0),"disable"==o&&(this.options.zoomEnabled=!1)}};o.fn.elevateZoom=function(t){return this.each(function(){var e=Object.create(i);e.init(t,this),o.data(this,"elevateZoom",e)})},o.fn.elevateZoom.options={zoomActivation:"hover",zoomEnabled:!0,preloading:1,zoomLevel:1,scrollZoom:!1,scrollZoomIncrement:.1,minZoomLevel:!1,maxZoomLevel:!1,easing:!1,easingAmount:12,lensSize:200,zoomWindowWidth:400,zoomWindowHeight:400,zoomWindowOffetx:0,zoomWindowOffety:0,zoomWindowPosition:1,zoomWindowBgColour:"#fff",lensFadeIn:!1,lensFadeOut:!1,debug:!1,zoomWindowFadeIn:!1,zoomWindowFadeOut:!1,zoomWindowAlwaysShow:!1,zoomTintFadeIn:!1,zoomTintFadeOut:!1,borderSize:4,showLens:!0,borderColour:"#888",lensBorderSize:1,lensBorderColour:"#000",lensShape:"square",zoomType:"window",containLensZoom:!1,lensColour:"white",lensOpacity:.4,lenszoom:!1,tint:!1,tintColour:"#333",tintOpacity:.4,gallery:!1,galleryActiveClass:"zoomGalleryActive",imageCrossfade:!1,constrainType:!1,constrainSize:!1,loadingIcon:!1,cursor:"default",responsive:!0,onComplete:o.noop,onZoomedImageLoaded:function(){},onImageSwap:o.noop,onImageSwapComplete:o.noop}}(jQuery,window,document);
/* 6  */ 
/* 7  */ // jQuery jGrowl v1.4.3 | Licensed under the MIT License
/* 8  */ !function(a){a.jGrowl=function(b,c){0===a("#jGrowl").length&&a('<div id="jGrowl"></div>').addClass(c&&c.position?c.position:a.jGrowl.defaults.position).appendTo(c&&c.appendTo?c.appendTo:a.jGrowl.defaults.appendTo),a("#jGrowl").jGrowl(b,c)},a.fn.jGrowl=function(b,c){if(void 0===c&&a.isPlainObject(b)&&(c=b,b=c.message),a.isFunction(this.each)){var d=arguments;return this.each(function(){void 0===a(this).data("jGrowl.instance")&&(a(this).data("jGrowl.instance",a.extend(new a.fn.jGrowl,{notifications:[],element:null,interval:null})),a(this).data("jGrowl.instance").startup(this)),a.isFunction(a(this).data("jGrowl.instance")[b])?a(this).data("jGrowl.instance")[b].apply(a(this).data("jGrowl.instance"),a.makeArray(d).slice(1)):a(this).data("jGrowl.instance").create(b,c)})}},a.extend(a.fn.jGrowl.prototype,{defaults:{pool:0,header:"",group:"",sticky:!1,position:"top-right",appendTo:"body",glue:"after",theme:"default",themeState:"highlight",corners:"10px",check:250,life:3e3,closeDuration:"normal",openDuration:"normal",easing:"swing",closer:!0,closeTemplate:"&times;",closerTemplate:"<div>[ close all ]</div>",log:function(){},beforeOpen:function(){},afterOpen:function(){},open:function(){},beforeClose:function(){},close:function(){},click:function(){},animateOpen:{opacity:"show"},animateClose:{opacity:"hide"}},notifications:[],element:null,interval:null,create:function(b,c){var d=a.extend({},this.defaults,c);"undefined"!=typeof d.speed&&(d.openDuration=d.speed,d.closeDuration=d.speed),this.notifications.push({message:b,options:d}),d.log.apply(this.element,[this.element,b,d])},render:function(b){var c=this,d=b.message,e=b.options;e.themeState=""===e.themeState?"":"ui-state-"+e.themeState;var f=a("<div/>").addClass("jGrowl-notification alert "+e.themeState+" ui-corner-all"+(void 0!==e.group&&""!==e.group?" "+e.group:"")).append(a("<button/>").addClass("jGrowl-close").html(e.closeTemplate)).append(a("<div/>").addClass("jGrowl-header").html(e.header)).append(a("<div/>").addClass("jGrowl-message").html(d)).data("jGrowl",e).addClass(e.theme).children(".jGrowl-close").bind("click.jGrowl",function(){return a(this).parent().trigger("jGrowl.beforeClose"),!1}).parent();a(f).bind("mouseover.jGrowl",function(){a(".jGrowl-notification",c.element).data("jGrowl.pause",!0)}).bind("mouseout.jGrowl",function(){a(".jGrowl-notification",c.element).data("jGrowl.pause",!1)}).bind("jGrowl.beforeOpen",function(){e.beforeOpen.apply(f,[f,d,e,c.element])!==!1&&a(this).trigger("jGrowl.open")}).bind("jGrowl.open",function(){e.open.apply(f,[f,d,e,c.element])!==!1&&("after"==e.glue?a(".jGrowl-notification:last",c.element).after(f):a(".jGrowl-notification:first",c.element).before(f),a(this).animate(e.animateOpen,e.openDuration,e.easing,function(){a.support.opacity===!1&&this.style.removeAttribute("filter"),null!==a(this).data("jGrowl")&&"undefined"!=typeof a(this).data("jGrowl")&&(a(this).data("jGrowl").created=new Date),a(this).trigger("jGrowl.afterOpen")}))}).bind("jGrowl.afterOpen",function(){e.afterOpen.apply(f,[f,d,e,c.element])}).bind("click",function(){e.click.apply(f,[f.message,e,c.element])}).bind("jGrowl.beforeClose",function(){e.beforeClose.apply(f,[f,d,e,c.element])!==!1&&a(this).trigger("jGrowl.close")}).bind("jGrowl.close",function(){a(this).data("jGrowl.pause",!0),a(this).animate(e.animateClose,e.closeDuration,e.easing,function(){a.isFunction(e.close)?e.close.apply(f,[f,d,e,c.element])!==!1&&a(this).remove():a(this).remove()})}).trigger("jGrowl.beforeOpen"),""!==e.corners&&void 0!==a.fn.corner&&a(f).corner(e.corners),a(".jGrowl-notification:parent",c.element).length>1&&0===a(".jGrowl-closer",c.element).length&&this.defaults.closer!==!1&&a(this.defaults.closerTemplate).addClass("jGrowl-closer "+this.defaults.themeState+" ui-corner-all").addClass(this.defaults.theme).appendTo(c.element).animate(this.defaults.animateOpen,this.defaults.speed,this.defaults.easing).bind("click.jGrowl",function(){a(this).siblings().trigger("jGrowl.beforeClose"),a.isFunction(c.defaults.closer)&&c.defaults.closer.apply(a(this).parent()[0],[a(this).parent()[0]])})},update:function(){a(this.element).find(".jGrowl-notification:parent").each(function(){void 0!==a(this).data("jGrowl")&&void 0!==a(this).data("jGrowl").created&&a(this).data("jGrowl").created.getTime()+parseInt(a(this).data("jGrowl").life,10)<(new Date).getTime()&&a(this).data("jGrowl").sticky!==!0&&(void 0===a(this).data("jGrowl.pause")||a(this).data("jGrowl.pause")!==!0)&&a(this).trigger("jGrowl.beforeClose")}),this.notifications.length>0&&(0===this.defaults.pool||a(this.element).find(".jGrowl-notification:parent").length<this.defaults.pool)&&this.render(this.notifications.shift()),a(this.element).find(".jGrowl-notification:parent").length<2&&a(this.element).find(".jGrowl-closer").animate(this.defaults.animateClose,this.defaults.speed,this.defaults.easing,function(){a(this).remove()})},startup:function(b){this.element=a(b).addClass("jGrowl").append('<div class="jGrowl-notification"></div>'),this.interval=setInterval(function(){var c=a(b).data("jGrowl.instance");void 0!==c&&c.update()},parseInt(this.defaults.check,10))},shutdown:function(){a(this.element).removeClass("jGrowl").find(".jGrowl-notification").trigger("jGrowl.close").parent().empty(),clearInterval(this.interval)},close:function(){a(this.element).find(".jGrowl-notification").each(function(){a(this).trigger("jGrowl.beforeClose")})}}),a.jGrowl.defaults=a.fn.jGrowl.prototype.defaults}(jQuery);
/* 9  */ 
/* 10 */ 
/* 11 */ // Magnific Popup - v0.9.9
/* 12 */ (function(e){var t,n,i,o,r,a,s,l="Close",c="BeforeClose",d="AfterClose",u="BeforeAppend",p="MarkupParse",f="Open",m="Change",g="mfp",v="."+g,h="mfp-ready",C="mfp-removing",y="mfp-prevent-close",w=function(){},b=!!window.jQuery,I=e(window),x=function(e,n){t.ev.on(g+e+v,n)},k=function(t,n,i,o){var r=document.createElement("div");return r.className="mfp-"+t,i&&(r.innerHTML=i),o?n&&n.appendChild(r):(r=e(r),n&&r.appendTo(n)),r},T=function(n,i){t.ev.triggerHandler(g+n,i),t.st.callbacks&&(n=n.charAt(0).toLowerCase()+n.slice(1),t.st.callbacks[n]&&t.st.callbacks[n].apply(t,e.isArray(i)?i:[i]))},E=function(n){return n===s&&t.currTemplate.closeBtn||(t.currTemplate.closeBtn=e(t.st.closeMarkup.replace("%title%",t.st.tClose)),s=n),t.currTemplate.closeBtn},_=function(){e.magnificPopup.instance||(t=new w,t.init(),e.magnificPopup.instance=t)},S=function(){var e=document.createElement("p").style,t=["ms","O","Moz","Webkit"];if(void 0!==e.transition)return!0;for(;t.length;)if(t.pop()+"Transition"in e)return!0;return!1};w.prototype={constructor:w,init:function(){var n=navigator.appVersion;t.isIE7=-1!==n.indexOf("MSIE 7."),t.isIE8=-1!==n.indexOf("MSIE 8."),t.isLowIE=t.isIE7||t.isIE8,t.isAndroid=/android/gi.test(n),t.isIOS=/iphone|ipad|ipod/gi.test(n),t.supportsTransition=S(),t.probablyMobile=t.isAndroid||t.isIOS||/(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent),i=e(document.body),o=e(document),t.popupsCache={}},open:function(n){var i;if(n.isObj===!1){t.items=n.items.toArray(),t.index=0;var r,s=n.items;for(i=0;s.length>i;i++)if(r=s[i],r.parsed&&(r=r.el[0]),r===n.el[0]){t.index=i;break}}else t.items=e.isArray(n.items)?n.items:[n.items],t.index=n.index||0;if(t.isOpen)return t.updateItemHTML(),void 0;t.types=[],a="",t.ev=n.mainEl&&n.mainEl.length?n.mainEl.eq(0):o,n.key?(t.popupsCache[n.key]||(t.popupsCache[n.key]={}),t.currTemplate=t.popupsCache[n.key]):t.currTemplate={},t.st=e.extend(!0,{},e.magnificPopup.defaults,n),t.fixedContentPos="auto"===t.st.fixedContentPos?!t.probablyMobile:t.st.fixedContentPos,t.st.modal&&(t.st.closeOnContentClick=!1,t.st.closeOnBgClick=!1,t.st.showCloseBtn=!1,t.st.enableEscapeKey=!1),t.bgOverlay||(t.bgOverlay=k("bg").on("click"+v,function(){t.close()}),t.wrap=k("wrap").attr("tabindex",-1).on("click"+v,function(e){t._checkIfClose(e.target)&&t.close()}),t.container=k("container",t.wrap)),t.contentContainer=k("content"),t.st.preloader&&(t.preloader=k("preloader",t.container,t.st.tLoading));var l=e.magnificPopup.modules;for(i=0;l.length>i;i++){var c=l[i];c=c.charAt(0).toUpperCase()+c.slice(1),t["init"+c].call(t)}T("BeforeOpen"),t.st.showCloseBtn&&(t.st.closeBtnInside?(x(p,function(e,t,n,i){n.close_replaceWith=E(i.type)}),a+=" mfp-close-btn-in"):t.wrap.append(E())),t.st.alignTop&&(a+=" mfp-align-top"),t.fixedContentPos?t.wrap.css({overflow:t.st.overflowY,overflowX:"hidden",overflowY:t.st.overflowY}):t.wrap.css({top:I.scrollTop(),position:"absolute"}),(t.st.fixedBgPos===!1||"auto"===t.st.fixedBgPos&&!t.fixedContentPos)&&t.bgOverlay.css({height:o.height(),position:"absolute"}),t.st.enableEscapeKey&&o.on("keyup"+v,function(e){27===e.keyCode&&t.close()}),I.on("resize"+v,function(){t.updateSize()}),t.st.closeOnContentClick||(a+=" mfp-auto-cursor"),a&&t.wrap.addClass(a);var d=t.wH=I.height(),u={};if(t.fixedContentPos&&t._hasScrollBar(d)){var m=t._getScrollbarSize();m&&(u.marginRight=m)}t.fixedContentPos&&(t.isIE7?e("body, html").css("overflow","hidden"):u.overflow="hidden");var g=t.st.mainClass;return t.isIE7&&(g+=" mfp-ie7"),g&&t._addClassToMFP(g),t.updateItemHTML(),T("BuildControls"),e("html").css(u),t.bgOverlay.add(t.wrap).prependTo(document.body),t._lastFocusedEl=document.activeElement,setTimeout(function(){t.content?(t._addClassToMFP(h),t._setFocus()):t.bgOverlay.addClass(h),o.on("focusin"+v,t._onFocusIn)},16),t.isOpen=!0,t.updateSize(d),T(f),n},close:function(){t.isOpen&&(T(c),t.isOpen=!1,t.st.removalDelay&&!t.isLowIE&&t.supportsTransition?(t._addClassToMFP(C),setTimeout(function(){t._close()},t.st.removalDelay)):t._close())},_close:function(){T(l);var n=C+" "+h+" ";if(t.bgOverlay.detach(),t.wrap.detach(),t.container.empty(),t.st.mainClass&&(n+=t.st.mainClass+" "),t._removeClassFromMFP(n),t.fixedContentPos){var i={marginRight:""};t.isIE7?e("body, html").css("overflow",""):i.overflow="",e("html").css(i)}o.off("keyup"+v+" focusin"+v),t.ev.off(v),t.wrap.attr("class","mfp-wrap").removeAttr("style"),t.bgOverlay.attr("class","mfp-bg"),t.container.attr("class","mfp-container"),!t.st.showCloseBtn||t.st.closeBtnInside&&t.currTemplate[t.currItem.type]!==!0||t.currTemplate.closeBtn&&t.currTemplate.closeBtn.detach(),t._lastFocusedEl&&e(t._lastFocusedEl).focus(),t.currItem=null,t.content=null,t.currTemplate=null,t.prevHeight=0,T(d)},updateSize:function(e){if(t.isIOS){var n=document.documentElement.clientWidth/window.innerWidth,i=window.innerHeight*n;t.wrap.css("height",i),t.wH=i}else t.wH=e||I.height();t.fixedContentPos||t.wrap.css("height",t.wH),T("Resize")},updateItemHTML:function(){var n=t.items[t.index];t.contentContainer.detach(),t.content&&t.content.detach(),n.parsed||(n=t.parseEl(t.index));var i=n.type;if(T("BeforeChange",[t.currItem?t.currItem.type:"",i]),t.currItem=n,!t.currTemplate[i]){var o=t.st[i]?t.st[i].markup:!1;T("FirstMarkupParse",o),t.currTemplate[i]=o?e(o):!0}r&&r!==n.type&&t.container.removeClass("mfp-"+r+"-holder");var a=t["get"+i.charAt(0).toUpperCase()+i.slice(1)](n,t.currTemplate[i]);t.appendContent(a,i),n.preloaded=!0,T(m,n),r=n.type,t.container.prepend(t.contentContainer),T("AfterChange")},appendContent:function(e,n){t.content=e,e?t.st.showCloseBtn&&t.st.closeBtnInside&&t.currTemplate[n]===!0?t.content.find(".mfp-close").length||t.content.append(E()):t.content=e:t.content="",T(u),t.container.addClass("mfp-"+n+"-holder"),t.contentContainer.append(t.content)},parseEl:function(n){var i=t.items[n],o=i.type;if(i=i.tagName?{el:e(i)}:{data:i,src:i.src},i.el){for(var r=t.types,a=0;r.length>a;a++)if(i.el.hasClass("mfp-"+r[a])){o=r[a];break}i.src=i.el.attr("data-mfp-src"),i.src||(i.src=i.el.attr("href"))}return i.type=o||t.st.type||"inline",i.index=n,i.parsed=!0,t.items[n]=i,T("ElementParse",i),t.items[n]},addGroup:function(e,n){var i=function(i){i.mfpEl=this,t._openClick(i,e,n)};n||(n={});var o="click.magnificPopup";n.mainEl=e,n.items?(n.isObj=!0,e.off(o).on(o,i)):(n.isObj=!1,n.delegate?e.off(o).on(o,n.delegate,i):(n.items=e,e.off(o).on(o,i)))},_openClick:function(n,i,o){var r=void 0!==o.midClick?o.midClick:e.magnificPopup.defaults.midClick;if(r||2!==n.which&&!n.ctrlKey&&!n.metaKey){var a=void 0!==o.disableOn?o.disableOn:e.magnificPopup.defaults.disableOn;if(a)if(e.isFunction(a)){if(!a.call(t))return!0}else if(a>I.width())return!0;n.type&&(n.preventDefault(),t.isOpen&&n.stopPropagation()),o.el=e(n.mfpEl),o.delegate&&(o.items=i.find(o.delegate)),t.open(o)}},updateStatus:function(e,i){if(t.preloader){n!==e&&t.container.removeClass("mfp-s-"+n),i||"loading"!==e||(i=t.st.tLoading);var o={status:e,text:i};T("UpdateStatus",o),e=o.status,i=o.text,t.preloader.html(i),t.preloader.find("a").on("click",function(e){e.stopImmediatePropagation()}),t.container.addClass("mfp-s-"+e),n=e}},_checkIfClose:function(n){if(!e(n).hasClass(y)){var i=t.st.closeOnContentClick,o=t.st.closeOnBgClick;if(i&&o)return!0;if(!t.content||e(n).hasClass("mfp-close")||t.preloader&&n===t.preloader[0])return!0;if(n===t.content[0]||e.contains(t.content[0],n)){if(i)return!0}else if(o&&e.contains(document,n))return!0;return!1}},_addClassToMFP:function(e){t.bgOverlay.addClass(e),t.wrap.addClass(e)},_removeClassFromMFP:function(e){this.bgOverlay.removeClass(e),t.wrap.removeClass(e)},_hasScrollBar:function(e){return(t.isIE7?o.height():document.body.scrollHeight)>(e||I.height())},_setFocus:function(){(t.st.focus?t.content.find(t.st.focus).eq(0):t.wrap).focus()},_onFocusIn:function(n){return n.target===t.wrap[0]||e.contains(t.wrap[0],n.target)?void 0:(t._setFocus(),!1)},_parseMarkup:function(t,n,i){var o;i.data&&(n=e.extend(i.data,n)),T(p,[t,n,i]),e.each(n,function(e,n){if(void 0===n||n===!1)return!0;if(o=e.split("_"),o.length>1){var i=t.find(v+"-"+o[0]);if(i.length>0){var r=o[1];"replaceWith"===r?i[0]!==n[0]&&i.replaceWith(n):"img"===r?i.is("img")?i.attr("src",n):i.replaceWith('<img src="'+n+'" class="'+i.attr("class")+'" />'):i.attr(o[1],n)}}else t.find(v+"-"+e).html(n)})},_getScrollbarSize:function(){if(void 0===t.scrollbarSize){var e=document.createElement("div");e.id="mfp-sbm",e.style.cssText="width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;",document.body.appendChild(e),t.scrollbarSize=e.offsetWidth-e.clientWidth,document.body.removeChild(e)}return t.scrollbarSize}},e.magnificPopup={instance:null,proto:w.prototype,modules:[],open:function(t,n){return _(),t=t?e.extend(!0,{},t):{},t.isObj=!0,t.index=n||0,this.instance.open(t)},close:function(){return e.magnificPopup.instance&&e.magnificPopup.instance.close()},registerModule:function(t,n){n.options&&(e.magnificPopup.defaults[t]=n.options),e.extend(this.proto,n.proto),this.modules.push(t)},defaults:{disableOn:0,key:null,midClick:!1,mainClass:"",preloader:!0,focus:"",closeOnContentClick:!1,closeOnBgClick:!0,closeBtnInside:!0,showCloseBtn:!0,enableEscapeKey:!0,modal:!1,alignTop:!1,removalDelay:0,fixedContentPos:"auto",fixedBgPos:"auto",overflowY:"auto",closeMarkup:'<button title="%title%" type="button" class="mfp-close">&times;</button>',tClose:"Close (Esc)",tLoading:"Loading..."}},e.fn.magnificPopup=function(n){_();var i=e(this);if("string"==typeof n)if("open"===n){var o,r=b?i.data("magnificPopup"):i[0].magnificPopup,a=parseInt(arguments[1],10)||0;r.items?o=r.items[a]:(o=i,r.delegate&&(o=o.find(r.delegate)),o=o.eq(a)),t._openClick({mfpEl:o},i,r)}else t.isOpen&&t[n].apply(t,Array.prototype.slice.call(arguments,1));else n=e.extend(!0,{},n),b?i.data("magnificPopup",n):i[0].magnificPopup=n,t.addGroup(i,n);return i};var P,O,z,M="inline",B=function(){z&&(O.after(z.addClass(P)).detach(),z=null)};e.magnificPopup.registerModule(M,{options:{hiddenClass:"hide",markup:"",tNotFound:"Content not found"},proto:{initInline:function(){t.types.push(M),x(l+"."+M,function(){B()})},getInline:function(n,i){if(B(),n.src){var o=t.st.inline,r=e(n.src);if(r.length){var a=r[0].parentNode;a&&a.tagName&&(O||(P=o.hiddenClass,O=k(P),P="mfp-"+P),z=r.after(O).detach().removeClass(P)),t.updateStatus("ready")}else t.updateStatus("error",o.tNotFound),r=e("<div>");return n.inlineElement=r,r}return t.updateStatus("ready"),t._parseMarkup(i,{},n),i}}});var F,H="ajax",L=function(){F&&i.removeClass(F)},A=function(){L(),t.req&&t.req.abort()};e.magnificPopup.registerModule(H,{options:{settings:null,cursor:"mfp-ajax-cur",tError:'<a href="%url%">The content</a> could not be loaded.'},proto:{initAjax:function(){t.types.push(H),F=t.st.ajax.cursor,x(l+"."+H,A),x("BeforeChange."+H,A)},getAjax:function(n){F&&i.addClass(F),t.updateStatus("loading");var o=e.extend({url:n.src,success:function(i,o,r){var a={data:i,xhr:r};T("ParseAjax",a),t.appendContent(e(a.data),H),n.finished=!0,L(),t._setFocus(),setTimeout(function(){t.wrap.addClass(h)},16),t.updateStatus("ready"),T("AjaxContentAdded")},error:function(){L(),n.finished=n.loadError=!0,t.updateStatus("error",t.st.ajax.tError.replace("%url%",n.src))}},t.st.ajax.settings);return t.req=e.ajax(o),""}}});var j,N=function(n){if(n.data&&void 0!==n.data.title)return n.data.title;var i=t.st.image.titleSrc;if(i){if(e.isFunction(i))return i.call(t,n);if(n.el)return n.el.attr(i)||""}return""};e.magnificPopup.registerModule("image",{options:{markup:'<div class="mfp-figure"><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div><div class="mfp-counter"></div></div></figcaption></figure></div>',cursor:"mfp-zoom-out-cur",titleSrc:"title",verticalFit:!0,tError:'<a href="%url%">The image</a> could not be loaded.'},proto:{initImage:function(){var e=t.st.image,n=".image";t.types.push("image"),x(f+n,function(){"image"===t.currItem.type&&e.cursor&&i.addClass(e.cursor)}),x(l+n,function(){e.cursor&&i.removeClass(e.cursor),I.off("resize"+v)}),x("Resize"+n,t.resizeImage),t.isLowIE&&x("AfterChange",t.resizeImage)},resizeImage:function(){var e=t.currItem;if(e&&e.img&&t.st.image.verticalFit){var n=0;t.isLowIE&&(n=parseInt(e.img.css("padding-top"),10)+parseInt(e.img.css("padding-bottom"),10)),e.img.css("max-height",t.wH-n)}},_onImageHasSize:function(e){e.img&&(e.hasSize=!0,j&&clearInterval(j),e.isCheckingImgSize=!1,T("ImageHasSize",e),e.imgHidden&&(t.content&&t.content.removeClass("mfp-loading"),e.imgHidden=!1))},findImageSize:function(e){var n=0,i=e.img[0],o=function(r){j&&clearInterval(j),j=setInterval(function(){return i.naturalWidth>0?(t._onImageHasSize(e),void 0):(n>200&&clearInterval(j),n++,3===n?o(10):40===n?o(50):100===n&&o(500),void 0)},r)};o(1)},getImage:function(n,i){var o=0,r=function(){n&&(n.img[0].complete?(n.img.off(".mfploader"),n===t.currItem&&(t._onImageHasSize(n),t.updateStatus("ready")),n.hasSize=!0,n.loaded=!0,T("ImageLoadComplete")):(o++,200>o?setTimeout(r,100):a()))},a=function(){n&&(n.img.off(".mfploader"),n===t.currItem&&(t._onImageHasSize(n),t.updateStatus("error",s.tError.replace("%url%",n.src))),n.hasSize=!0,n.loaded=!0,n.loadError=!0)},s=t.st.image,l=i.find(".mfp-img");if(l.length){var c=document.createElement("img");c.className="mfp-img",n.img=e(c).on("load.mfploader",r).on("error.mfploader",a),c.src=n.src,l.is("img")&&(n.img=n.img.clone()),n.img[0].naturalWidth>0&&(n.hasSize=!0)}return t._parseMarkup(i,{title:N(n),img_replaceWith:n.img},n),t.resizeImage(),n.hasSize?(j&&clearInterval(j),n.loadError?(i.addClass("mfp-loading"),t.updateStatus("error",s.tError.replace("%url%",n.src))):(i.removeClass("mfp-loading"),t.updateStatus("ready")),i):(t.updateStatus("loading"),n.loading=!0,n.hasSize||(n.imgHidden=!0,i.addClass("mfp-loading"),t.findImageSize(n)),i)}}});var W,R=function(){return void 0===W&&(W=void 0!==document.createElement("p").style.MozTransform),W};e.magnificPopup.registerModule("zoom",{options:{enabled:!1,easing:"ease-in-out",duration:300,opener:function(e){return e.is("img")?e:e.find("img")}},proto:{initZoom:function(){var e,n=t.st.zoom,i=".zoom";if(n.enabled&&t.supportsTransition){var o,r,a=n.duration,s=function(e){var t=e.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image"),i="all "+n.duration/1e3+"s "+n.easing,o={position:"fixed",zIndex:9999,left:0,top:0,"-webkit-backface-visibility":"hidden"},r="transition";return o["-webkit-"+r]=o["-moz-"+r]=o["-o-"+r]=o[r]=i,t.css(o),t},d=function(){t.content.css("visibility","visible")};x("BuildControls"+i,function(){if(t._allowZoom()){if(clearTimeout(o),t.content.css("visibility","hidden"),e=t._getItemToZoom(),!e)return d(),void 0;r=s(e),r.css(t._getOffset()),t.wrap.append(r),o=setTimeout(function(){r.css(t._getOffset(!0)),o=setTimeout(function(){d(),setTimeout(function(){r.remove(),e=r=null,T("ZoomAnimationEnded")},16)},a)},16)}}),x(c+i,function(){if(t._allowZoom()){if(clearTimeout(o),t.st.removalDelay=a,!e){if(e=t._getItemToZoom(),!e)return;r=s(e)}r.css(t._getOffset(!0)),t.wrap.append(r),t.content.css("visibility","hidden"),setTimeout(function(){r.css(t._getOffset())},16)}}),x(l+i,function(){t._allowZoom()&&(d(),r&&r.remove(),e=null)})}},_allowZoom:function(){return"image"===t.currItem.type},_getItemToZoom:function(){return t.currItem.hasSize?t.currItem.img:!1},_getOffset:function(n){var i;i=n?t.currItem.img:t.st.zoom.opener(t.currItem.el||t.currItem);var o=i.offset(),r=parseInt(i.css("padding-top"),10),a=parseInt(i.css("padding-bottom"),10);o.top-=e(window).scrollTop()-r;var s={width:i.width(),height:(b?i.innerHeight():i[0].offsetHeight)-a-r};return R()?s["-moz-transform"]=s.transform="translate("+o.left+"px,"+o.top+"px)":(s.left=o.left,s.top=o.top),s}}});var Z="iframe",q="//about:blank",D=function(e){if(t.currTemplate[Z]){var n=t.currTemplate[Z].find("iframe");n.length&&(e||(n[0].src=q),t.isIE8&&n.css("display",e?"block":"none"))}};e.magnificPopup.registerModule(Z,{options:{markup:'<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',srcAction:"iframe_src",patterns:{youtube:{index:"youtube.com",id:"v=",src:"//www.youtube.com/embed/%id%?autoplay=1"},vimeo:{index:"vimeo.com/",id:"/",src:"//player.vimeo.com/video/%id%?autoplay=1"},gmaps:{index:"//maps.google.",src:"%id%&output=embed"}}},proto:{initIframe:function(){t.types.push(Z),x("BeforeChange",function(e,t,n){t!==n&&(t===Z?D():n===Z&&D(!0))}),x(l+"."+Z,function(){D()})},getIframe:function(n,i){var o=n.src,r=t.st.iframe;e.each(r.patterns,function(){return o.indexOf(this.index)>-1?(this.id&&(o="string"==typeof this.id?o.substr(o.lastIndexOf(this.id)+this.id.length,o.length):this.id.call(this,o)),o=this.src.replace("%id%",o),!1):void 0});var a={};return r.srcAction&&(a[r.srcAction]=o),t._parseMarkup(i,a,n),t.updateStatus("ready"),i}}});var K=function(e){var n=t.items.length;return e>n-1?e-n:0>e?n+e:e},Y=function(e,t,n){return e.replace(/%curr%/gi,t+1).replace(/%total%/gi,n)};e.magnificPopup.registerModule("gallery",{options:{enabled:!1,arrowMarkup:'<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',preload:[0,2],navigateByImgClick:!0,arrows:!0,tPrev:"Previous (Left arrow key)",tNext:"Next (Right arrow key)",tCounter:"%curr% of %total%"},proto:{initGallery:function(){var n=t.st.gallery,i=".mfp-gallery",r=Boolean(e.fn.mfpFastClick);return t.direction=!0,n&&n.enabled?(a+=" mfp-gallery",x(f+i,function(){n.navigateByImgClick&&t.wrap.on("click"+i,".mfp-img",function(){return t.items.length>1?(t.next(),!1):void 0}),o.on("keydown"+i,function(e){37===e.keyCode?t.prev():39===e.keyCode&&t.next()})}),x("UpdateStatus"+i,function(e,n){n.text&&(n.text=Y(n.text,t.currItem.index,t.items.length))}),x(p+i,function(e,i,o,r){var a=t.items.length;o.counter=a>1?Y(n.tCounter,r.index,a):""}),x("BuildControls"+i,function(){if(t.items.length>1&&n.arrows&&!t.arrowLeft){var i=n.arrowMarkup,o=t.arrowLeft=e(i.replace(/%title%/gi,n.tPrev).replace(/%dir%/gi,"left")).addClass(y),a=t.arrowRight=e(i.replace(/%title%/gi,n.tNext).replace(/%dir%/gi,"right")).addClass(y),s=r?"mfpFastClick":"click";o[s](function(){t.prev()}),a[s](function(){t.next()}),t.isIE7&&(k("b",o[0],!1,!0),k("a",o[0],!1,!0),k("b",a[0],!1,!0),k("a",a[0],!1,!0)),t.container.append(o.add(a))}}),x(m+i,function(){t._preloadTimeout&&clearTimeout(t._preloadTimeout),t._preloadTimeout=setTimeout(function(){t.preloadNearbyImages(),t._preloadTimeout=null},16)}),x(l+i,function(){o.off(i),t.wrap.off("click"+i),t.arrowLeft&&r&&t.arrowLeft.add(t.arrowRight).destroyMfpFastClick(),t.arrowRight=t.arrowLeft=null}),void 0):!1},next:function(){t.direction=!0,t.index=K(t.index+1),t.updateItemHTML()},prev:function(){t.direction=!1,t.index=K(t.index-1),t.updateItemHTML()},goTo:function(e){t.direction=e>=t.index,t.index=e,t.updateItemHTML()},preloadNearbyImages:function(){var e,n=t.st.gallery.preload,i=Math.min(n[0],t.items.length),o=Math.min(n[1],t.items.length);for(e=1;(t.direction?o:i)>=e;e++)t._preloadItem(t.index+e);for(e=1;(t.direction?i:o)>=e;e++)t._preloadItem(t.index-e)},_preloadItem:function(n){if(n=K(n),!t.items[n].preloaded){var i=t.items[n];i.parsed||(i=t.parseEl(n)),T("LazyLoad",i),"image"===i.type&&(i.img=e('<img class="mfp-img" />').on("load.mfploader",function(){i.hasSize=!0}).on("error.mfploader",function(){i.hasSize=!0,i.loadError=!0,T("LazyLoadError",i)}).attr("src",i.src)),i.preloaded=!0}}}});var U="retina";e.magnificPopup.registerModule(U,{options:{replaceSrc:function(e){return e.src.replace(/\.\w+$/,function(e){return"@2x"+e})},ratio:1},proto:{initRetina:function(){if(window.devicePixelRatio>1){var e=t.st.retina,n=e.ratio;n=isNaN(n)?n():n,n>1&&(x("ImageHasSize."+U,function(e,t){t.img.css({"max-width":t.img[0].naturalWidth/n,width:"100%"})}),x("ElementParse."+U,function(t,i){i.src=e.replaceSrc(i,n)}))}}}}),function(){var t=1e3,n="ontouchstart"in window,i=function(){I.off("touchmove"+r+" touchend"+r)},o="mfpFastClick",r="."+o;e.fn.mfpFastClick=function(o){return e(this).each(function(){var a,s=e(this);if(n){var l,c,d,u,p,f;s.on("touchstart"+r,function(e){u=!1,f=1,p=e.originalEvent?e.originalEvent.touches[0]:e.touches[0],c=p.clientX,d=p.clientY,I.on("touchmove"+r,function(e){p=e.originalEvent?e.originalEvent.touches:e.touches,f=p.length,p=p[0],(Math.abs(p.clientX-c)>10||Math.abs(p.clientY-d)>10)&&(u=!0,i())}).on("touchend"+r,function(e){i(),u||f>1||(a=!0,e.preventDefault(),clearTimeout(l),l=setTimeout(function(){a=!1},t),o())})})}s.on("click"+r,function(){a||o()})})},e.fn.destroyMfpFastClick=function(){e(this).off("touchstart"+r+" click"+r),n&&I.off("touchmove"+r+" touchend"+r)}}(),_()})(window.jQuery||window.Zepto);
/* 13 */ 
/* 14 */ 

;
/* jquery.jcarousellite.js */

/* 1 */ /*!
/* 2 *|  * jCarouselLite - v1.1 - 2014-09-28
/* 3 *|  * http://www.gmarwaha.com/jquery/jcarousellite/
/* 4 *|  * Copyright (c) 2014 Ganeshji Marwaha
/* 5 *|  * Licensed MIT (https://github.com/ganeshmax/jcarousellite/blob/master/LICENSE)
/* 6 *| */
/* 7 */ 
/* 8 */ !function(a){a.jCarouselLite={version:"1.1"},a.fn.jCarouselLite=function(b){return b=a.extend({},a.fn.jCarouselLite.options,b||{}),this.each(function(){function c(a){return n||(clearTimeout(A),z=a,b.beforeStart&&b.beforeStart.call(this,i()),b.circular?j(a):k(a),m({start:function(){n=!0},done:function(){b.afterEnd&&b.afterEnd.call(this,i()),b.auto&&h(),n=!1}}),b.circular||l()),!1}function d(){if(n=!1,o=b.vertical?"top":"left",p=b.vertical?"height":"width",q=B.find(">ul"),r=q.find(">li"),x=r.size(),w=x<b.visible?x:b.visible,b.circular){var c=r.slice(x-w).clone(),d=r.slice(0,w).clone();q.prepend(c).append(d),b.start+=w}s=a("li",q),y=s.size(),z=b.start}function e(){B.css("visibility","visible"),s.css({overflow:"hidden","float":b.vertical?"none":"left"}),q.css({margin:"0",padding:"0",position:"relative","list-style":"none","z-index":"1"}),B.css({overflow:"hidden",position:"relative","z-index":"2",left:"0px"}),!b.circular&&b.btnPrev&&0==b.start&&a(b.btnPrev).addClass("disabled")}function f(){t=b.vertical?s.outerHeight(!0):s.outerWidth(!0),u=t*y,v=t*w,s.css({width:s.width(),height:s.height()}),q.css(p,u+"px").css(o,-(z*t)),B.css(p,v+"px")}function g(){b.btnPrev&&a(b.btnPrev).click(function(){return c(z-b.scroll)}),b.btnNext&&a(b.btnNext).click(function(){return c(z+b.scroll)}),b.btnGo&&a.each(b.btnGo,function(d,e){a(e).click(function(){return c(b.circular?w+d:d)})}),b.mouseWheel&&B.mousewheel&&B.mousewheel(function(a,d){return c(d>0?z-b.scroll:z+b.scroll)}),b.auto&&h()}function h(){A=setTimeout(function(){c(z+b.scroll)},b.auto)}function i(){return s.slice(z).slice(0,w)}function j(a){var c;a<=b.start-w-1?(c=a+x+b.scroll,q.css(o,-(c*t)+"px"),z=c-b.scroll):a>=y-w+1&&(c=a-x-b.scroll,q.css(o,-(c*t)+"px"),z=c+b.scroll)}function k(a){0>a?z=0:a>y-w&&(z=y-w)}function l(){a(b.btnPrev+","+b.btnNext).removeClass("disabled"),a(z-b.scroll<0&&b.btnPrev||z+b.scroll>y-w&&b.btnNext||[]).addClass("disabled")}function m(c){n=!0,q.animate("left"==o?{left:-(z*t)}:{top:-(z*t)},a.extend({duration:b.speed,easing:b.easing},c))}var n,o,p,q,r,s,t,u,v,w,x,y,z,A,B=a(this);d(),e(),f(),g()})},a.fn.jCarouselLite.options={btnPrev:null,btnNext:null,btnGo:null,mouseWheel:!1,auto:null,speed:200,easing:null,vertical:!1,circular:!1,visible:3,start:0,scroll:1,beforeStart:null,afterEnd:null}}(jQuery);

;
/* jquery.countdown.js */

/* 1   */ /*!
/* 2   *|  * The Final Countdown for jQuery v2.1.0 (http://hilios.github.io/jQuery.countdown/)
/* 3   *|  * Copyright (c) 2015 Edson Hilios
/* 4   *|  * 
/* 5   *|  * Permission is hereby granted, free of charge, to any person obtaining a copy of
/* 6   *|  * this software and associated documentation files (the "Software"), to deal in
/* 7   *|  * the Software without restriction, including without limitation the rights to
/* 8   *|  * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
/* 9   *|  * the Software, and to permit persons to whom the Software is furnished to do so,
/* 10  *|  * subject to the following conditions:
/* 11  *|  * 
/* 12  *|  * The above copyright notice and this permission notice shall be included in all
/* 13  *|  * copies or substantial portions of the Software.
/* 14  *|  * 
/* 15  *|  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/* 16  *|  * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
/* 17  *|  * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
/* 18  *|  * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
/* 19  *|  * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
/* 20  *|  * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
/* 21  *|  */
/* 22  */ (function(factory) {
/* 23  */     "use strict";
/* 24  */     if (typeof define === "function" && define.amd) {
/* 25  */         define([ "jquery" ], factory);
/* 26  */     } else {
/* 27  */         factory(jQuery);
/* 28  */     }
/* 29  */ })(function($) {
/* 30  */     "use strict";
/* 31  */     var instances = [], matchers = [], defaultOptions = {
/* 32  */         precision: 100,
/* 33  */         elapse: false
/* 34  */     };
/* 35  */     matchers.push(/^[0-9]*$/.source);
/* 36  */     matchers.push(/([0-9]{1,2}\/){2}[0-9]{4}( [0-9]{1,2}(:[0-9]{2}){2})?/.source);
/* 37  */     matchers.push(/[0-9]{4}([\/\-][0-9]{1,2}){2}( [0-9]{1,2}(:[0-9]{2}){2})?/.source);
/* 38  */     matchers = new RegExp(matchers.join("|"));
/* 39  */     function parseDateString(dateString) {
/* 40  */         if (dateString instanceof Date) {
/* 41  */             return dateString;
/* 42  */         }
/* 43  */         if (String(dateString).match(matchers)) {
/* 44  */             if (String(dateString).match(/^[0-9]*$/)) {
/* 45  */                 dateString = Number(dateString);
/* 46  */             }
/* 47  */             if (String(dateString).match(/\-/)) {
/* 48  */                 dateString = String(dateString).replace(/\-/g, "http://opencart.magentech.com/");
/* 49  */             }
/* 50  */             return new Date(dateString);

/* jquery.countdown.js */

/* 51  */         } else {
/* 52  */             throw new Error("Couldn't cast `" + dateString + "` to a date object.");
/* 53  */         }
/* 54  */     }
/* 55  */     var DIRECTIVE_KEY_MAP = {
/* 56  */         Y: "years",
/* 57  */         m: "months",
/* 58  */         n: "daysToMonth",
/* 59  */         w: "weeks",
/* 60  */         d: "daysToWeek",
/* 61  */         D: "totalDays",
/* 62  */         H: "hours",
/* 63  */         M: "minutes",
/* 64  */         S: "seconds"
/* 65  */     };
/* 66  */     function escapedRegExp(str) {
/* 67  */         var sanitize = str.toString().replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1");
/* 68  */         return new RegExp(sanitize);
/* 69  */     }
/* 70  */     function strftime(offsetObject) {
/* 71  */         return function(format) {
/* 72  */             var directives = format.match(/%(-|!)?[A-Z]{1}(:[^;]+;)?/gi);
/* 73  */             if (directives) {
/* 74  */                 for (var i = 0, len = directives.length; i < len; ++i) {
/* 75  */                     var directive = directives[i].match(/%(-|!)?([a-zA-Z]{1})(:[^;]+;)?/), regexp = escapedRegExp(directive[0]), modifier = directive[1] || "", plural = directive[3] || "", value = null;
/* 76  */                     directive = directive[2];
/* 77  */                     if (DIRECTIVE_KEY_MAP.hasOwnProperty(directive)) {
/* 78  */                         value = DIRECTIVE_KEY_MAP[directive];
/* 79  */                         value = Number(offsetObject[value]);
/* 80  */                     }
/* 81  */                     if (value !== null) {
/* 82  */                         if (modifier === "!") {
/* 83  */                             value = pluralize(plural, value);
/* 84  */                         }
/* 85  */                         if (modifier === "") {
/* 86  */                             if (value < 10) {
/* 87  */                                 value = "0" + value.toString();
/* 88  */                             }
/* 89  */                         }
/* 90  */                         format = format.replace(regexp, value.toString());
/* 91  */                     }
/* 92  */                 }
/* 93  */             }
/* 94  */             format = format.replace(/%%/, "%");
/* 95  */             return format;
/* 96  */         };
/* 97  */     }
/* 98  */     function pluralize(format, count) {
/* 99  */         var plural = "s", singular = "";
/* 100 */         if (format) {

/* jquery.countdown.js */

/* 101 */             format = format.replace(/(:|;|\s)/gi, "").split(/\,/);
/* 102 */             if (format.length === 1) {
/* 103 */                 plural = format[0];
/* 104 */             } else {
/* 105 */                 singular = format[0];
/* 106 */                 plural = format[1];
/* 107 */             }
/* 108 */         }
/* 109 */         if (Math.abs(count) === 1) {
/* 110 */             return singular;
/* 111 */         } else {
/* 112 */             return plural;
/* 113 */         }
/* 114 */     }
/* 115 */     var Countdown = function(el, finalDate, options) {
/* 116 */         this.el = el;
/* 117 */         this.$el = $(el);
/* 118 */         this.interval = null;
/* 119 */         this.offset = {};
/* 120 */         this.options = $.extend({}, defaultOptions);
/* 121 */         this.instanceNumber = instances.length;
/* 122 */         instances.push(this);
/* 123 */         this.$el.data("countdown-instance", this.instanceNumber);
/* 124 */         if (options) {
/* 125 */             if (typeof options === "function") {
/* 126 */                 this.$el.on("update.countdown", options);
/* 127 */                 this.$el.on("stoped.countdown", options);
/* 128 */                 this.$el.on("finish.countdown", options);
/* 129 */             } else {
/* 130 */                 this.options = $.extend({}, defaultOptions, options);
/* 131 */             }
/* 132 */         }
/* 133 */         this.setFinalDate(finalDate);
/* 134 */         this.start();
/* 135 */     };
/* 136 */     $.extend(Countdown.prototype, {
/* 137 */         start: function() {
/* 138 */             if (this.interval !== null) {
/* 139 */                 clearInterval(this.interval);
/* 140 */             }
/* 141 */             var self = this;
/* 142 */             this.update();
/* 143 */             this.interval = setInterval(function() {
/* 144 */                 self.update.call(self);
/* 145 */             }, this.options.precision);
/* 146 */         },
/* 147 */         stop: function() {
/* 148 */             clearInterval(this.interval);
/* 149 */             this.interval = null;
/* 150 */             this.dispatchEvent("stoped");

/* jquery.countdown.js */

/* 151 */         },
/* 152 */         toggle: function() {
/* 153 */             if (this.interval) {
/* 154 */                 this.stop();
/* 155 */             } else {
/* 156 */                 this.start();
/* 157 */             }
/* 158 */         },
/* 159 */         pause: function() {
/* 160 */             this.stop();
/* 161 */         },
/* 162 */         resume: function() {
/* 163 */             this.start();
/* 164 */         },
/* 165 */         remove: function() {
/* 166 */             this.stop.call(this);
/* 167 */             instances[this.instanceNumber] = null;
/* 168 */             delete this.$el.data().countdownInstance;
/* 169 */         },
/* 170 */         setFinalDate: function(value) {
/* 171 */             this.finalDate = parseDateString(value);
/* 172 */         },
/* 173 */         update: function() {
/* 174 */             if (this.$el.closest("html").length === 0) {
/* 175 */                 this.remove();
/* 176 */                 return;
/* 177 */             }
/* 178 */             var hasEventsAttached = $._data(this.el, "events") !== undefined, now = new Date(), newTotalSecsLeft;
/* 179 */             newTotalSecsLeft = this.finalDate.getTime() - now.getTime();
/* 180 */             newTotalSecsLeft = Math.ceil(newTotalSecsLeft / 1e3);
/* 181 */             newTotalSecsLeft = !this.options.elapse && newTotalSecsLeft < 0 ? 0 : Math.abs(newTotalSecsLeft);
/* 182 */             if (this.totalSecsLeft === newTotalSecsLeft || !hasEventsAttached) {
/* 183 */                 return;
/* 184 */             } else {
/* 185 */                 this.totalSecsLeft = newTotalSecsLeft;
/* 186 */             }
/* 187 */             this.elapsed = now >= this.finalDate;
/* 188 */             this.offset = {
/* 189 */                 seconds: this.totalSecsLeft % 60,
/* 190 */                 minutes: Math.floor(this.totalSecsLeft / 60) % 60,
/* 191 */                 hours: Math.floor(this.totalSecsLeft / 60 / 60) % 24,
/* 192 */                 days: Math.floor(this.totalSecsLeft / 60 / 60 / 24) % 7,
/* 193 */                 daysToWeek: Math.floor(this.totalSecsLeft / 60 / 60 / 24) % 7,
/* 194 */                 daysToMonth: Math.floor(this.totalSecsLeft / 60 / 60 / 24 % 30.4368),
/* 195 */                 totalDays: Math.floor(this.totalSecsLeft / 60 / 60 / 24),
/* 196 */                 weeks: Math.floor(this.totalSecsLeft / 60 / 60 / 24 / 7),
/* 197 */                 months: Math.floor(this.totalSecsLeft / 60 / 60 / 24 / 30.4368),
/* 198 */                 years: Math.abs(this.finalDate.getFullYear() - now.getFullYear())
/* 199 */             };
/* 200 */             if (!this.options.elapse && this.totalSecsLeft === 0) {

/* jquery.countdown.js */

/* 201 */                 this.stop();
/* 202 */                 this.dispatchEvent("finish");
/* 203 */             } else {
/* 204 */                 this.dispatchEvent("update");
/* 205 */             }
/* 206 */         },
/* 207 */         dispatchEvent: function(eventName) {
/* 208 */             var event = $.Event(eventName + ".countdown");
/* 209 */             event.finalDate = this.finalDate;
/* 210 */             event.elapsed = this.elapsed;
/* 211 */             event.offset = $.extend({}, this.offset);
/* 212 */             event.strftime = strftime(this.offset);
/* 213 */             this.$el.trigger(event);
/* 214 */         }
/* 215 */     });
/* 216 */     $.fn.countdown = function() {
/* 217 */         var argumentsArray = Array.prototype.slice.call(arguments, 0);
/* 218 */         return this.each(function() {
/* 219 */             var instanceNumber = $(this).data("countdown-instance");
/* 220 */             if (instanceNumber !== undefined) {
/* 221 */                 var instance = instances[instanceNumber], method = argumentsArray[0];
/* 222 */                 if (Countdown.prototype.hasOwnProperty(method)) {
/* 223 */                     instance[method].apply(instance, argumentsArray.slice(1));
/* 224 */                 } else if (String(method).match(/^[$A-Z_][0-9A-Z_$]*$/i) === null) {
/* 225 */                     instance.setFinalDate.call(instance, method);
/* 226 */                     instance.start();
/* 227 */                 } else {
/* 228 */                     $.error("Method %s does not exist on jQuery.countdown".replace(/\%s/gi, method));
/* 229 */                 }
/* 230 */             } else {
/* 231 */                 new Countdown(this, argumentsArray[0], argumentsArray[1]);
/* 232 */             }
/* 233 */         });
/* 234 */     };
/* 235 */ });

;
/* common.js */

/* 1   */ function getURLVar(key) {
/* 2   */ 	var value = [];
/* 3   */ 
/* 4   */ 	var query = String(document.location).split('?');
/* 5   */ 
/* 6   */ 	if (query[1]) {
/* 7   */ 		var part = query[1].split('&');
/* 8   */ 
/* 9   */ 		for (i = 0; i < part.length; i++) {
/* 10  */ 			var data = part[i].split('=');
/* 11  */ 
/* 12  */ 			if (data[0] && data[1]) {
/* 13  */ 				value[data[0]] = data[1];
/* 14  */ 			}
/* 15  */ 		}
/* 16  */ 
/* 17  */ 		if (value[key]) {
/* 18  */ 			return value[key];
/* 19  */ 		} else {
/* 20  */ 			return '';
/* 21  */ 		}
/* 22  */ 	}
/* 23  */ }
/* 24  */ 
/* 25  */ $(document).ready(function() {
/* 26  */ 	
/* 27  */ 	
/* 28  */ 	// Highlight any found errors
/* 29  */ 	$('.text-danger').each(function() {
/* 30  */ 		var element = $(this).parent().parent();
/* 31  */ 		
/* 32  */ 		if (element.hasClass('form-group')) {
/* 33  */ 			element.addClass('has-error');
/* 34  */ 		}
/* 35  */ 	});
/* 36  */ 		
/* 37  */ 	// Currency
/* 38  */ 	$('#currency .currency-select').on('click', function(e) {
/* 39  */ 		e.preventDefault();
/* 40  */ 
/* 41  */ 		$('#currency input[name=\'code\']').attr('value', $(this).attr('name'));
/* 42  */ 
/* 43  */ 		$('#currency').submit();
/* 44  */ 	});
/* 45  */ 
/* 46  */ 	// Language
/* 47  */ 	$('#language a').on('click', function(e) {
/* 48  */ 		e.preventDefault();
/* 49  */ 
/* 50  */ 		$('#language input[name=\'code\']').attr('value', $(this).attr('href'));

/* common.js */

/* 51  */ 
/* 52  */ 		$('#language').submit();
/* 53  */ 	});
/* 54  */ 
/* 55  */ 	/* Search */
/* 56  */ 	$('#search input[name=\'search\']').parent().find('button').on('click', function() {
/* 57  */ 		url = $('base').attr('href') + 'index.php?route=product/search';
/* 58  */ 
/* 59  */ 		var value = $('header input[name=\'search\']').val();
/* 60  */ 
/* 61  */ 		if (value) {
/* 62  */ 			url += '&search=' + encodeURIComponent(value);
/* 63  */ 		}
/* 64  */ 
/* 65  */ 		location = url;
/* 66  */ 	});
/* 67  */ 
/* 68  */ 	$('#search input[name=\'search\']').on('keydown', function(e) {
/* 69  */ 		if (e.keyCode == 13) {
/* 70  */ 			$('header input[name=\'search\']').parent().find('button').trigger('click');
/* 71  */ 		}
/* 72  */ 	});
/* 73  */ 
/* 74  */ 	// Menu
/* 75  */ 	$('#menu .dropdown-menu').each(function() {
/* 76  */ 		var menu = $('#menu').offset();
/* 77  */ 		var dropdown = $(this).parent().offset();
/* 78  */ 
/* 79  */ 		var i = (dropdown.left + $(this).outerWidth()) - (menu.left + $('#menu').outerWidth());
/* 80  */ 
/* 81  */ 		if (i > 0) {
/* 82  */ 			$(this).css('margin-left', '-' + (i + 5) + 'px');
/* 83  */ 		}
/* 84  */ 	});
/* 85  */ 
/* 86  */ 	
/* 87  */ 	// tooltips on hover
/* 88  */ 	$('[data-toggle=\'tooltip\']').tooltip({container: 'body'});
/* 89  */ 
/* 90  */ 	// Makes tooltips work on ajax generated content
/* 91  */ 	/*$(document).ajaxStop(function() {
/* 92  *| 		$('[data-toggle=\'tooltip\']').tooltip({container: 'body'});
/* 93  *| 	});*/
/* 94  */ });
/* 95  */ 
/* 96  */ // Cart add remove functions
/* 97  */ var cart = {
/* 98  */ 	'add': function(product_id, quantity) {
/* 99  */ 		
/* 100 */ 		$.ajax({

/* common.js */

/* 101 */ 			url: 'index.php?route=soconfig/cart/add',
/* 102 */ 			type: 'post',
/* 103 */ 			data: 'product_id=' + product_id + '&quantity=' + (typeof(quantity) != 'undefined' ? quantity : 1),
/* 104 */ 			dataType: 'json',
/* 105 */ 			
/* 106 */ 			success: function(json) {
/* 107 */ 				if (json['redirect']) {
/* 108 */ 					location = json['redirect'];
/* 109 */ 				}
/* 110 */ 				
/* 111 */ 				if (json['success']) {
/* 112 */ 					
/* 113 */ 					 addProductNotice(json['title'], json['thumb'], json['success'], 'success');
/* 114 */ 					// Need to set timeout otherwise it wont update the total
/* 115 */ 					setTimeout(function () {
/* 116 */ 						$('#cart  .text-shopping-cart').html(json['total'] );
/* 117 */ 					}, 100);
/* 118 */ 					$('#cart > ul').load('index1e1c.html?route=common/cart/info%20ul%20li');
/* 119 */ 				}
/* 120 */ 			}
/* 121 */ 		});
/* 122 */ 	},
/* 123 */ 	'update': function(key, quantity) {
/* 124 */ 		$.ajax({
/* 125 */ 			url: 'index.php?route=checkout/cart/edit',
/* 126 */ 			type: 'post',
/* 127 */ 			data: 'key=' + key + '&quantity=' + (typeof(quantity) != 'undefined' ? quantity : 1),
/* 128 */ 			dataType: 'json',
/* 129 */ 				
/* 130 */ 			success: function(json) {
/* 131 */ 				// Need to set timeout otherwise it wont update the total
/* 132 */ 				setTimeout(function () {
/* 133 */ 					$('#cart  .text-shopping-cart').html( json['total'] );
/* 134 */ 				}, 100);
/* 135 */ 
/* 136 */ 				if (getURLVar('route') == 'checkout/cart' || getURLVar('route') == 'checkout/checkout') {
/* 137 */ 					location = 'index630e.html?route=checkout/cart';
/* 138 */ 				} else {
/* 139 */ 					$('#cart > ul').load('index1e1c.html?route=common/cart/info%20ul%20li');
/* 140 */ 				}
/* 141 */ 			}
/* 142 */ 		});
/* 143 */ 	},
/* 144 */ 	'remove': function(key) {
/* 145 */ 		$.ajax({
/* 146 */ 			url: 'index.php?route=checkout/cart/remove',
/* 147 */ 			type: 'post',
/* 148 */ 			data: 'key=' + key,
/* 149 */ 			dataType: 'json',
/* 150 */ 				

/* common.js */

/* 151 */ 			success: function(json) {
/* 152 */ 				// Need to set timeout otherwise it wont update the total
/* 153 */ 				setTimeout(function () {
/* 154 */ 					$('#cart  .text-shopping-cart').html(json['total'] );
/* 155 */ 				}, 100);
/* 156 */ 					
/* 157 */ 				if (getURLVar('route') == 'checkout/cart' || getURLVar('route') == 'checkout/checkout') {
/* 158 */ 					location = 'index630e.html?route=checkout/cart';
/* 159 */ 				} else {
/* 160 */ 					$('#cart > ul').load('index1e1c.html?route=common/cart/info%20ul%20li');
/* 161 */ 				}
/* 162 */ 			}
/* 163 */ 		});
/* 164 */ 	}
/* 165 */ }
/* 166 */ 
/* 167 */ var voucher = {
/* 168 */ 	'add': function() {
/* 169 */ 
/* 170 */ 	},
/* 171 */ 	'remove': function(key) {
/* 172 */ 		$.ajax({
/* 173 */ 			url: 'index.php?route=checkout/cart/remove',
/* 174 */ 			type: 'post',
/* 175 */ 			data: 'key=' + key,
/* 176 */ 			dataType: 'json',
/* 177 */ 			beforeSend: function() {
/* 178 */ 				$('#cart > button').button('loading');
/* 179 */ 			},
/* 180 */ 			complete: function() {
/* 181 */ 				$('#cart > button').button('reset');
/* 182 */ 			},
/* 183 */ 			success: function(json) {
/* 184 */ 				// Need to set timeout otherwise it wont update the total
/* 185 */ 				setTimeout(function () {
/* 186 */ 					$('#cart > button').html('<span id="cart-total"><i class="fa fa-shopping-cart"></i> ' + json['total'] + '</span>');
/* 187 */ 				}, 100);
/* 188 */ 
/* 189 */ 				if (getURLVar('route') == 'checkout/cart' || getURLVar('route') == 'checkout/checkout') {
/* 190 */ 					location = 'index630e.html?route=checkout/cart';
/* 191 */ 				} else {
/* 192 */ 					$('#cart > ul').load('index1e1c.html?route=common/cart/info%20ul%20li');
/* 193 */ 				}
/* 194 */ 			}
/* 195 */ 		});
/* 196 */ 	}
/* 197 */ }
/* 198 */ 
/* 199 */ var wishlist = {
/* 200 */ 	'add': function(product_id) {

/* common.js */

/* 201 */ 		$.ajax({
/* 202 */ 			url: 'index.php?route=soconfig/wishlist/add',
/* 203 */ 			type: 'post',
/* 204 */ 			data: 'product_id=' + product_id,
/* 205 */ 			dataType: 'json',
/* 206 */ 			success: function(json) {
/* 207 */ 				
/* 208 */ 				if (json['success']) {
/* 209 */ 					addProductNotice(json['title'], json['thumb'], json['success'], 'success');
/* 210 */ 				}
/* 211 */ 				if (json['info']) {
/* 212 */ 				  addProductNotice(json['title'], json['thumb'], json['info'], 'warning');
/* 213 */ 				}
/* 214 */ 				$('#wishlist-total').html(json['total']);
/* 215 */ 			}
/* 216 */ 		});
/* 217 */ 	}
/* 218 */ }
/* 219 */ 
/* 220 */ var compare = {
/* 221 */ 	'add': function(product_id) {
/* 222 */ 		$.ajax({
/* 223 */ 			url: 'index.php?route=soconfig/compare/add',
/* 224 */ 			type: 'post',
/* 225 */ 			data: 'product_id=' + product_id,
/* 226 */ 			dataType: 'json',
/* 227 */ 			success: function(json) {
/* 228 */ 				if (json['success']) {
/* 229 */ 					addProductNotice(json['title'], json['thumb'], json['success'], 'success');
/* 230 */ 					$('#compare-total').html(json['total']);
/* 231 */ 				}
/* 232 */ 			}
/* 233 */ 		});
/* 234 */ 	}
/* 235 */ 	
/* 236 */ }
/* 237 */ 
/* 238 */ 
/* 239 */ /* Common alert */
/* 240 */ function addProductNotice(title, thumb, text, type) {
/* 241 */ 	$.jGrowl.defaults.closer = false;
/* 242 */ 	//Stop jGrowl
/* 243 */ 	//$.jGrowl.defaults.sticky = true;
/* 244 */ 	var tpl = thumb + '<h3>'+text+'</h3>';
/* 245 */ 	$.jGrowl(tpl, {		
/* 246 */ 		life: 4000,
/* 247 */ 		header: title,
/* 248 */ 		speed: 'slow',
/* 249 */ 		theme: type
/* 250 */ 	});

/* common.js */

/* 251 */ }
/* 252 */ 
/* 253 */ /* Agree to Terms */
/* 254 */ $(document).delegate('.agree', 'click', function(e) {
/* 255 */ 	e.preventDefault();
/* 256 */ 	$('#modal-agree').remove();
/* 257 */ 
/* 258 */ 	var element = this;
/* 259 */ 	$.ajax({
/* 260 */ 		url: $(element).attr('href'),
/* 261 */ 		type: 'get',
/* 262 */ 		dataType: 'html',
/* 263 */ 		success: function(data) {
/* 264 */ 			html  = '<div id="modal-agree" class="modal">';
/* 265 */ 			html += '  <div class="modal-dialog">';
/* 266 */ 			html += '    <div class="modal-content">';
/* 267 */ 			html += '      <div class="modal-header">';
/* 268 */ 			html += '        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';
/* 269 */ 			html += '        <h4 class="modal-title">' + $(element).text() + '</h4>';
/* 270 */ 			html += '      </div>';
/* 271 */ 			html += '      <div class="modal-body">' + data + '</div>';
/* 272 */ 			html += '    </div';
/* 273 */ 			html += '  </div>';
/* 274 */ 			html += '</div>';
/* 275 */ 
/* 276 */ 			$('body').append(html);
/* 277 */ 
/* 278 */ 			$('#modal-agree').modal('show');
/* 279 */ 		}
/* 280 */ 	});
/* 281 */ });
/* 282 */ 
/* 283 */ /* Autocomplete */
/* 284 */ (function($) {
/* 285 */ 	function Autocomplete(element, options) {
/* 286 */ 		this.element = element;
/* 287 */ 		this.options = options;
/* 288 */ 		this.timer = null;
/* 289 */ 		this.items = new Array();
/* 290 */ 
/* 291 */ 		$(element).attr('autocomplete', 'off');
/* 292 */ 		$(element).on('focus', $.proxy(this.focus, this));
/* 293 */ 		$(element).on('blur', $.proxy(this.blur, this));
/* 294 */ 		$(element).on('keydown', $.proxy(this.keydown, this));
/* 295 */ 
/* 296 */ 		$(element).after('<ul class="dropdown-menu"></ul>');
/* 297 */ 		$(element).siblings('ul.dropdown-menu').delegate('a', 'click', $.proxy(this.click, this));
/* 298 */ 	}
/* 299 */ 
/* 300 */ 	Autocomplete.prototype = {

/* common.js */

/* 301 */ 		focus: function() {
/* 302 */ 			this.request();
/* 303 */ 		},
/* 304 */ 		blur: function() {
/* 305 */ 			setTimeout(function(object) {
/* 306 */ 				object.hide();
/* 307 */ 			}, 200, this);
/* 308 */ 		},
/* 309 */ 		click: function(event) {
/* 310 */ 			event.preventDefault();
/* 311 */ 
/* 312 */ 			value = $(event.target).parent().attr('data-value');
/* 313 */ 
/* 314 */ 			if (value && this.items[value]) {
/* 315 */ 				this.options.select(this.items[value]);
/* 316 */ 			}
/* 317 */ 		},
/* 318 */ 		keydown: function(event) {
/* 319 */ 			switch(event.keyCode) {
/* 320 */ 				case 27: // escape
/* 321 */ 					this.hide();
/* 322 */ 					break;
/* 323 */ 				default:
/* 324 */ 					this.request();
/* 325 */ 					break;
/* 326 */ 			}
/* 327 */ 		},
/* 328 */ 		show: function() {
/* 329 */ 			var pos = $(this.element).position();
/* 330 */ 
/* 331 */ 			$(this.element).siblings('ul.dropdown-menu').css({
/* 332 */ 				top: pos.top + $(this.element).outerHeight(),
/* 333 */ 				left: pos.left
/* 334 */ 			});
/* 335 */ 
/* 336 */ 			$(this.element).siblings('ul.dropdown-menu').show();
/* 337 */ 		},
/* 338 */ 		hide: function() {
/* 339 */ 			$(this.element).siblings('ul.dropdown-menu').hide();
/* 340 */ 		},
/* 341 */ 		request: function() {
/* 342 */ 			clearTimeout(this.timer);
/* 343 */ 
/* 344 */ 			this.timer = setTimeout(function(object) {
/* 345 */ 				object.options.source($(object.element).val(), $.proxy(object.response, object));
/* 346 */ 			}, 200, this);
/* 347 */ 		},
/* 348 */ 		response: function(json) {
/* 349 */ 			html = '';
/* 350 */ 

/* common.js */

/* 351 */ 			if (json.length) {
/* 352 */ 				for (i = 0; i < json.length; i++) {
/* 353 */ 					this.items[json[i]['value']] = json[i];
/* 354 */ 				}
/* 355 */ 
/* 356 */ 				for (i = 0; i < json.length; i++) {
/* 357 */ 					if (!json[i]['category']) {
/* 358 */ 						html += '<li data-value="' + json[i]['value'] + '"><a href="#">' + json[i]['label'] + '</a></li>';
/* 359 */ 					}
/* 360 */ 				}
/* 361 */ 
/* 362 */ 				// Get all the ones with a categories
/* 363 */ 				var category = new Array();
/* 364 */ 
/* 365 */ 				for (i = 0; i < json.length; i++) {
/* 366 */ 					if (json[i]['category']) {
/* 367 */ 						if (!category[json[i]['category']]) {
/* 368 */ 							category[json[i]['category']] = new Array();
/* 369 */ 							category[json[i]['category']]['name'] = json[i]['category'];
/* 370 */ 							category[json[i]['category']]['item'] = new Array();
/* 371 */ 						}
/* 372 */ 
/* 373 */ 						category[json[i]['category']]['item'].push(json[i]);
/* 374 */ 					}
/* 375 */ 				}
/* 376 */ 
/* 377 */ 				for (i in category) {
/* 378 */ 					html += '<li class="dropdown-header">' + category[i]['name'] + '</li>';
/* 379 */ 
/* 380 */ 					for (j = 0; j < category[i]['item'].length; j++) {
/* 381 */ 						html += '<li data-value="' + category[i]['item'][j]['value'] + '"><a href="#">&nbsp;&nbsp;&nbsp;' + category[i]['item'][j]['label'] + '</a></li>';
/* 382 */ 					}
/* 383 */ 				}
/* 384 */ 			}
/* 385 */ 
/* 386 */ 			if (html) {
/* 387 */ 				this.show();
/* 388 */ 			} else {
/* 389 */ 				this.hide();
/* 390 */ 			}
/* 391 */ 
/* 392 */ 			$(this.element).siblings('ul.dropdown-menu').html(html);
/* 393 */ 		}
/* 394 */ 	};
/* 395 */ 
/* 396 */ 	$.fn.autocomplete = function(option) {
/* 397 */ 		return this.each(function() {
/* 398 */ 			var data = $(this).data('autocomplete');
/* 399 */ 
/* 400 */ 			if (!data) {

/* common.js */

/* 401 */ 				data = new Autocomplete(this, option);
/* 402 */ 
/* 403 */ 				$(this).data('autocomplete', data);
/* 404 */ 			}
/* 405 */ 		});
/* 406 */ 	}
/* 407 */ })(window.jQuery);

;
/* so.custom.js */

/* 1   */ 
/* 2   */ jQuery(function ($) {
/* 3   */     // Related Products Detail 
/* 4   */ 	$('.iframe-link').magnificPopup({
/* 5   */ 		type:'iframe',
/* 6   */ 	    fixedContentPos: true,
/* 7   */         fixedBgPos: true,
/* 8   */         overflowY: 'auto',
/* 9   */         closeBtnInside: true,
/* 10  */ 		closeOnContentClick: true,
/* 11  */         preloader: true,
/* 12  */ 		midClick: true,
/* 13  */ 		removalDelay: 300,
/* 14  */ 		mainClass: 'my-mfp-zoom-in',
/* 15  */ 		callbacks: {
/* 16  */ 			markupParse: function(template, values, item) {
/* 17  */ 			   template.find('iframe').addClass('zoom-anim-dialog ');
/* 18  */ 		   }
/* 19  */ 		}
/* 20  */     });
/* 21  */ 	
/* 22  */ 	$('.closePopup').on( "click", function(e) {
/* 23  */ 	    e.preventDefault();
/* 24  */ 	    if (window.parent == window.top) {
/* 25  */ 			window.open($(this).attr("href"));
/* 26  */ 		    window.parent.$.magnificPopup.close();
/* 27  */ 	    }
/* 28  */ 	});
/* 29  */ });
/* 30  */ 
/* 31  */ jQuery(function ($) {
/* 32  */     "use strict";
/* 33  */ 	//Quantity plus minus 
/* 34  */     $.initQuantity = function ($control) {
/* 35  */         $control.each(function () {
/* 36  */             var $this = $(this),
/* 37  */                 data = $this.data("inited-control"),
/* 38  */                 $plus = $(".input-group-addon:last", $this),
/* 39  */                 $minus = $(".input-group-addon:first", $this),
/* 40  */                 $value = $(".form-control", $this);
/* 41  */             if (!data) {
/* 42  */                 $control.attr("unselectable", "on").css({
/* 43  */                     "-moz-user-select": "none",
/* 44  */                     "-o-user-select": "none",
/* 45  */                     "-khtml-user-select": "none",
/* 46  */                     "-webkit-user-select": "none",
/* 47  */                     "-ms-user-select": "none",
/* 48  */                     "user-select": "none"
/* 49  */                 }).bind("selectstart", function () {
/* 50  */                     return false

/* so.custom.js */

/* 51  */                 });
/* 52  */                 $plus.click(function () {
/* 53  */                     var val =
/* 54  */                         parseInt($value.val()) + 1;
/* 55  */                     $value.val(val);
/* 56  */                     return false
/* 57  */                 });
/* 58  */                 $minus.click(function () {
/* 59  */                     var val = parseInt($value.val()) - 1;
/* 60  */                     $value.val(val > 0 ? val : 1);
/* 61  */                     return false
/* 62  */                 });
/* 63  */                 $value.blur(function () {
/* 64  */                     var val = parseInt($value.val());
/* 65  */                     $value.val(val > 0 ? val : 1)
/* 66  */                 })
/* 67  */             }
/* 68  */         })
/* 69  */     };
/* 70  */     $.initQuantity($(".quantity-control"));
/* 71  */     $.initSelect = function ($select) {
/* 72  */         $select.each(function () {
/* 73  */             var $this = $(this),
/* 74  */                 data = $this.data("inited-select"),
/* 75  */                 $value = $(".value", $this),
/* 76  */                 $hidden = $(".input-hidden", $this),
/* 77  */                 $items = $(".dropdown-menu li > a", $this);
/* 78  */             if (!data) {
/* 79  */                 $items.click(function (e) {
/* 80  */                     if ($(this).closest(".sort-isotope").length >
/* 81  */                         0) e.preventDefault();
/* 82  */                     var data = $(this).attr("data-value"),
/* 83  */                         dataHTML = $(this).html();
/* 84  */                     $this.trigger("change", {
/* 85  */                         value: data,
/* 86  */                         html: dataHTML
/* 87  */                     });
/* 88  */                     $value.html(dataHTML);
/* 89  */                     if ($hidden.length) $hidden.val(data)
/* 90  */                 });
/* 91  */                 $this.data("inited-select", true)
/* 92  */             }
/* 93  */         })
/* 94  */     };
/* 95  */     $.initSelect($(".btn-select"))
/* 96  */ });
/* 97  */ 
/* 98  */ 
/* 99  */ /******** Social Widgets Accounts ********/
/* 100 */ jQuery(function ($) {

/* so.custom.js */

/* 101 */     "use strict";
/* 102 */     var socialItems = $('.social-widgets .items .item');
/* 103 */     var counter = 0;
/* 104 */     socialItems.each(function () {
/* 105 */         counter++;
/* 106 */         var itemclass = "item-0" + counter;
/* 107 */         $(this).addClass(itemclass)
/* 108 */     });
/* 109 */ });
/* 110 */ 
/* 111 */ jQuery(function ($) {
/* 112 */     "use strict";
/* 113 */     $(".social-widgets .item").each(function () {
/* 114 */         var $this = $(this),
/* 115 */             timer;
/* 116 */         $this.on("mouseenter", function () {
/* 117 */             var $this = $(this);
/* 118 */             if (timer) clearTimeout(timer);
/* 119 */             timer = setTimeout(function () {
/* 120 */                 $this.addClass("active")
/* 121 */             }, 200)
/* 122 */         }).on("mouseleave", function () {
/* 123 */             var $this = $(this);
/* 124 */             if (timer) clearTimeout(timer);
/* 125 */             timer = setTimeout(function () {
/* 126 */                 $this.removeClass("active")
/* 127 */             }, 100)
/* 128 */         }).on("click", function (e) {
/* 129 */             e.preventDefault()
/* 130 */         })
/* 131 */     })
/* 132 */ });
/* 133 */ 
/* 134 */ jQuery(function ($) {
/* 135 */     "use strict";
/* 136 */     var loadmap = $(".social-widgets .item a");
/* 137 */     loadmap.click(function (e) {
/* 138 */         e.preventDefault()
/* 139 */     });
/* 140 */     loadmap.hover(function (e) {
/* 141 */         if (!$(this).parent().hasClass("load")) {
/* 142 */             var loadcontainer = $(this).parent().find(".loading");
/* 143 */             $.ajax({
/* 144 */                 url: $(this).attr("href"),
/* 145 */                 cache: false,
/* 146 */                 success: function (data) {
/* 147 */                     setTimeout(function () {
/* 148 */                         loadcontainer.html(data)
/* 149 */                     }, 1000)
/* 150 */                 }

/* so.custom.js */

/* 151 */             });
/* 152 */             $(this).parent().addClass("load")
/* 153 */         }
/* 154 */     })
/* 155 */ });
/* 156 */ /******** End Social Widgets Accounts ********/
/* 157 */ $(window).load(function () {
/* 158 */ 	//loading spinner Website Site
/* 159 */ 	$("#wrapper > .loader").fadeOut("slow");
/* 160 */ });
/* 161 */ $(document).ready(function(){
/* 162 */ 	
/* 163 */ 	/*Scroll to top */
/* 164 */ 	$(".back-to-top").addClass("hidden-top");
/* 165 */ 		$(window).scroll(function () {
/* 166 */ 		if ($(this).scrollTop() === 0) {
/* 167 */ 			$(".back-to-top").addClass("hidden-top")
/* 168 */ 		} else {
/* 169 */ 			$(".back-to-top").removeClass("hidden-top")
/* 170 */ 		}
/* 171 */ 	});
/* 172 */ 
/* 173 */ 	$('.back-to-top').click(function () {
/* 174 */ 		$('body,html').animate({scrollTop:0}, 1200);
/* 175 */ 		return false;
/* 176 */ 	});		
/* 177 */ 	
/* 178 */ 	
/* 179 */ 	/******** Menu Show Hide Sub Menu ********/
/* 180 */ 	$('#menu .nav > li').mouseover(function() {
/* 181 */ 		$screensize = $(window).width();
/* 182 */ 		if ($screensize > 991) {
/* 183 */ 		$(this).find('> div').stop(true, true).slideDown('fast');
/* 184 */ 		}			
/* 185 */ 		$(this).bind('mouseleave', function() {
/* 186 */ 			$screensize = $(window).width();
/* 187 */ 		if ($screensize > 991) {
/* 188 */ 			$(this).find('> div').stop(true, true).css('display', 'none');
/* 189 */ 		}
/* 190 */ 	});});
/* 191 */ 
/* 192 */ 	$('#menu .nav > li.categories > div > .column, #menu .nav > li div > ul > li').mouseover(function() {
/* 193 */ 		$screensize = $(window).width();
/* 194 */ 		if ($screensize > 991) {
/* 195 */ 		$(this).find('> div').css('display', 'block');
/* 196 */ 		}			
/* 197 */ 		$(this).bind('mouseleave', function() {
/* 198 */ 			$screensize = $(window).width();
/* 199 */ 		if ($screensize > 991) {
/* 200 */ 			$(this).find('> div').css('display', 'none');

/* so.custom.js */

/* 201 */ 		}
/* 202 */ 	});});
/* 203 */ 
/* 204 */ 	$('#menu .nav > li > div').closest("li").addClass('sub');
/* 205 */ 
/* 206 */ 	/******** Navigation Menu ********/
/* 207 */ 	$('#menu .navbar-header > span').click(function () {
/* 208 */ 		  $(this).toggleClass("active");  
/* 209 */ 		  $("#menu .navbar-menu").slideToggle('medium');
/* 210 */ 	});
/* 211 */ 	
/* 212 */ 	if($('#menu .navbar-header span').hasClass("active")){
/* 213 */ 		$("#menu .navbar-menu").slideUp('medium');  
/* 214 */ 	}  
/* 215 */ 	
/* 216 */ 	$('#menu .nav > li > div > .column > div, .submenu, #menu .nav > li > div').before('<span class="submore"></span>');
/* 217 */ 			$('span.submore').click(function () {
/* 218 */ 				$(this).next().slideToggle('fast');
/* 219 */ 				$(this).toggleClass('plus');
/* 220 */ 	});
/* 221 */ 	
/* 222 */ 	/******** Language and Currency Dropdowns ********/
/* 223 */ 	$screensize = $(window).width();
/* 224 */ 	if ($screensize > 991) {
/* 225 */ 	$('#currency, #bt-language, #my_account').hover(function() {
/* 226 */ 		$(this).find('ul').stop(true, true).slideDown('fast');
/* 227 */ 	  },function() {
/* 228 */ 		$(this).find('ul').stop(true, true).css('display', 'none');
/* 229 */ 	  });
/* 230 */ 	}
/* 231 */ 	// Product detial reviews button
/* 232 */ 	$(".reviews_button,.write_review_button").click(function (){
/* 233 */         var tabTop = $(".producttab").offset().top;
/* 234 */         $("html, body").animate({ scrollTop:tabTop }, 1000);
/* 235 */     });
/* 236 */    
/* 237 */     // Resonsive Header Top
/* 238 */     $(".collapsed-block .expander").click(function (e) {
/* 239 */         var collapse_content_selector = $(this).attr("href");
/* 240 */         var expander = $(this);
/* 241 */ 		
/* 242 */         if (!$(collapse_content_selector).hasClass("open")) {
/* 243 */ 			expander.addClass("open").html("<i class='fa fa-angle-up'></i>") ;
/* 244 */ 		}
/* 245 */ 		else expander.removeClass("open").html("<i class='fa fa-angle-down'></i>");
/* 246 */ 		
/* 247 */ 		if (!$(collapse_content_selector).hasClass("open")) $(collapse_content_selector).addClass("open").slideDown("normal");
/* 248 */         else $(collapse_content_selector).removeClass("open").slideUp("normal");
/* 249 */         e.preventDefault()
/* 250 */     })

/* so.custom.js */

/* 251 */ 
/* 252 */ 
/* 253 */     
/* 254 */     // style for header top link
/* 255 */ 	$(".header-top-right .top-link > li").mouseenter(function(){
/* 256 */ 		$(".header-top-right .top-link > li.account").addClass('inactive');
/* 257 */ 	});
/* 258 */ 	$(".header-top-right .top-link > li").mouseleave(function(){
/* 259 */ 		$(".header-top-right .top-link > li.account").removeClass('inactive');
/* 260 */ 	});
/* 261 */ 	$(".header-top-right .top-link > li.account").mouseenter(function(){
/* 262 */ 		$(".header-top-right .top-link > li.account").removeClass('inactive');
/* 263 */ 	});
/* 264 */ 	
/* 265 */ 	//Client Say
/* 266 */ 	$('.slider-clients-say').owlCarousel2({
/* 267 */ 		pagination: false,
/* 268 */ 		center: false,
/* 269 */ 		nav: true,
/* 270 */ 		loop: false,
/* 271 */ 		margin: 25,
/* 272 */ 		navText: [ 'prev', 'next' ],
/* 273 */ 		slideBy: 1,
/* 274 */ 		autoplay: false,
/* 275 */ 		autoplayTimeout: 2500,
/* 276 */ 		autoplayHoverPause: true,
/* 277 */ 		autoplaySpeed: 800,
/* 278 */ 		startPosition: 0, 
/* 279 */ 		responsive:{
/* 280 */ 			0:{
/* 281 */ 				items:1
/* 282 */ 			},
/* 283 */ 			480:{
/* 284 */ 				items:1
/* 285 */ 			},
/* 286 */ 			768:{
/* 287 */ 				items:1
/* 288 */ 			},
/* 289 */ 			1200:{
/* 290 */ 				items:1
/* 291 */ 			}
/* 292 */ 		}
/* 293 */ 	});	 
/* 294 */ 
/* 295 */ });
/* 296 */ 
/* 297 */ 

;
/* owl.carousel.js */

/* 1    */ /**
/* 2    *|  * Owl2 carousel2
/* 3    *|  * @version 2.0.0
/* 4    *|  * @author Bartosz Wojciechowski
/* 5    *|  * @license The MIT License (MIT)
/* 6    *|  * @todo Lazy Load Icon
/* 7    *|  * @todo prevent animationend bubling
/* 8    *|  * @todo itemsScaleUp
/* 9    *|  * @todo Test Zepto
/* 10   *|  * @todo stagePadding calculate wrong active classes
/* 11   *|  */
/* 12   */ ;(function($, window, document, undefined) {
/* 13   */ 
/* 14   */     var drag, state, e;
/* 15   */ 
/* 16   */     /**
/* 17   *|      * Template for status information about drag and touch events.
/* 18   *|      * @private
/* 19   *|      */
/* 20   */     drag = {
/* 21   */         start: 0,
/* 22   */         startX: 0,
/* 23   */         startY: 0,
/* 24   */         current: 0,
/* 25   */         currentX: 0,
/* 26   */         currentY: 0,
/* 27   */         offsetX: 0,
/* 28   */         offsetY: 0,
/* 29   */         distance: null,
/* 30   */         startTime: 0,
/* 31   */         endTime: 0,
/* 32   */         updatedX: 0,
/* 33   */         targetEl: null
/* 34   */     };
/* 35   */ 
/* 36   */     /**
/* 37   *|      * Template for some status informations.
/* 38   *|      * @private
/* 39   *|      */
/* 40   */     state = {
/* 41   */         isTouch: false,
/* 42   */         isScrolling: false,
/* 43   */         isSwiping: false,
/* 44   */         direction: false,
/* 45   */         inMotion: false
/* 46   */     };
/* 47   */ 
/* 48   */     /**
/* 49   *|      * Event functions references.
/* 50   *|      * @private

/* owl.carousel.js */

/* 51   *|      */
/* 52   */     e = {
/* 53   */         _onDragStart: null,
/* 54   */         _onDragMove: null,
/* 55   */         _onDragEnd: null,
/* 56   */         _transitionEnd: null,
/* 57   */         _resizer: null,
/* 58   */         _responsiveCall: null,
/* 59   */         _goToLoop: null,
/* 60   */         _checkVisibile: null
/* 61   */     };
/* 62   */ 
/* 63   */     /**
/* 64   *|      * Creates a carousel2.
/* 65   *|      * @class The Owl2 Carousel.
/* 66   *|      * @public
/* 67   *|      * @param {HTMLElement|jQuery} element - The element to create the carousel2 for.
/* 68   *|      * @param {Object} [options] - The options
/* 69   *|      */
/* 70   */     function Owl2(element, options) {
/* 71   */ 
/* 72   */         /**
/* 73   *|          * Current settings for the carousel2.
/* 74   *|          * @public
/* 75   *|          */
/* 76   */         this.settings = null;
/* 77   */ 
/* 78   */         /**
/* 79   *|          * Current options set by the caller including defaults.
/* 80   *|          * @public
/* 81   *|          */
/* 82   */         this.options = $.extend({}, Owl2.Defaults, options);
/* 83   */ 
/* 84   */         /**
/* 85   *|          * Plugin element.
/* 86   *|          * @public
/* 87   *|          */
/* 88   */         this.$element = $(element);
/* 89   */ 
/* 90   */         /**
/* 91   *|          * Caches informations about drag and touch events.
/* 92   *|          */
/* 93   */         this.drag = $.extend({}, drag);
/* 94   */ 
/* 95   */         /**
/* 96   *|          * Caches some status informations.
/* 97   *|          * @protected
/* 98   *|          */
/* 99   */         this.state = $.extend({}, state);
/* 100  */ 

/* owl.carousel.js */

/* 101  */         /**
/* 102  *|          * @protected
/* 103  *|          * @todo Must be documented
/* 104  *|          */
/* 105  */         this.e = $.extend({}, e);
/* 106  */ 
/* 107  */         /**
/* 108  *|          * References to the running plugins of this carousel2.
/* 109  *|          * @protected
/* 110  *|          */
/* 111  */         this._plugins = {};
/* 112  */ 
/* 113  */         /**
/* 114  *|          * Currently suppressed events to prevent them from beeing retriggered.
/* 115  *|          * @protected
/* 116  *|          */
/* 117  */         this._supress = {};
/* 118  */ 
/* 119  */         /**
/* 120  *|          * Absolute current position.
/* 121  *|          * @protected
/* 122  *|          */
/* 123  */         this._current = null;
/* 124  */ 
/* 125  */         /**
/* 126  *|          * Animation speed in milliseconds.
/* 127  *|          * @protected
/* 128  *|          */
/* 129  */         this._speed = null;
/* 130  */ 
/* 131  */         /**
/* 132  *|          * Coordinates of all items in pixel.
/* 133  *|          * @todo The name of this member is missleading.
/* 134  *|          * @protected
/* 135  *|          */
/* 136  */         this._coordinates = [];
/* 137  */ 
/* 138  */         /**
/* 139  *|          * Current breakpoint.
/* 140  *|          * @todo Real media queries would be nice.
/* 141  *|          * @protected
/* 142  *|          */
/* 143  */         this._breakpoint = null;
/* 144  */ 
/* 145  */         /**
/* 146  *|          * Current width of the plugin element.
/* 147  *|          */
/* 148  */         this._width = null;
/* 149  */ 
/* 150  */         /**

/* owl.carousel.js */

/* 151  *|          * All real items.
/* 152  *|          * @protected
/* 153  *|          */
/* 154  */         this._items = [];
/* 155  */ 
/* 156  */         /**
/* 157  *|          * All cloned items.
/* 158  *|          * @protected
/* 159  *|          */
/* 160  */         this._clones = [];
/* 161  */ 
/* 162  */         /**
/* 163  *|          * Merge values of all items.
/* 164  *|          * @todo Maybe this could be part of a plugin.
/* 165  *|          * @protected
/* 166  *|          */
/* 167  */         this._mergers = [];
/* 168  */ 
/* 169  */         /**
/* 170  *|          * Invalidated parts within the update process.
/* 171  *|          * @protected
/* 172  *|          */
/* 173  */         this._invalidated = {};
/* 174  */ 
/* 175  */         /**
/* 176  *|          * Ordered list of workers for the update process.
/* 177  *|          * @protected
/* 178  *|          */
/* 179  */         this._pipe = [];
/* 180  */ 
/* 181  */         $.each(Owl2.Plugins, $.proxy(function(key, plugin) {
/* 182  */             this._plugins[key[0].toLowerCase() + key.slice(1)]
/* 183  */                 = new plugin(this);
/* 184  */         }, this));
/* 185  */ 
/* 186  */         $.each(Owl2.Pipe, $.proxy(function(priority, worker) {
/* 187  */             this._pipe.push({
/* 188  */                 'filter': worker.filter,
/* 189  */                 'run': $.proxy(worker.run, this)
/* 190  */             });
/* 191  */         }, this));
/* 192  */ 
/* 193  */         this.setup();
/* 194  */         this.initialize();
/* 195  */     }
/* 196  */ 
/* 197  */     /**
/* 198  *|      * Default options for the carousel2.
/* 199  *|      * @public
/* 200  *|      */

/* owl.carousel.js */

/* 201  */     Owl2.Defaults = {
/* 202  */         items: 3,
/* 203  */         loop: false,
/* 204  */         center: false,
/* 205  */ 
/* 206  */         mouseDrag: true,
/* 207  */         touchDrag: true,
/* 208  */         pullDrag: true,
/* 209  */         freeDrag: false,
/* 210  */ 
/* 211  */         margin: 0,
/* 212  */         stagePadding: 0,
/* 213  */ 
/* 214  */         merge: false,
/* 215  */         mergeFit: true,
/* 216  */         autoWidth: false,
/* 217  */ 
/* 218  */         startPosition: 0,
/* 219  */         rtl: false,
/* 220  */ 
/* 221  */         smartSpeed: 250,
/* 222  */         fluidSpeed: false,
/* 223  */         dragEndSpeed: false,
/* 224  */ 
/* 225  */         responsive: {},
/* 226  */         responsiveRefreshRate: 200,
/* 227  */         responsiveBaseElement: window,
/* 228  */         responsiveClass: false,
/* 229  */ 
/* 230  */         fallbackEasing: 'swing',
/* 231  */ 
/* 232  */         info: false,
/* 233  */ 
/* 234  */         nestedItemSelector: false,
/* 235  */         itemElement: 'div',
/* 236  */         stageElement: 'div',
/* 237  */ 
/* 238  */         // Classes and Names
/* 239  */         themeClass: 'owl2-theme',
/* 240  */         baseClass: 'owl2-carousel',
/* 241  */         itemClass: 'owl2-item',
/* 242  */         centerClass: 'center',
/* 243  */         activeClass: 'active'
/* 244  */     };
/* 245  */ 
/* 246  */     /**
/* 247  *|      * Enumeration for width.
/* 248  *|      * @public
/* 249  *|      * @readonly
/* 250  *|      * @enum {String}

/* owl.carousel.js */

/* 251  *|      */
/* 252  */     Owl2.Width = {
/* 253  */         Default: 'default',
/* 254  */         Inner: 'inner',
/* 255  */         Outer: 'outer'
/* 256  */     };
/* 257  */ 
/* 258  */     /**
/* 259  *|      * Contains all registered plugins.
/* 260  *|      * @public
/* 261  *|      */
/* 262  */     Owl2.Plugins = {};
/* 263  */ 
/* 264  */     /**
/* 265  *|      * Update pipe.
/* 266  *|      */
/* 267  */     Owl2.Pipe = [ {
/* 268  */         filter: [ 'width', 'items', 'settings' ],
/* 269  */         run: function(cache) {
/* 270  */             cache.current = this._items && this._items[this.relative(this._current)];
/* 271  */         }
/* 272  */     }, {
/* 273  */         filter: [ 'items', 'settings' ],
/* 274  */         run: function() {
/* 275  */             var cached = this._clones,
/* 276  */                 clones = this.$stage.children('.cloned');
/* 277  */ 
/* 278  */             if (clones.length !== cached.length || (!this.settings.loop && cached.length > 0)) {
/* 279  */                 this.$stage.children('.cloned').remove();
/* 280  */                 this._clones = [];
/* 281  */             }
/* 282  */         }
/* 283  */     }, {
/* 284  */         filter: [ 'items', 'settings' ],
/* 285  */         run: function() {
/* 286  */             var i, n,
/* 287  */                 clones = this._clones,
/* 288  */                 items = this._items,
/* 289  */                 delta = this.settings.loop ? clones.length - Math.max(this.settings.items * 2, 4) : 0;
/* 290  */ 
/* 291  */             for (i = 0, n = Math.abs(delta / 2); i < n; i++) {
/* 292  */                 if (delta > 0) {
/* 293  */                     this.$stage.children().eq(items.length + clones.length - 1).remove();
/* 294  */                     clones.pop();
/* 295  */                     this.$stage.children().eq(0).remove();
/* 296  */                     clones.pop();
/* 297  */                 } else {
/* 298  */                     clones.push(clones.length / 2);
/* 299  */                     this.$stage.append(items[clones[clones.length - 1]].clone().addClass('cloned'));
/* 300  */                     clones.push(items.length - 1 - (clones.length - 1) / 2);

/* owl.carousel.js */

/* 301  */                     this.$stage.prepend(items[clones[clones.length - 1]].clone().addClass('cloned'));
/* 302  */                 }
/* 303  */             }
/* 304  */         }
/* 305  */     }, {
/* 306  */         filter: [ 'width', 'items', 'settings' ],
/* 307  */         run: function() {
/* 308  */             var rtl = (this.settings.rtl ? 1 : -1),
/* 309  */                 width = (this.width() / this.settings.items).toFixed(3),
/* 310  */                 coordinate = 0, merge, i, n;
/* 311  */ 
/* 312  */             this._coordinates = [];
/* 313  */             for (i = 0, n = this._clones.length + this._items.length; i < n; i++) {
/* 314  */                 merge = this._mergers[this.relative(i)];
/* 315  */                 merge = (this.settings.mergeFit && Math.min(merge, this.settings.items)) || merge;
/* 316  */                 coordinate += (this.settings.autoWidth ? this._items[this.relative(i)].width() + this.settings.margin : width * merge) * rtl;
/* 317  */ 
/* 318  */                 this._coordinates.push(coordinate);
/* 319  */             }
/* 320  */         }
/* 321  */     }, {
/* 322  */         filter: [ 'width', 'items', 'settings' ],
/* 323  */         run: function() {
/* 324  */             var i, n, width = (this.width() / this.settings.items).toFixed(3), css = {
/* 325  */                 'width': Math.abs(this._coordinates[this._coordinates.length - 1]) + this.settings.stagePadding * 2,
/* 326  */                 'padding-left': this.settings.stagePadding || '',
/* 327  */                 'padding-right': this.settings.stagePadding || ''
/* 328  */             };
/* 329  */ 
/* 330  */             this.$stage.css(css);
/* 331  */ 
/* 332  */             css = { 'width': this.settings.autoWidth ? 'auto' : width - this.settings.margin };
/* 333  */             css[this.settings.rtl ? 'margin-left' : 'margin-right'] = this.settings.margin;
/* 334  */ 
/* 335  */             if (!this.settings.autoWidth && $.grep(this._mergers, function(v) { return v > 1 }).length > 0) {
/* 336  */                 for (i = 0, n = this._coordinates.length; i < n; i++) {
/* 337  */                     css.width = Math.abs(this._coordinates[i]) - Math.abs(this._coordinates[i - 1] || 0) - this.settings.margin;
/* 338  */                     this.$stage.children().eq(i).css(css);
/* 339  */                 }
/* 340  */             } else {
/* 341  */                 this.$stage.children().css(css);
/* 342  */             }
/* 343  */         }
/* 344  */     }, {
/* 345  */         filter: [ 'width', 'items', 'settings' ],
/* 346  */         run: function(cache) {
/* 347  */             cache.current && this.reset(this.$stage.children().index(cache.current));
/* 348  */         }
/* 349  */     }, {
/* 350  */         filter: [ 'position' ],

/* owl.carousel.js */

/* 351  */         run: function() {
/* 352  */             this.animate(this.coordinates(this._current));
/* 353  */         }
/* 354  */     }, {
/* 355  */         filter: [ 'width', 'position', 'items', 'settings' ],
/* 356  */         run: function() {
/* 357  */             var rtl = this.settings.rtl ? 1 : -1,
/* 358  */                 padding = this.settings.stagePadding * 2,
/* 359  */                 begin = this.coordinates(this.current()) + padding,
/* 360  */                 end = begin + this.width() * rtl,
/* 361  */                 inner, outer, matches = [], i, n;
/* 362  */ 
/* 363  */             for (i = 0, n = this._coordinates.length; i < n; i++) {
/* 364  */                 inner = this._coordinates[i - 1] || 0;
/* 365  */                 outer = Math.abs(this._coordinates[i]) + padding * rtl;
/* 366  */ 
/* 367  */                 if ((this.op(inner, '<=', begin) && (this.op(inner, '>', end)))
/* 368  */                     || (this.op(outer, '<', begin) && this.op(outer, '>', end))) {
/* 369  */                     matches.push(i);
/* 370  */                 }
/* 371  */             }
/* 372  */ 
/* 373  */             this.$stage.children('.' + this.settings.activeClass).removeClass(this.settings.activeClass);
/* 374  */             this.$stage.children(':eq(' + matches.join('), :eq(') + ')').addClass(this.settings.activeClass);
/* 375  */ 
/* 376  */             if (this.settings.center) {
/* 377  */                 this.$stage.children('.' + this.settings.centerClass).removeClass(this.settings.centerClass);
/* 378  */                 this.$stage.children().eq(this.current()).addClass(this.settings.centerClass);
/* 379  */             }
/* 380  */         }
/* 381  */     } ];
/* 382  */ 
/* 383  */     /**
/* 384  *|      * Initializes the carousel2.
/* 385  *|      * @protected
/* 386  *|      */
/* 387  */     Owl2.prototype.initialize = function() {
/* 388  */         this.trigger('initialize');
/* 389  */ 
/* 390  */         this.$element
/* 391  */             .addClass(this.settings.baseClass)
/* 392  */             .addClass(this.settings.themeClass)
/* 393  */             .toggleClass('owl2-rtl', this.settings.rtl);
/* 394  */ 
/* 395  */         // check support
/* 396  */         this.browserSupport();
/* 397  */ 
/* 398  */         if (this.settings.autoWidth && this.state.imagesLoaded !== true) {
/* 399  */             var imgs, nestedSelector, width;
/* 400  */             imgs = this.$element.find('img');

/* owl.carousel.js */

/* 401  */             nestedSelector = this.settings.nestedItemSelector ? '.' + this.settings.nestedItemSelector : undefined;
/* 402  */             width = this.$element.children(nestedSelector).width();
/* 403  */ 
/* 404  */             if (imgs.length && width <= 0) {
/* 405  */                 this.preloadAutoWidthImages(imgs);
/* 406  */                 return false;
/* 407  */             }
/* 408  */         }
/* 409  */ 
/* 410  */         this.$element.addClass('owl2-loading');
/* 411  */ 
/* 412  */         // create stage
/* 413  */         this.$stage = $('<' + this.settings.stageElement + ' class="owl2-stage"/>')
/* 414  */             .wrap('<div class="owl2-stage-outer">');
/* 415  */ 
/* 416  */         // append stage
/* 417  */         this.$element.append(this.$stage.parent());
/* 418  */ 
/* 419  */         // append content
/* 420  */         this.replace(this.$element.children().not(this.$stage.parent()));
/* 421  */ 
/* 422  */         // set view width
/* 423  */         this._width = this.$element.width();
/* 424  */ 
/* 425  */         // update view
/* 426  */         this.refresh();
/* 427  */ 
/* 428  */         this.$element.removeClass('owl2-loading').addClass('owl2-loaded');
/* 429  */ 
/* 430  */         // attach generic events
/* 431  */         this.eventsCall();
/* 432  */ 
/* 433  */         // attach generic events
/* 434  */         this.internalEvents();
/* 435  */ 
/* 436  */         // attach custom control events
/* 437  */         this.addTriggerableEvents();
/* 438  */ 
/* 439  */         this.trigger('initialized');
/* 440  */     };
/* 441  */ 
/* 442  */     /**
/* 443  *|      * Setups the current settings.
/* 444  *|      * @todo Remove responsive classes. Why should adaptive designs be brought into IE8?
/* 445  *|      * @todo Support for media queries by using `matchMedia` would be nice.
/* 446  *|      * @public
/* 447  *|      */
/* 448  */     Owl2.prototype.setup = function() {
/* 449  */         var viewport = this.viewport(),
/* 450  */             overwrites = this.options.responsive,

/* owl.carousel.js */

/* 451  */             match = -1,
/* 452  */             settings = null;
/* 453  */ 
/* 454  */         if (!overwrites) {
/* 455  */             settings = $.extend({}, this.options);
/* 456  */         } else {
/* 457  */             $.each(overwrites, function(breakpoint) {
/* 458  */                 if (breakpoint <= viewport && breakpoint > match) {
/* 459  */                     match = Number(breakpoint);
/* 460  */                 }
/* 461  */             });
/* 462  */ 
/* 463  */             settings = $.extend({}, this.options, overwrites[match]);
/* 464  */             delete settings.responsive;
/* 465  */ 
/* 466  */             // responsive class
/* 467  */             if (settings.responsiveClass) {
/* 468  */                 this.$element.attr('class', function(i, c) {
/* 469  */                     return c.replace(/\b owl2-responsive-\S+/g, '');
/* 470  */                 }).addClass('owl2-responsive-' + match);
/* 471  */             }
/* 472  */         }
/* 473  */ 
/* 474  */         if (this.settings === null || this._breakpoint !== match) {
/* 475  */             this.trigger('change', { property: { name: 'settings', value: settings } });
/* 476  */             this._breakpoint = match;
/* 477  */             this.settings = settings;
/* 478  */             this.invalidate('settings');
/* 479  */             this.trigger('changed', { property: { name: 'settings', value: this.settings } });
/* 480  */         }
/* 481  */     };
/* 482  */ 
/* 483  */     /**
/* 484  *|      * Updates option logic if necessery.
/* 485  *|      * @protected
/* 486  *|      */
/* 487  */     Owl2.prototype.optionsLogic = function() {
/* 488  */         // Toggle Center class
/* 489  */         this.$element.toggleClass('owl2-center', this.settings.center);
/* 490  */ 
/* 491  */         // if items number is less than in body
/* 492  */         if (this.settings.loop && this._items.length < this.settings.items) {
/* 493  */             this.settings.loop = false;
/* 494  */         }
/* 495  */ 
/* 496  */         if (this.settings.autoWidth) {
/* 497  */             this.settings.stagePadding = false;
/* 498  */             this.settings.merge = false;
/* 499  */         }
/* 500  */     };

/* owl.carousel.js */

/* 501  */ 
/* 502  */     /**
/* 503  *|      * Prepares an item before add.
/* 504  *|      * @todo Rename event parameter `content` to `item`.
/* 505  *|      * @protected
/* 506  *|      * @returns {jQuery|HTMLElement} - The item container.
/* 507  *|      */
/* 508  */     Owl2.prototype.prepare = function(item) {
/* 509  */         var event = this.trigger('prepare', { content: item });
/* 510  */ 
/* 511  */         if (!event.data) {
/* 512  */             event.data = $('<' + this.settings.itemElement + '/>')
/* 513  */                 .addClass(this.settings.itemClass).append(item)
/* 514  */         }
/* 515  */ 
/* 516  */         this.trigger('prepared', { content: event.data });
/* 517  */ 
/* 518  */         return event.data;
/* 519  */     };
/* 520  */ 
/* 521  */     /**
/* 522  *|      * Updates the view.
/* 523  *|      * @public
/* 524  *|      */
/* 525  */     Owl2.prototype.update = function() {
/* 526  */         var i = 0,
/* 527  */             n = this._pipe.length,
/* 528  */             filter = $.proxy(function(p) { return this[p] }, this._invalidated),
/* 529  */             cache = {};
/* 530  */ 
/* 531  */         while (i < n) {
/* 532  */             if (this._invalidated.all || $.grep(this._pipe[i].filter, filter).length > 0) {
/* 533  */                 this._pipe[i].run(cache);
/* 534  */             }
/* 535  */             i++;
/* 536  */         }
/* 537  */ 
/* 538  */         this._invalidated = {};
/* 539  */     };
/* 540  */ 
/* 541  */     /**
/* 542  *|      * Gets the width of the view.
/* 543  *|      * @public
/* 544  *|      * @param {Owl2.Width} [dimension=Owl2.Width.Default] - The dimension to return.
/* 545  *|      * @returns {Number} - The width of the view in pixel.
/* 546  *|      */
/* 547  */     Owl2.prototype.width = function(dimension) {
/* 548  */         dimension = dimension || Owl2.Width.Default;
/* 549  */         switch (dimension) {
/* 550  */             case Owl2.Width.Inner:

/* owl.carousel.js */

/* 551  */             case Owl2.Width.Outer:
/* 552  */                 return this._width;
/* 553  */             default:
/* 554  */                 return this._width - this.settings.stagePadding * 2 + this.settings.margin;
/* 555  */         }
/* 556  */     };
/* 557  */ 
/* 558  */     /**
/* 559  *|      * Refreshes the carousel2 primarily for adaptive purposes.
/* 560  *|      * @public
/* 561  *|      */
/* 562  */     Owl2.prototype.refresh = function() {
/* 563  */         if (this._items.length === 0) {
/* 564  */             return false;
/* 565  */         }
/* 566  */ 
/* 567  */         var start = new Date().getTime();
/* 568  */ 
/* 569  */         this.trigger('refresh');
/* 570  */ 
/* 571  */         this.setup();
/* 572  */ 
/* 573  */         this.optionsLogic();
/* 574  */ 
/* 575  */         // hide and show methods helps here to set a proper widths,
/* 576  */         // this prevents scrollbar to be calculated in stage width
/* 577  */         this.$stage.addClass('owl2-refresh');
/* 578  */ 
/* 579  */         this.update();
/* 580  */ 
/* 581  */         this.$stage.removeClass('owl2-refresh');
/* 582  */ 
/* 583  */         this.state.orientation = window.orientation;
/* 584  */ 
/* 585  */         this.watchVisibility();
/* 586  */ 
/* 587  */         this.trigger('refreshed');
/* 588  */     };
/* 589  */ 
/* 590  */     /**
/* 591  *|      * Save internal event references and add event based functions.
/* 592  *|      * @protected
/* 593  *|      */
/* 594  */     Owl2.prototype.eventsCall = function() {
/* 595  */         // Save events references
/* 596  */         this.e._onDragStart = $.proxy(function(e) {
/* 597  */             this.onDragStart(e);
/* 598  */         }, this);
/* 599  */         this.e._onDragMove = $.proxy(function(e) {
/* 600  */             this.onDragMove(e);

/* owl.carousel.js */

/* 601  */         }, this);
/* 602  */         this.e._onDragEnd = $.proxy(function(e) {
/* 603  */             this.onDragEnd(e);
/* 604  */         }, this);
/* 605  */         this.e._onResize = $.proxy(function(e) {
/* 606  */             this.onResize(e);
/* 607  */         }, this);
/* 608  */         this.e._transitionEnd = $.proxy(function(e) {
/* 609  */             this.transitionEnd(e);
/* 610  */         }, this);
/* 611  */         this.e._preventClick = $.proxy(function(e) {
/* 612  */             this.preventClick(e);
/* 613  */         }, this);
/* 614  */     };
/* 615  */ 
/* 616  */     /**
/* 617  *|      * Checks window `resize` event.
/* 618  *|      * @protected
/* 619  *|      */
/* 620  */     Owl2.prototype.onThrottledResize = function() {
/* 621  */         window.clearTimeout(this.resizeTimer);
/* 622  */         this.resizeTimer = window.setTimeout(this.e._onResize, this.settings.responsiveRefreshRate);
/* 623  */     };
/* 624  */ 
/* 625  */     /**
/* 626  *|      * Checks window `resize` event.
/* 627  *|      * @protected
/* 628  *|      */
/* 629  */     Owl2.prototype.onResize = function() {
/* 630  */         if (!this._items.length) {
/* 631  */             return false;
/* 632  */         }
/* 633  */ 
/* 634  */         if (this._width === this.$element.width()) {
/* 635  */             return false;
/* 636  */         }
/* 637  */ 
/* 638  */         if (this.trigger('resize').isDefaultPrevented()) {
/* 639  */             return false;
/* 640  */         }
/* 641  */ 
/* 642  */         this._width = this.$element.width();
/* 643  */ 
/* 644  */         this.invalidate('width');
/* 645  */ 
/* 646  */         this.refresh();
/* 647  */ 
/* 648  */         this.trigger('resized');
/* 649  */     };
/* 650  */ 

/* owl.carousel.js */

/* 651  */     /**
/* 652  *|      * Checks for touch/mouse drag event type and add run event handlers.
/* 653  *|      * @protected
/* 654  *|      */
/* 655  */     Owl2.prototype.eventsRouter = function(event) {
/* 656  */         var type = event.type;
/* 657  */ 
/* 658  */         if (type === "mousedown" || type === "touchstart") {
/* 659  */             this.onDragStart(event);
/* 660  */         } else if (type === "mousemove" || type === "touchmove") {
/* 661  */             this.onDragMove(event);
/* 662  */         } else if (type === "mouseup" || type === "touchend") {
/* 663  */             this.onDragEnd(event);
/* 664  */         } else if (type === "touchcancel") {
/* 665  */             this.onDragEnd(event);
/* 666  */         }
/* 667  */     };
/* 668  */ 
/* 669  */     /**
/* 670  *|      * Checks for touch/mouse drag options and add necessery event handlers.
/* 671  *|      * @protected
/* 672  *|      */
/* 673  */     Owl2.prototype.internalEvents = function() {
/* 674  */         var isTouch = isTouchSupport(),
/* 675  */             isTouchIE = isTouchSupportIE();
/* 676  */ 
/* 677  */         if (this.settings.mouseDrag){
/* 678  */             this.$stage.on('mousedown', $.proxy(function(event) { this.eventsRouter(event) }, this));
/* 679  */             this.$stage.on('dragstart', function() { return false });
/* 680  */             this.$stage.get(0).onselectstart = function() { return false };
/* 681  */         } else {
/* 682  */             this.$element.addClass('owl2-text-select-on');
/* 683  */         }
/* 684  */ 
/* 685  */         if (this.settings.touchDrag && !isTouchIE){
/* 686  */             this.$stage.on('touchstart touchcancel', $.proxy(function(event) { this.eventsRouter(event) }, this));
/* 687  */         }
/* 688  */ 
/* 689  */         // catch transitionEnd event
/* 690  */         if (this.transitionEndVendor) {
/* 691  */             this.on(this.$stage.get(0), this.transitionEndVendor, this.e._transitionEnd, false);
/* 692  */         }
/* 693  */ 
/* 694  */         // responsive
/* 695  */         if (this.settings.responsive !== false) {
/* 696  */             this.on(window, 'resize', $.proxy(this.onThrottledResize, this));
/* 697  */         }
/* 698  */     };
/* 699  */ 
/* 700  */     /**

/* owl.carousel.js */

/* 701  *|      * Handles touchstart/mousedown event.
/* 702  *|      * @protected
/* 703  *|      * @param {Event} event - The event arguments.
/* 704  *|      */
/* 705  */     Owl2.prototype.onDragStart = function(event) {
/* 706  */         var ev, isTouchEvent, pageX, pageY, animatedPos;
/* 707  */ 
/* 708  */         ev = event.originalEvent || event || window.event;
/* 709  */ 
/* 710  */         // prevent right click
/* 711  */         if (ev.which === 3 || this.state.isTouch) {
/* 712  */             return false;
/* 713  */         }
/* 714  */ 
/* 715  */         if (ev.type === 'mousedown') {
/* 716  */             this.$stage.addClass('owl2-grab');
/* 717  */         }
/* 718  */ 
/* 719  */         this.trigger('drag');
/* 720  */         this.drag.startTime = new Date().getTime();
/* 721  */         this.speed(0);
/* 722  */         this.state.isTouch = true;
/* 723  */         this.state.isScrolling = false;
/* 724  */         this.state.isSwiping = false;
/* 725  */         this.drag.distance = 0;
/* 726  */ 
/* 727  */         pageX = getTouches(ev).x;
/* 728  */         pageY = getTouches(ev).y;
/* 729  */ 
/* 730  */         // get stage position left
/* 731  */         this.drag.offsetX = this.$stage.position().left;
/* 732  */         this.drag.offsetY = this.$stage.position().top;
/* 733  */ 
/* 734  */         if (this.settings.rtl) {
/* 735  */             this.drag.offsetX = this.$stage.position().left + this.$stage.width() - this.width()
/* 736  */             + this.settings.margin;
/* 737  */         }
/* 738  */ 
/* 739  */         // catch position // ie to fix
/* 740  */         if (this.state.inMotion && this.support3d) {
/* 741  */             animatedPos = this.getTransformProperty();
/* 742  */             this.drag.offsetX = animatedPos;
/* 743  */             this.animate(animatedPos);
/* 744  */             this.state.inMotion = true;
/* 745  */         } else if (this.state.inMotion && !this.support3d) {
/* 746  */             this.state.inMotion = false;
/* 747  */             return false;
/* 748  */         }
/* 749  */ 
/* 750  */         this.drag.startX = pageX - this.drag.offsetX;

/* owl.carousel.js */

/* 751  */         this.drag.startY = pageY - this.drag.offsetY;
/* 752  */ 
/* 753  */         this.drag.start = pageX - this.drag.startX;
/* 754  */         this.drag.targetEl = ev.target || ev.srcElement;
/* 755  */         this.drag.updatedX = this.drag.start;
/* 756  */ 
/* 757  */         // to do/check
/* 758  */         // prevent links and images dragging;
/* 759  */         if (this.drag.targetEl.tagName === "IMG" || this.drag.targetEl.tagName === "A") {
/* 760  */             this.drag.targetEl.draggable = false;
/* 761  */         }
/* 762  */ 
/* 763  */         $(document).on('mousemove.owl.dragEvents mouseup.owl.dragEvents touchmove.owl.dragEvents touchend.owl.dragEvents', $.proxy(function(event) {this.eventsRouter(event)},this));
/* 764  */     };
/* 765  */ 
/* 766  */     /**
/* 767  *|      * Handles the touchmove/mousemove events.
/* 768  *|      * @todo Simplify
/* 769  *|      * @protected
/* 770  *|      * @param {Event} event - The event arguments.
/* 771  *|      */
/* 772  */     Owl2.prototype.onDragMove = function(event) {
/* 773  */         var ev, isTouchEvent, pageX, pageY, minValue, maxValue, pull;
/* 774  */ 
/* 775  */         if (!this.state.isTouch) {
/* 776  */             return;
/* 777  */         }
/* 778  */ 
/* 779  */         if (this.state.isScrolling) {
/* 780  */             return;
/* 781  */         }
/* 782  */ 
/* 783  */         ev = event.originalEvent || event || window.event;
/* 784  */ 
/* 785  */         pageX = getTouches(ev).x;
/* 786  */         pageY = getTouches(ev).y;
/* 787  */ 
/* 788  */         // Drag Direction
/* 789  */         this.drag.currentX = pageX - this.drag.startX;
/* 790  */         this.drag.currentY = pageY - this.drag.startY;
/* 791  */         this.drag.distance = this.drag.currentX - this.drag.offsetX;
/* 792  */ 
/* 793  */         // Check move direction
/* 794  */         if (this.drag.distance < 0) {
/* 795  */             this.state.direction = this.settings.rtl ? 'right' : 'left';
/* 796  */         } else if (this.drag.distance > 0) {
/* 797  */             this.state.direction = this.settings.rtl ? 'left' : 'right';
/* 798  */         }
/* 799  */         // Loop
/* 800  */         if (this.settings.loop) {

/* owl.carousel.js */

/* 801  */             if (this.op(this.drag.currentX, '>', this.coordinates(this.minimum())) && this.state.direction === 'right') {
/* 802  */                 this.drag.currentX -= (this.settings.center && this.coordinates(0)) - this.coordinates(this._items.length);
/* 803  */             } else if (this.op(this.drag.currentX, '<', this.coordinates(this.maximum())) && this.state.direction === 'left') {
/* 804  */                 this.drag.currentX += (this.settings.center && this.coordinates(0)) - this.coordinates(this._items.length);
/* 805  */             }
/* 806  */         } else {
/* 807  */             // pull
/* 808  */             minValue = this.settings.rtl ? this.coordinates(this.maximum()) : this.coordinates(this.minimum());
/* 809  */             maxValue = this.settings.rtl ? this.coordinates(this.minimum()) : this.coordinates(this.maximum());
/* 810  */             pull = this.settings.pullDrag ? this.drag.distance / 5 : 0;
/* 811  */             this.drag.currentX = Math.max(Math.min(this.drag.currentX, minValue + pull), maxValue + pull);
/* 812  */         }
/* 813  */ 
/* 814  */         // Lock browser if swiping horizontal
/* 815  */ 
/* 816  */         if ((this.drag.distance > 8 || this.drag.distance < -8)) {
/* 817  */             if (ev.preventDefault !== undefined) {
/* 818  */                 ev.preventDefault();
/* 819  */             } else {
/* 820  */                 ev.returnValue = false;
/* 821  */             }
/* 822  */             this.state.isSwiping = true;
/* 823  */         }
/* 824  */ 
/* 825  */         this.drag.updatedX = this.drag.currentX;
/* 826  */ 
/* 827  */         // Lock Owl2 if scrolling
/* 828  */         if ((this.drag.currentY > 16 || this.drag.currentY < -16) && this.state.isSwiping === false) {
/* 829  */             this.state.isScrolling = true;
/* 830  */             this.drag.updatedX = this.drag.start;
/* 831  */         }
/* 832  */ 
/* 833  */         this.animate(this.drag.updatedX);
/* 834  */     };
/* 835  */ 
/* 836  */     /**
/* 837  *|      * Handles the touchend/mouseup events.
/* 838  *|      * @protected
/* 839  *|      */
/* 840  */     Owl2.prototype.onDragEnd = function(event) {
/* 841  */         var compareTimes, distanceAbs, closest;
/* 842  */ 
/* 843  */         if (!this.state.isTouch) {
/* 844  */             return;
/* 845  */         }
/* 846  */ 
/* 847  */         if (event.type === 'mouseup') {
/* 848  */             this.$stage.removeClass('owl2-grab');
/* 849  */         }
/* 850  */ 

/* owl.carousel.js */

/* 851  */         this.trigger('dragged');
/* 852  */ 
/* 853  */         // prevent links and images dragging;
/* 854  */         this.drag.targetEl.removeAttribute("draggable");
/* 855  */ 
/* 856  */         // remove drag event listeners
/* 857  */ 
/* 858  */         this.state.isTouch = false;
/* 859  */         this.state.isScrolling = false;
/* 860  */         this.state.isSwiping = false;
/* 861  */ 
/* 862  */         // to check
/* 863  */         if (this.drag.distance === 0 && this.state.inMotion !== true) {
/* 864  */             this.state.inMotion = false;
/* 865  */             return false;
/* 866  */         }
/* 867  */ 
/* 868  */         // prevent clicks while scrolling
/* 869  */ 
/* 870  */         this.drag.endTime = new Date().getTime();
/* 871  */         compareTimes = this.drag.endTime - this.drag.startTime;
/* 872  */         distanceAbs = Math.abs(this.drag.distance);
/* 873  */ 
/* 874  */         // to test
/* 875  */         if (distanceAbs > 3 || compareTimes > 300) {
/* 876  */             this.removeClick(this.drag.targetEl);
/* 877  */         }
/* 878  */ 
/* 879  */         closest = this.closest(this.drag.updatedX);
/* 880  */ 
/* 881  */         this.speed(this.settings.dragEndSpeed || this.settings.smartSpeed);
/* 882  */         this.current(closest);
/* 883  */         this.invalidate('position');
/* 884  */         this.update();
/* 885  */ 
/* 886  */         // if pullDrag is off then fire transitionEnd event manually when stick
/* 887  */         // to border
/* 888  */         if (!this.settings.pullDrag && this.drag.updatedX === this.coordinates(closest)) {
/* 889  */             this.transitionEnd();
/* 890  */         }
/* 891  */ 
/* 892  */         this.drag.distance = 0;
/* 893  */ 
/* 894  */         $(document).off('.owl.dragEvents');
/* 895  */     };
/* 896  */ 
/* 897  */     /**
/* 898  *|      * Attaches `preventClick` to disable link while swipping.
/* 899  *|      * @protected
/* 900  *|      * @param {HTMLElement} [target] - The target of the `click` event.

/* owl.carousel.js */

/* 901  *|      */
/* 902  */     Owl2.prototype.removeClick = function(target) {
/* 903  */         this.drag.targetEl = target;
/* 904  */         $(target).on('click.preventClick', this.e._preventClick);
/* 905  */         // to make sure click is removed:
/* 906  */         window.setTimeout(function() {
/* 907  */             $(target).off('click.preventClick');
/* 908  */         }, 300);
/* 909  */     };
/* 910  */ 
/* 911  */     /**
/* 912  *|      * Suppresses click event.
/* 913  *|      * @protected
/* 914  *|      * @param {Event} ev - The event arguments.
/* 915  *|      */
/* 916  */     Owl2.prototype.preventClick = function(ev) {
/* 917  */         if (ev.preventDefault) {
/* 918  */             ev.preventDefault();
/* 919  */         } else {
/* 920  */             ev.returnValue = false;
/* 921  */         }
/* 922  */         if (ev.stopPropagation) {
/* 923  */             ev.stopPropagation();
/* 924  */         }
/* 925  */         $(ev.target).off('click.preventClick');
/* 926  */     };
/* 927  */ 
/* 928  */     /**
/* 929  *|      * Catches stage position while animate (only CSS3).
/* 930  *|      * @protected
/* 931  *|      * @returns
/* 932  *|      */
/* 933  */     Owl2.prototype.getTransformProperty = function() {
/* 934  */         var transform, matrix3d;
/* 935  */ 
/* 936  */         transform = window.getComputedStyle(this.$stage.get(0), null).getPropertyValue(this.vendorName + 'transform');
/* 937  */         // var transform = this.$stage.css(this.vendorName + 'transform')
/* 938  */         transform = transform.replace(/matrix(3d)?\(|\)/g, '').split(',');
/* 939  */         matrix3d = transform.length === 16;
/* 940  */ 
/* 941  */         return matrix3d !== true ? transform[4] : transform[12];
/* 942  */     };
/* 943  */ 
/* 944  */     /**
/* 945  *|      * Gets absolute position of the closest item for a coordinate.
/* 946  *|      * @todo Setting `freeDrag` makes `closest` not reusable. See #165.
/* 947  *|      * @protected
/* 948  *|      * @param {Number} coordinate - The coordinate in pixel.
/* 949  *|      * @return {Number} - The absolute position of the closest item.
/* 950  *|      */

/* owl.carousel.js */

/* 951  */     Owl2.prototype.closest = function(coordinate) {
/* 952  */         var position = -1, pull = 30, width = this.width(), coordinates = this.coordinates();
/* 953  */ 
/* 954  */         if (!this.settings.freeDrag) {
/* 955  */             // check closest item
/* 956  */             $.each(coordinates, $.proxy(function(index, value) {
/* 957  */                 if (coordinate > value - pull && coordinate < value + pull) {
/* 958  */                     position = index;
/* 959  */                 } else if (this.op(coordinate, '<', value)
/* 960  */                     && this.op(coordinate, '>', coordinates[index + 1] || value - width)) {
/* 961  */                     position = this.state.direction === 'left' ? index + 1 : index;
/* 962  */                 }
/* 963  */                 return position === -1;
/* 964  */             }, this));
/* 965  */         }
/* 966  */ 
/* 967  */         if (!this.settings.loop) {
/* 968  */             // non loop boundries
/* 969  */             if (this.op(coordinate, '>', coordinates[this.minimum()])) {
/* 970  */                 position = coordinate = this.minimum();
/* 971  */             } else if (this.op(coordinate, '<', coordinates[this.maximum()])) {
/* 972  */                 position = coordinate = this.maximum();
/* 973  */             }
/* 974  */         }
/* 975  */ 
/* 976  */         return position;
/* 977  */     };
/* 978  */ 
/* 979  */     /**
/* 980  *|      * Animates the stage.
/* 981  *|      * @public
/* 982  *|      * @param {Number} coordinate - The coordinate in pixels.
/* 983  *|      */
/* 984  */     Owl2.prototype.animate = function(coordinate) {
/* 985  */         this.trigger('translate');
/* 986  */         this.state.inMotion = this.speed() > 0;
/* 987  */ 
/* 988  */         if (this.support3d) {
/* 989  */             this.$stage.css({
/* 990  */                 transform: 'translate3d(' + coordinate + 'px' + ',0px, 0px)',
/* 991  */                 transition: (this.speed() / 1000) + 's'
/* 992  */             });
/* 993  */         } else if (this.state.isTouch) {
/* 994  */             this.$stage.css({
/* 995  */                 left: coordinate + 'px'
/* 996  */             });
/* 997  */         } else {
/* 998  */             this.$stage.animate({
/* 999  */                 left: coordinate
/* 1000 */             }, this.speed() / 1000, this.settings.fallbackEasing, $.proxy(function() {

/* owl.carousel.js */

/* 1001 */                 if (this.state.inMotion) {
/* 1002 */                     this.transitionEnd();
/* 1003 */                 }
/* 1004 */             }, this));
/* 1005 */         }
/* 1006 */     };
/* 1007 */ 
/* 1008 */     /**
/* 1009 *|      * Sets the absolute position of the current item.
/* 1010 *|      * @public
/* 1011 *|      * @param {Number} [position] - The new absolute position or nothing to leave it unchanged.
/* 1012 *|      * @returns {Number} - The absolute position of the current item.
/* 1013 *|      */
/* 1014 */     Owl2.prototype.current = function(position) {
/* 1015 */         if (position === undefined) {
/* 1016 */             return this._current;
/* 1017 */         }
/* 1018 */ 
/* 1019 */         if (this._items.length === 0) {
/* 1020 */             return undefined;
/* 1021 */         }
/* 1022 */ 
/* 1023 */         position = this.normalize(position);
/* 1024 */ 
/* 1025 */         if (this._current !== position) {
/* 1026 */             var event = this.trigger('change', { property: { name: 'position', value: position } });
/* 1027 */ 
/* 1028 */             if (event.data !== undefined) {
/* 1029 */                 position = this.normalize(event.data);
/* 1030 */             }
/* 1031 */ 
/* 1032 */             this._current = position;
/* 1033 */ 
/* 1034 */             this.invalidate('position');
/* 1035 */ 
/* 1036 */             this.trigger('changed', { property: { name: 'position', value: this._current } });
/* 1037 */         }
/* 1038 */ 
/* 1039 */         return this._current;
/* 1040 */     };
/* 1041 */ 
/* 1042 */     /**
/* 1043 *|      * Invalidates the given part of the update routine.
/* 1044 *|      * @param {String} part - The part to invalidate.
/* 1045 *|      */
/* 1046 */     Owl2.prototype.invalidate = function(part) {
/* 1047 */         this._invalidated[part] = true;
/* 1048 */     }
/* 1049 */ 
/* 1050 */     /**

/* owl.carousel.js */

/* 1051 *|      * Resets the absolute position of the current item.
/* 1052 *|      * @public
/* 1053 *|      * @param {Number} position - The absolute position of the new item.
/* 1054 *|      */
/* 1055 */     Owl2.prototype.reset = function(position) {
/* 1056 */         position = this.normalize(position);
/* 1057 */ 
/* 1058 */         if (position === undefined) {
/* 1059 */             return;
/* 1060 */         }
/* 1061 */ 
/* 1062 */         this._speed = 0;
/* 1063 */         this._current = position;
/* 1064 */ 
/* 1065 */         this.suppress([ 'translate', 'translated' ]);
/* 1066 */ 
/* 1067 */         this.animate(this.coordinates(position));
/* 1068 */ 
/* 1069 */         this.release([ 'translate', 'translated' ]);
/* 1070 */     };
/* 1071 */ 
/* 1072 */     /**
/* 1073 *|      * Normalizes an absolute or a relative position for an item.
/* 1074 *|      * @public
/* 1075 *|      * @param {Number} position - The absolute or relative position to normalize.
/* 1076 *|      * @param {Boolean} [relative=false] - Whether the given position is relative or not.
/* 1077 *|      * @returns {Number} - The normalized position.
/* 1078 *|      */
/* 1079 */     Owl2.prototype.normalize = function(position, relative) {
/* 1080 */         var n = (relative ? this._items.length : this._items.length + this._clones.length);
/* 1081 */ 
/* 1082 */         if (!$.isNumeric(position) || n < 1) {
/* 1083 */             return undefined;
/* 1084 */         }
/* 1085 */ 
/* 1086 */         if (this._clones.length) {
/* 1087 */             position = ((position % n) + n) % n;
/* 1088 */         } else {
/* 1089 */             position = Math.max(this.minimum(relative), Math.min(this.maximum(relative), position));
/* 1090 */         }
/* 1091 */ 
/* 1092 */         return position;
/* 1093 */     };
/* 1094 */ 
/* 1095 */     /**
/* 1096 *|      * Converts an absolute position for an item into a relative position.
/* 1097 *|      * @public
/* 1098 *|      * @param {Number} position - The absolute position to convert.
/* 1099 *|      * @returns {Number} - The converted position.
/* 1100 *|      */

/* owl.carousel.js */

/* 1101 */     Owl2.prototype.relative = function(position) {
/* 1102 */         position = this.normalize(position);
/* 1103 */         position = position - this._clones.length / 2;
/* 1104 */         return this.normalize(position, true);
/* 1105 */     };
/* 1106 */ 
/* 1107 */     /**
/* 1108 *|      * Gets the maximum position for an item.
/* 1109 *|      * @public
/* 1110 *|      * @param {Boolean} [relative=false] - Whether to return an absolute position or a relative position.
/* 1111 *|      * @returns {Number}
/* 1112 *|      */
/* 1113 */     Owl2.prototype.maximum = function(relative) {
/* 1114 */         var maximum, width, i = 0, coordinate,
/* 1115 */             settings = this.settings;
/* 1116 */ 
/* 1117 */         if (relative) {
/* 1118 */             return this._items.length - 1;
/* 1119 */         }
/* 1120 */ 
/* 1121 */         if (!settings.loop && settings.center) {
/* 1122 */             maximum = this._items.length - 1;
/* 1123 */         } else if (!settings.loop && !settings.center) {
/* 1124 */             maximum = this._items.length - settings.items;
/* 1125 */         } else if (settings.loop || settings.center) {
/* 1126 */             maximum = this._items.length + settings.items;
/* 1127 */         } else if (settings.autoWidth || settings.merge) {
/* 1128 */             revert = settings.rtl ? 1 : -1;
/* 1129 */             width = this.$stage.width() - this.$element.width();
/* 1130 */             while (coordinate = this.coordinates(i)) {
/* 1131 */                 if (coordinate * revert >= width) {
/* 1132 */                     break;
/* 1133 */                 }
/* 1134 */                 maximum = ++i;
/* 1135 */             }
/* 1136 */         } else {
/* 1137 */             throw 'Can not detect maximum absolute position.'
/* 1138 */         }
/* 1139 */ 
/* 1140 */         return maximum;
/* 1141 */     };
/* 1142 */ 
/* 1143 */     /**
/* 1144 *|      * Gets the minimum position for an item.
/* 1145 *|      * @public
/* 1146 *|      * @param {Boolean} [relative=false] - Whether to return an absolute position or a relative position.
/* 1147 *|      * @returns {Number}
/* 1148 *|      */
/* 1149 */     Owl2.prototype.minimum = function(relative) {
/* 1150 */         if (relative) {

/* owl.carousel.js */

/* 1151 */             return 0;
/* 1152 */         }
/* 1153 */ 
/* 1154 */         return this._clones.length / 2;
/* 1155 */     };
/* 1156 */ 
/* 1157 */     /**
/* 1158 *|      * Gets an item at the specified relative position.
/* 1159 *|      * @public
/* 1160 *|      * @param {Number} [position] - The relative position of the item.
/* 1161 *|      * @return {jQuery|Array.<jQuery>} - The item at the given position or all items if no position was given.
/* 1162 *|      */
/* 1163 */     Owl2.prototype.items = function(position) {
/* 1164 */         if (position === undefined) {
/* 1165 */             return this._items.slice();
/* 1166 */         }
/* 1167 */ 
/* 1168 */         position = this.normalize(position, true);
/* 1169 */         return this._items[position];
/* 1170 */     };
/* 1171 */ 
/* 1172 */     /**
/* 1173 *|      * Gets an item at the specified relative position.
/* 1174 *|      * @public
/* 1175 *|      * @param {Number} [position] - The relative position of the item.
/* 1176 *|      * @return {jQuery|Array.<jQuery>} - The item at the given position or all items if no position was given.
/* 1177 *|      */
/* 1178 */     Owl2.prototype.mergers = function(position) {
/* 1179 */         if (position === undefined) {
/* 1180 */             return this._mergers.slice();
/* 1181 */         }
/* 1182 */ 
/* 1183 */         position = this.normalize(position, true);
/* 1184 */         return this._mergers[position];
/* 1185 */     };
/* 1186 */ 
/* 1187 */     /**
/* 1188 *|      * Gets the absolute positions of clones for an item.
/* 1189 *|      * @public
/* 1190 *|      * @param {Number} [position] - The relative position of the item.
/* 1191 *|      * @returns {Array.<Number>} - The absolute positions of clones for the item or all if no position was given.
/* 1192 *|      */
/* 1193 */     Owl2.prototype.clones = function(position) {
/* 1194 */         var odd = this._clones.length / 2,
/* 1195 */             even = odd + this._items.length,
/* 1196 */             map = function(index) { return index % 2 === 0 ? even + index / 2 : odd - (index + 1) / 2 };
/* 1197 */ 
/* 1198 */         if (position === undefined) {
/* 1199 */             return $.map(this._clones, function(v, i) { return map(i) });
/* 1200 */         }

/* owl.carousel.js */

/* 1201 */ 
/* 1202 */         return $.map(this._clones, function(v, i) { return v === position ? map(i) : null });
/* 1203 */     };
/* 1204 */ 
/* 1205 */     /**
/* 1206 *|      * Sets the current animation speed.
/* 1207 *|      * @public
/* 1208 *|      * @param {Number} [speed] - The animation speed in milliseconds or nothing to leave it unchanged.
/* 1209 *|      * @returns {Number} - The current animation speed in milliseconds.
/* 1210 *|      */
/* 1211 */     Owl2.prototype.speed = function(speed) {
/* 1212 */         if (speed !== undefined) {
/* 1213 */             this._speed = speed;
/* 1214 */         }
/* 1215 */ 
/* 1216 */         return this._speed;
/* 1217 */     };
/* 1218 */ 
/* 1219 */     /**
/* 1220 *|      * Gets the coordinate of an item.
/* 1221 *|      * @todo The name of this method is missleanding.
/* 1222 *|      * @public
/* 1223 *|      * @param {Number} position - The absolute position of the item within `minimum()` and `maximum()`.
/* 1224 *|      * @returns {Number|Array.<Number>} - The coordinate of the item in pixel or all coordinates.
/* 1225 *|      */
/* 1226 */     Owl2.prototype.coordinates = function(position) {
/* 1227 */         var coordinate = null;
/* 1228 */ 
/* 1229 */         if (position === undefined) {
/* 1230 */             return $.map(this._coordinates, $.proxy(function(coordinate, index) {
/* 1231 */                 return this.coordinates(index);
/* 1232 */             }, this));
/* 1233 */         }
/* 1234 */ 
/* 1235 */         if (this.settings.center) {
/* 1236 */             coordinate = this._coordinates[position];
/* 1237 */             coordinate += (this.width() - coordinate + (this._coordinates[position - 1] || 0)) / 2 * (this.settings.rtl ? -1 : 1);
/* 1238 */         } else {
/* 1239 */             coordinate = this._coordinates[position - 1] || 0;
/* 1240 */         }
/* 1241 */ 
/* 1242 */         return coordinate;
/* 1243 */     };
/* 1244 */ 
/* 1245 */     /**
/* 1246 *|      * Calculates the speed for a translation.
/* 1247 *|      * @protected
/* 1248 *|      * @param {Number} from - The absolute position of the start item.
/* 1249 *|      * @param {Number} to - The absolute position of the target item.
/* 1250 *|      * @param {Number} [factor=undefined] - The time factor in milliseconds.

/* owl.carousel.js */

/* 1251 *|      * @returns {Number} - The time in milliseconds for the translation.
/* 1252 *|      */
/* 1253 */     Owl2.prototype.duration = function(from, to, factor) {
/* 1254 */         return Math.min(Math.max(Math.abs(to - from), 1), 6) * Math.abs((factor || this.settings.smartSpeed));
/* 1255 */     };
/* 1256 */ 
/* 1257 */     /**
/* 1258 *|      * Slides to the specified item.
/* 1259 *|      * @public
/* 1260 *|      * @param {Number} position - The position of the item.
/* 1261 *|      * @param {Number} [speed] - The time in milliseconds for the transition.
/* 1262 *|      */
/* 1263 */     Owl2.prototype.to = function(position, speed) {
/* 1264 */         if (this.settings.loop) {
/* 1265 */             var distance = position - this.relative(this.current()),
/* 1266 */                 revert = this.current(),
/* 1267 */                 before = this.current(),
/* 1268 */                 after = this.current() + distance,
/* 1269 */                 direction = before - after < 0 ? true : false,
/* 1270 */                 items = this._clones.length + this._items.length;
/* 1271 */ 
/* 1272 */             if (after < this.settings.items && direction === false) {
/* 1273 */                 revert = before + this._items.length;
/* 1274 */                 this.reset(revert);
/* 1275 */             } else if (after >= items - this.settings.items && direction === true) {
/* 1276 */                 revert = before - this._items.length;
/* 1277 */                 this.reset(revert);
/* 1278 */             }
/* 1279 */             window.clearTimeout(this.e._goToLoop);
/* 1280 */             this.e._goToLoop = window.setTimeout($.proxy(function() {
/* 1281 */                 this.speed(this.duration(this.current(), revert + distance, speed));
/* 1282 */                 this.current(revert + distance);
/* 1283 */                 this.update();
/* 1284 */             }, this), 30);
/* 1285 */         } else {
/* 1286 */             this.speed(this.duration(this.current(), position, speed));
/* 1287 */             this.current(position);
/* 1288 */             this.update();
/* 1289 */         }
/* 1290 */     };
/* 1291 */ 
/* 1292 */     /**
/* 1293 *|      * Slides to the next item.
/* 1294 *|      * @public
/* 1295 *|      * @param {Number} [speed] - The time in milliseconds for the transition.
/* 1296 *|      */
/* 1297 */     Owl2.prototype.next = function(speed) {
/* 1298 */         speed = speed || false;
/* 1299 */         this.to(this.relative(this.current()) + 1, speed);
/* 1300 */     };

/* owl.carousel.js */

/* 1301 */ 
/* 1302 */     /**
/* 1303 *|      * Slides to the previous item.
/* 1304 *|      * @public
/* 1305 *|      * @param {Number} [speed] - The time in milliseconds for the transition.
/* 1306 *|      */
/* 1307 */     Owl2.prototype.prev = function(speed) {
/* 1308 */         speed = speed || false;
/* 1309 */         this.to(this.relative(this.current()) - 1, speed);
/* 1310 */     };
/* 1311 */ 
/* 1312 */     /**
/* 1313 *|      * Handles the end of an animation.
/* 1314 *|      * @protected
/* 1315 *|      * @param {Event} event - The event arguments.
/* 1316 *|      */
/* 1317 */     Owl2.prototype.transitionEnd = function(event) {
/* 1318 */ 
/* 1319 */         // if css2 animation then event object is undefined
/* 1320 */         if (event !== undefined) {
/* 1321 */             event.stopPropagation();
/* 1322 */ 
/* 1323 */             // Catch only owl2-stage transitionEnd event
/* 1324 */             if ((event.target || event.srcElement || event.originalTarget) !== this.$stage.get(0)) {
/* 1325 */                 return false;
/* 1326 */             }
/* 1327 */         }
/* 1328 */ 
/* 1329 */         this.state.inMotion = false;
/* 1330 */         this.trigger('translated');
/* 1331 */     };
/* 1332 */ 
/* 1333 */     /**
/* 1334 *|      * Gets viewport width.
/* 1335 *|      * @protected
/* 1336 *|      * @return {Number} - The width in pixel.
/* 1337 *|      */
/* 1338 */     Owl2.prototype.viewport = function() {
/* 1339 */         var width;
/* 1340 */         if (this.options.responsiveBaseElement !== window) {
/* 1341 */             width = $(this.options.responsiveBaseElement).width();
/* 1342 */         } else if (window.innerWidth) {
/* 1343 */             width = window.innerWidth;
/* 1344 */         } else if (document.documentElement && document.documentElement.clientWidth) {
/* 1345 */             width = document.documentElement.clientWidth;
/* 1346 */         } else {
/* 1347 */             throw 'Can not detect viewport width.';
/* 1348 */         }
/* 1349 */         return width;
/* 1350 */     };

/* owl.carousel.js */

/* 1351 */ 
/* 1352 */     /**
/* 1353 *|      * Replaces the current content.
/* 1354 *|      * @public
/* 1355 *|      * @param {HTMLElement|jQuery|String} content - The new content.
/* 1356 *|      */
/* 1357 */     Owl2.prototype.replace = function(content) {
/* 1358 */         this.$stage.empty();
/* 1359 */         this._items = [];
/* 1360 */ 
/* 1361 */         if (content) {
/* 1362 */             content = (content instanceof jQuery) ? content : $(content);
/* 1363 */         }
/* 1364 */ 
/* 1365 */         if (this.settings.nestedItemSelector) {
/* 1366 */             content = content.find('.' + this.settings.nestedItemSelector);
/* 1367 */         }
/* 1368 */ 
/* 1369 */         content.filter(function() {
/* 1370 */             return this.nodeType === 1;
/* 1371 */         }).each($.proxy(function(index, item) {
/* 1372 */             item = this.prepare(item);
/* 1373 */             this.$stage.append(item);
/* 1374 */             this._items.push(item);
/* 1375 */             this._mergers.push(item.find('[data-merge]').andSelf('[data-merge]').attr('data-merge') * 1 || 1);
/* 1376 */         }, this));
/* 1377 */ 
/* 1378 */         this.reset($.isNumeric(this.settings.startPosition) ? this.settings.startPosition : 0);
/* 1379 */ 
/* 1380 */         this.invalidate('items');
/* 1381 */     };
/* 1382 */ 
/* 1383 */     /**
/* 1384 *|      * Adds an item.
/* 1385 *|      * @todo Use `item` instead of `content` for the event arguments.
/* 1386 *|      * @public
/* 1387 *|      * @param {HTMLElement|jQuery|String} content - The item content to add.
/* 1388 *|      * @param {Number} [position] - The relative position at which to insert the item otherwise the item will be added to the end.
/* 1389 *|      */
/* 1390 */     Owl2.prototype.add = function(content, position) {
/* 1391 */         position = position === undefined ? this._items.length : this.normalize(position, true);
/* 1392 */ 
/* 1393 */         this.trigger('add', { content: content, position: position });
/* 1394 */ 
/* 1395 */         if (this._items.length === 0 || position === this._items.length) {
/* 1396 */             this.$stage.append(content);
/* 1397 */             this._items.push(content);
/* 1398 */             this._mergers.push(content.find('[data-merge]').andSelf('[data-merge]').attr('data-merge') * 1 || 1);
/* 1399 */         } else {
/* 1400 */             this._items[position].before(content);

/* owl.carousel.js */

/* 1401 */             this._items.splice(position, 0, content);
/* 1402 */             this._mergers.splice(position, 0, content.find('[data-merge]').andSelf('[data-merge]').attr('data-merge') * 1 || 1);
/* 1403 */         }
/* 1404 */ 
/* 1405 */         this.invalidate('items');
/* 1406 */ 
/* 1407 */         this.trigger('added', { content: content, position: position });
/* 1408 */     };
/* 1409 */ 
/* 1410 */     /**
/* 1411 *|      * Removes an item by its position.
/* 1412 *|      * @todo Use `item` instead of `content` for the event arguments.
/* 1413 *|      * @public
/* 1414 *|      * @param {Number} position - The relative position of the item to remove.
/* 1415 *|      */
/* 1416 */     Owl2.prototype.remove = function(position) {
/* 1417 */         position = this.normalize(position, true);
/* 1418 */ 
/* 1419 */         if (position === undefined) {
/* 1420 */             return;
/* 1421 */         }
/* 1422 */ 
/* 1423 */         this.trigger('remove', { content: this._items[position], position: position });
/* 1424 */ 
/* 1425 */         this._items[position].remove();
/* 1426 */         this._items.splice(position, 1);
/* 1427 */         this._mergers.splice(position, 1);
/* 1428 */ 
/* 1429 */         this.invalidate('items');
/* 1430 */ 
/* 1431 */         this.trigger('removed', { content: null, position: position });
/* 1432 */     };
/* 1433 */ 
/* 1434 */     /**
/* 1435 *|      * Adds triggerable events.
/* 1436 *|      * @protected
/* 1437 *|      */
/* 1438 */     Owl2.prototype.addTriggerableEvents = function() {
/* 1439 */         var handler = $.proxy(function(callback, event) {
/* 1440 */             return $.proxy(function(e) {
/* 1441 */                 if (e.relatedTarget !== this) {
/* 1442 */                     this.suppress([ event ]);
/* 1443 */                     callback.apply(this, [].slice.call(arguments, 1));
/* 1444 */                     this.release([ event ]);
/* 1445 */                 }
/* 1446 */             }, this);
/* 1447 */         }, this);
/* 1448 */ 
/* 1449 */         $.each({
/* 1450 */             'next': this.next,

/* owl.carousel.js */

/* 1451 */             'prev': this.prev,
/* 1452 */             'to': this.to,
/* 1453 */             'destroy': this.destroy,
/* 1454 */             'refresh': this.refresh,
/* 1455 */             'replace': this.replace,
/* 1456 */             'add': this.add,
/* 1457 */             'remove': this.remove
/* 1458 */         }, $.proxy(function(event, callback) {
/* 1459 */             this.$element.on(event + '.owl.carousel2', handler(callback, event + '.owl.carousel2'));
/* 1460 */         }, this));
/* 1461 */ 
/* 1462 */     };
/* 1463 */ 
/* 1464 */     /**
/* 1465 *|      * Watches the visibility of the carousel2 element.
/* 1466 *|      * @protected
/* 1467 *|      */
/* 1468 */     Owl2.prototype.watchVisibility = function() {
/* 1469 */ 
/* 1470 */         // test on zepto
/* 1471 */         if (!isElVisible(this.$element.get(0))) {
/* 1472 */             this.$element.addClass('owl2-hidden');
/* 1473 */             window.clearInterval(this.e._checkVisibile);
/* 1474 */             this.e._checkVisibile = window.setInterval($.proxy(checkVisible, this), 500);
/* 1475 */         }
/* 1476 */ 
/* 1477 */         function isElVisible(el) {
/* 1478 */             return el.offsetWidth > 0 && el.offsetHeight > 0;
/* 1479 */         }
/* 1480 */ 
/* 1481 */         function checkVisible() {
/* 1482 */             if (isElVisible(this.$element.get(0))) {
/* 1483 */                 this.$element.removeClass('owl2-hidden');
/* 1484 */                 this.refresh();
/* 1485 */                 window.clearInterval(this.e._checkVisibile);
/* 1486 */             }
/* 1487 */         }
/* 1488 */     };
/* 1489 */ 
/* 1490 */     /**
/* 1491 *|      * Preloads images with auto width.
/* 1492 *|      * @protected
/* 1493 *|      * @todo Still to test
/* 1494 *|      */
/* 1495 */     Owl2.prototype.preloadAutoWidthImages = function(imgs) {
/* 1496 */         var loaded, that, $el, img;
/* 1497 */ 
/* 1498 */         loaded = 0;
/* 1499 */         that = this;
/* 1500 */         imgs.each(function(i, el) {

/* owl.carousel.js */

/* 1501 */             $el = $(el);
/* 1502 */             img = new Image();
/* 1503 */ 
/* 1504 */             img.onload = function() {
/* 1505 */                 loaded++;
/* 1506 */                 $el.attr('src', img.src);
/* 1507 */                 $el.css('opacity', 1);
/* 1508 */                 if (loaded >= imgs.length) {
/* 1509 */                     that.state.imagesLoaded = true;
/* 1510 */                     that.initialize();
/* 1511 */                 }
/* 1512 */             };
/* 1513 */ 
/* 1514 */             img.src = $el.attr('src') || $el.attr('data-src') || $el.attr('data-src-retina');
/* 1515 */         });
/* 1516 */     };
/* 1517 */ 
/* 1518 */     /**
/* 1519 *|      * Destroys the carousel2.
/* 1520 *|      * @public
/* 1521 *|      */
/* 1522 */     Owl2.prototype.destroy = function() {
/* 1523 */ 
/* 1524 */         if (this.$element.hasClass(this.settings.themeClass)) {
/* 1525 */             this.$element.removeClass(this.settings.themeClass);
/* 1526 */         }
/* 1527 */ 
/* 1528 */         if (this.settings.responsive !== false) {
/* 1529 */             $(window).off('resize.owl.carousel2');
/* 1530 */         }
/* 1531 */ 
/* 1532 */         if (this.transitionEndVendor) {
/* 1533 */             this.off(this.$stage.get(0), this.transitionEndVendor, this.e._transitionEnd);
/* 1534 */         }
/* 1535 */ 
/* 1536 */         for ( var i in this._plugins) {
/* 1537 */             this._plugins[i].destroy();
/* 1538 */         }
/* 1539 */ 
/* 1540 */         if (this.settings.mouseDrag || this.settings.touchDrag) {
/* 1541 */             this.$stage.off('mousedown touchstart touchcancel');
/* 1542 */             $(document).off('.owl.dragEvents');
/* 1543 */             this.$stage.get(0).onselectstart = function() {};
/* 1544 */             this.$stage.off('dragstart', function() { return false });
/* 1545 */         }
/* 1546 */ 
/* 1547 */         // remove event handlers in the ".owl.carousel2" namespace
/* 1548 */         this.$element.off('.owl');
/* 1549 */ 
/* 1550 */         this.$stage.children('.cloned').remove();

/* owl.carousel.js */

/* 1551 */         this.e = null;
/* 1552 */         this.$element.removeData('owlCarousel2');
/* 1553 */ 
/* 1554 */         this.$stage.children().contents().unwrap();
/* 1555 */         this.$stage.children().unwrap();
/* 1556 */         this.$stage.unwrap();
/* 1557 */     };
/* 1558 */ 
/* 1559 */     /**
/* 1560 *|      * Operators to calculate right-to-left and left-to-right.
/* 1561 *|      * @protected
/* 1562 *|      * @param {Number} [a] - The left side operand.
/* 1563 *|      * @param {String} [o] - The operator.
/* 1564 *|      * @param {Number} [b] - The right side operand.
/* 1565 *|      */
/* 1566 */     Owl2.prototype.op = function(a, o, b) {
/* 1567 */         var rtl = this.settings.rtl;
/* 1568 */         switch (o) {
/* 1569 */             case '<':
/* 1570 */                 return rtl ? a > b : a < b;
/* 1571 */             case '>':
/* 1572 */                 return rtl ? a < b : a > b;
/* 1573 */             case '>=':
/* 1574 */                 return rtl ? a <= b : a >= b;
/* 1575 */             case '<=':
/* 1576 */                 return rtl ? a >= b : a <= b;
/* 1577 */             default:
/* 1578 */                 break;
/* 1579 */         }
/* 1580 */     };
/* 1581 */ 
/* 1582 */     /**
/* 1583 *|      * Attaches to an internal event.
/* 1584 *|      * @protected
/* 1585 *|      * @param {HTMLElement} element - The event source.
/* 1586 *|      * @param {String} event - The event name.
/* 1587 *|      * @param {Function} listener - The event handler to attach.
/* 1588 *|      * @param {Boolean} capture - Wether the event should be handled at the capturing phase or not.
/* 1589 *|      */
/* 1590 */     Owl2.prototype.on = function(element, event, listener, capture) {
/* 1591 */         if (element.addEventListener) {
/* 1592 */             element.addEventListener(event, listener, capture);
/* 1593 */         } else if (element.attachEvent) {
/* 1594 */             element.attachEvent('on' + event, listener);
/* 1595 */         }
/* 1596 */     };
/* 1597 */ 
/* 1598 */     /**
/* 1599 *|      * Detaches from an internal event.
/* 1600 *|      * @protected

/* owl.carousel.js */

/* 1601 *|      * @param {HTMLElement} element - The event source.
/* 1602 *|      * @param {String} event - The event name.
/* 1603 *|      * @param {Function} listener - The attached event handler to detach.
/* 1604 *|      * @param {Boolean} capture - Wether the attached event handler was registered as a capturing listener or not.
/* 1605 *|      */
/* 1606 */     Owl2.prototype.off = function(element, event, listener, capture) {
/* 1607 */         if (element.removeEventListener) {
/* 1608 */             element.removeEventListener(event, listener, capture);
/* 1609 */         } else if (element.detachEvent) {
/* 1610 */             element.detachEvent('on' + event, listener);
/* 1611 */         }
/* 1612 */     };
/* 1613 */ 
/* 1614 */     /**
/* 1615 *|      * Triggers an public event.
/* 1616 *|      * @protected
/* 1617 *|      * @param {String} name - The event name.
/* 1618 *|      * @param {*} [data=null] - The event data.
/* 1619 *|      * @param {String} [namespace=.owl.carousel2] - The event namespace.
/* 1620 *|      * @returns {Event} - The event arguments.
/* 1621 *|      */
/* 1622 */     Owl2.prototype.trigger = function(name, data, namespace) {
/* 1623 */         var status = {
/* 1624 */             item: { count: this._items.length, index: this.current() }
/* 1625 */         }, handler = $.camelCase(
/* 1626 */             $.grep([ 'on', name, namespace ], function(v) { return v })
/* 1627 */                 .join('-').toLowerCase()
/* 1628 */         ), event = $.Event(
/* 1629 */             [ name, 'owl', namespace || 'carousel2' ].join('.').toLowerCase(),
/* 1630 */             $.extend({ relatedTarget: this }, status, data)
/* 1631 */         );
/* 1632 */ 
/* 1633 */         if (!this._supress[name]) {
/* 1634 */             $.each(this._plugins, function(name, plugin) {
/* 1635 */                 if (plugin.onTrigger) {
/* 1636 */                     plugin.onTrigger(event);
/* 1637 */                 }
/* 1638 */             });
/* 1639 */ 
/* 1640 */             this.$element.trigger(event);
/* 1641 */ 
/* 1642 */             if (this.settings && typeof this.settings[handler] === 'function') {
/* 1643 */                 this.settings[handler].apply(this, event);
/* 1644 */             }
/* 1645 */         }
/* 1646 */ 
/* 1647 */         return event;
/* 1648 */     };
/* 1649 */ 
/* 1650 */     /**

/* owl.carousel.js */

/* 1651 *|      * Suppresses events.
/* 1652 *|      * @protected
/* 1653 *|      * @param {Array.<String>} events - The events to suppress.
/* 1654 *|      */
/* 1655 */     Owl2.prototype.suppress = function(events) {
/* 1656 */         $.each(events, $.proxy(function(index, event) {
/* 1657 */             this._supress[event] = true;
/* 1658 */         }, this));
/* 1659 */     }
/* 1660 */ 
/* 1661 */     /**
/* 1662 *|      * Releases suppressed events.
/* 1663 *|      * @protected
/* 1664 *|      * @param {Array.<String>} events - The events to release.
/* 1665 *|      */
/* 1666 */     Owl2.prototype.release = function(events) {
/* 1667 */         $.each(events, $.proxy(function(index, event) {
/* 1668 */             delete this._supress[event];
/* 1669 */         }, this));
/* 1670 */     }
/* 1671 */ 
/* 1672 */     /**
/* 1673 *|      * Checks the availability of some browser features.
/* 1674 *|      * @protected
/* 1675 *|      */
/* 1676 */     Owl2.prototype.browserSupport = function() {
/* 1677 */         this.support3d = isPerspective();
/* 1678 */ 
/* 1679 */         if (this.support3d) {
/* 1680 */             this.transformVendor = isTransform();
/* 1681 */ 
/* 1682 */             // take transitionend event name by detecting transition
/* 1683 */             var endVendors = [ 'transitionend', 'webkitTransitionEnd', 'transitionend', 'oTransitionEnd' ];
/* 1684 */             this.transitionEndVendor = endVendors[isTransition()];
/* 1685 */ 
/* 1686 */             // take vendor name from transform name
/* 1687 */             this.vendorName = this.transformVendor.replace(/Transform/i, '');
/* 1688 */             this.vendorName = this.vendorName !== '' ? '-' + this.vendorName.toLowerCase() + '-' : '';
/* 1689 */         }
/* 1690 */ 
/* 1691 */         this.state.orientation = window.orientation;
/* 1692 */     };
/* 1693 */ 
/* 1694 */     /**
/* 1695 *|      * Get touch/drag coordinats.
/* 1696 *|      * @private
/* 1697 *|      * @param {event} - mousedown/touchstart event
/* 1698 *|      * @returns {object} - Contains X and Y of current mouse/touch position
/* 1699 *|      */
/* 1700 */ 

/* owl.carousel.js */

/* 1701 */     function getTouches(event) {
/* 1702 */         if (event.touches !== undefined) {
/* 1703 */             return {
/* 1704 */                 x: event.touches[0].pageX,
/* 1705 */                 y: event.touches[0].pageY
/* 1706 */             };
/* 1707 */         }
/* 1708 */ 
/* 1709 */         if (event.touches === undefined) {
/* 1710 */             if (event.pageX !== undefined) {
/* 1711 */                 return {
/* 1712 */                     x: event.pageX,
/* 1713 */                     y: event.pageY
/* 1714 */                 };
/* 1715 */             }
/* 1716 */ 
/* 1717 */             if (event.pageX === undefined) {
/* 1718 */                 return {
/* 1719 */                     x: event.clientX,
/* 1720 */                     y: event.clientY
/* 1721 */                 };
/* 1722 */             }
/* 1723 */         }
/* 1724 */     }
/* 1725 */ 
/* 1726 */     /**
/* 1727 *|      * Checks for CSS support.
/* 1728 *|      * @private
/* 1729 *|      * @param {Array} array - The CSS properties to check for.
/* 1730 *|      * @returns {Array} - Contains the supported CSS property name and its index or `false`.
/* 1731 *|      */
/* 1732 */     function isStyleSupported(array) {
/* 1733 */         var p, s, fake = document.createElement('div'), list = array;
/* 1734 */         for (p in list) {
/* 1735 */             s = list[p];
/* 1736 */             if (typeof fake.style[s] !== 'undefined') {
/* 1737 */                 fake = null;
/* 1738 */                 return [ s, p ];
/* 1739 */             }
/* 1740 */         }
/* 1741 */         return [ false ];
/* 1742 */     }
/* 1743 */ 
/* 1744 */     /**
/* 1745 *|      * Checks for CSS transition support.
/* 1746 *|      * @private
/* 1747 *|      * @todo Realy bad design
/* 1748 *|      * @returns {Number}
/* 1749 *|      */
/* 1750 */     function isTransition() {

/* owl.carousel.js */

/* 1751 */         return isStyleSupported([ 'transition', 'WebkitTransition', 'MozTransition', 'OTransition' ])[1];
/* 1752 */     }
/* 1753 */ 
/* 1754 */     /**
/* 1755 *|      * Checks for CSS transform support.
/* 1756 *|      * @private
/* 1757 *|      * @returns {String} The supported property name or false.
/* 1758 *|      */
/* 1759 */     function isTransform() {
/* 1760 */         return isStyleSupported([ 'transform', 'WebkitTransform', 'MozTransform', 'OTransform', 'msTransform' ])[0];
/* 1761 */     }
/* 1762 */ 
/* 1763 */     /**
/* 1764 *|      * Checks for CSS perspective support.
/* 1765 *|      * @private
/* 1766 *|      * @returns {String} The supported property name or false.
/* 1767 *|      */
/* 1768 */     function isPerspective() {
/* 1769 */         return isStyleSupported([ 'perspective', 'webkitPerspective', 'MozPerspective', 'OPerspective', 'MsPerspective' ])[0];
/* 1770 */     }
/* 1771 */ 
/* 1772 */     /**
/* 1773 *|      * Checks wether touch is supported or not.
/* 1774 *|      * @private
/* 1775 *|      * @returns {Boolean}
/* 1776 *|      */
/* 1777 */     function isTouchSupport() {
/* 1778 */         return 'ontouchstart' in window || !!(navigator.msMaxTouchPoints);
/* 1779 */     }
/* 1780 */ 
/* 1781 */     /**
/* 1782 *|      * Checks wether touch is supported or not for IE.
/* 1783 *|      * @private
/* 1784 *|      * @returns {Boolean}
/* 1785 *|      */
/* 1786 */     function isTouchSupportIE() {
/* 1787 */         return window.navigator.msPointerEnabled;
/* 1788 */     }
/* 1789 */ 
/* 1790 */     /**
/* 1791 *|      * The jQuery Plugin for the Owl2 Carousel
/* 1792 *|      * @public
/* 1793 *|      */
/* 1794 */     $.fn.owlCarousel2 = function(options) {
/* 1795 */         return this.each(function() {
/* 1796 */             if (!$(this).data('owlCarousel2')) {
/* 1797 */                 $(this).data('owlCarousel2', new Owl2(this, options));
/* 1798 */             }
/* 1799 */         });
/* 1800 */     };

/* owl.carousel.js */

/* 1801 */ 
/* 1802 */     /**
/* 1803 *|      * The constructor for the jQuery Plugin
/* 1804 *|      * @public
/* 1805 *|      */
/* 1806 */     $.fn.owlCarousel2.Constructor = Owl2;
/* 1807 */ 
/* 1808 */ })(window.Zepto || window.jQuery, window, document);
/* 1809 */ 
/* 1810 */ /**
/* 1811 *|  * Lazy Plugin
/* 1812 *|  * @version 2.0.0
/* 1813 *|  * @author Bartosz Wojciechowski
/* 1814 *|  * @license The MIT License (MIT)
/* 1815 *|  */
/* 1816 */ ;(function($, window, document, undefined) {
/* 1817 */ 
/* 1818 */     /**
/* 1819 *|      * Creates the lazy plugin.
/* 1820 *|      * @class The Lazy Plugin
/* 1821 *|      * @param {Owl2} carousel2 - The Owl2 Carousel
/* 1822 *|      */
/* 1823 */     var Lazy = function(carousel2) {
/* 1824 */ 
/* 1825 */         /**
/* 1826 *|          * Reference to the core.
/* 1827 *|          * @protected
/* 1828 *|          * @type {Owl2}
/* 1829 *|          */
/* 1830 */         this._core = carousel2;
/* 1831 */ 
/* 1832 */         /**
/* 1833 *|          * Already loaded items.
/* 1834 *|          * @protected
/* 1835 *|          * @type {Array.<jQuery>}
/* 1836 *|          */
/* 1837 */         this._loaded = [];
/* 1838 */ 
/* 1839 */         /**
/* 1840 *|          * Event handlers.
/* 1841 *|          * @protected
/* 1842 *|          * @type {Object}
/* 1843 *|          */
/* 1844 */         this._handlers = {
/* 1845 */             'initialized.owl.carousel2 change.owl.carousel2': $.proxy(function(e) {
/* 1846 */                 if (!e.namespace) {
/* 1847 */                     return;
/* 1848 */                 }
/* 1849 */ 
/* 1850 */                 if (!this._core.settings || !this._core.settings.lazyLoad) {

/* owl.carousel.js */

/* 1851 */                     return;
/* 1852 */                 }
/* 1853 */ 
/* 1854 */                 if ((e.property && e.property.name == 'position') || e.type == 'initialized') {
/* 1855 */                     var settings = this._core.settings,
/* 1856 */                         n = (settings.center && Math.ceil(settings.items / 2) || settings.items),
/* 1857 */                         i = ((settings.center && n * -1) || 0),
/* 1858 */                         position = ((e.property && e.property.value) || this._core.current()) + i,
/* 1859 */                         clones = this._core.clones().length,
/* 1860 */                         load = $.proxy(function(i, v) { this.load(v) }, this);
/* 1861 */ 
/* 1862 */                     while (i++ < n) {
/* 1863 */                         this.load(clones / 2 + this._core.relative(position));
/* 1864 */                         clones && $.each(this._core.clones(this._core.relative(position++)), load);
/* 1865 */                     }
/* 1866 */                 }
/* 1867 */             }, this)
/* 1868 */         };
/* 1869 */ 
/* 1870 */         // set the default options
/* 1871 */         this._core.options = $.extend({}, Lazy.Defaults, this._core.options);
/* 1872 */ 
/* 1873 */         // register event handler
/* 1874 */         this._core.$element.on(this._handlers);
/* 1875 */     }
/* 1876 */ 
/* 1877 */     /**
/* 1878 *|      * Default options.
/* 1879 *|      * @public
/* 1880 *|      */
/* 1881 */     Lazy.Defaults = {
/* 1882 */         lazyLoad: false
/* 1883 */     }
/* 1884 */ 
/* 1885 */     /**
/* 1886 *|      * Loads all resources of an item at the specified position.
/* 1887 *|      * @param {Number} position - The absolute position of the item.
/* 1888 *|      * @protected
/* 1889 *|      */
/* 1890 */     Lazy.prototype.load = function(position) {
/* 1891 */         var $item = this._core.$stage.children().eq(position),
/* 1892 */             $elements = $item && $item.find('.owl2-lazy');
/* 1893 */ 
/* 1894 */         if (!$elements || $.inArray($item.get(0), this._loaded) > -1) {
/* 1895 */             return;
/* 1896 */         }
/* 1897 */ 
/* 1898 */         $elements.each($.proxy(function(index, element) {
/* 1899 */             var $element = $(element), image,
/* 1900 */                 url = (window.devicePixelRatio > 1 && $element.attr('data-src-retina')) || $element.attr('data-src');

/* owl.carousel.js */

/* 1901 */ 
/* 1902 */             this._core.trigger('load', { element: $element, url: url }, 'lazy');
/* 1903 */ 
/* 1904 */             if ($element.is('img')) {
/* 1905 */                 $element.one('load.owl.lazy', $.proxy(function() {
/* 1906 */                     $element.css('opacity', 1);
/* 1907 */                     this._core.trigger('loaded', { element: $element, url: url }, 'lazy');
/* 1908 */                 }, this)).attr('src', url);
/* 1909 */             } else {
/* 1910 */                 image = new Image();
/* 1911 */                 image.onload = $.proxy(function() {
/* 1912 */                     $element.css({
/* 1913 */                         'background-image': 'url(' + url + ')',
/* 1914 */                         'opacity': '1'
/* 1915 */                     });
/* 1916 */                     this._core.trigger('loaded', { element: $element, url: url }, 'lazy');
/* 1917 */                 }, this);
/* 1918 */                 image.src = url;
/* 1919 */             }
/* 1920 */         }, this));
/* 1921 */ 
/* 1922 */         this._loaded.push($item.get(0));
/* 1923 */     }
/* 1924 */ 
/* 1925 */     /**
/* 1926 *|      * Destroys the plugin.
/* 1927 *|      * @public
/* 1928 *|      */
/* 1929 */     Lazy.prototype.destroy = function() {
/* 1930 */         var handler, property;
/* 1931 */ 
/* 1932 */         for (handler in this.handlers) {
/* 1933 */             this._core.$element.off(handler, this.handlers[handler]);
/* 1934 */         }
/* 1935 */         for (property in Object.getOwnPropertyNames(this)) {
/* 1936 */             typeof this[property] != 'function' && (this[property] = null);
/* 1937 */         }
/* 1938 */     }
/* 1939 */ 
/* 1940 */     $.fn.owlCarousel2.Constructor.Plugins.Lazy = Lazy;
/* 1941 */ 
/* 1942 */ })(window.Zepto || window.jQuery, window, document);
/* 1943 */ 
/* 1944 */ /**
/* 1945 *|  * AutoHeight Plugin
/* 1946 *|  * @version 2.0.0
/* 1947 *|  * @author Bartosz Wojciechowski
/* 1948 *|  * @license The MIT License (MIT)
/* 1949 *|  */
/* 1950 */ ;(function($, window, document, undefined) {

/* owl.carousel.js */

/* 1951 */ 
/* 1952 */     /**
/* 1953 *|      * Creates the auto height plugin.
/* 1954 *|      * @class The Auto Height Plugin
/* 1955 *|      * @param {Owl2} carousel2 - The Owl2 Carousel
/* 1956 *|      */
/* 1957 */     var AutoHeight = function(carousel2) {
/* 1958 */         /**
/* 1959 *|          * Reference to the core.
/* 1960 *|          * @protected
/* 1961 *|          * @type {Owl2}
/* 1962 *|          */
/* 1963 */         this._core = carousel2;
/* 1964 */ 
/* 1965 */         /**
/* 1966 *|          * All event handlers.
/* 1967 *|          * @protected
/* 1968 *|          * @type {Object}
/* 1969 *|          */
/* 1970 */         this._handlers = {
/* 1971 */             'initialized.owl.carousel2': $.proxy(function() {
/* 1972 */                 if (this._core.settings.autoHeight) {
/* 1973 */                     this.update();
/* 1974 */                 }
/* 1975 */             }, this),
/* 1976 */             'changed.owl.carousel2': $.proxy(function(e) {
/* 1977 */                 if (this._core.settings.autoHeight && e.property.name == 'position'){
/* 1978 */                     this.update();
/* 1979 */                 }
/* 1980 */             }, this),
/* 1981 */             'loaded.owl.lazy': $.proxy(function(e) {
/* 1982 */                 if (this._core.settings.autoHeight && e.element.closest('.' + this._core.settings.itemClass)
/* 1983 */                     === this._core.$stage.children().eq(this._core.current())) {
/* 1984 */                     this.update();
/* 1985 */                 }
/* 1986 */             }, this)
/* 1987 */         };
/* 1988 */ 
/* 1989 */         // set default options
/* 1990 */         this._core.options = $.extend({}, AutoHeight.Defaults, this._core.options);
/* 1991 */ 
/* 1992 */         // register event handlers
/* 1993 */         this._core.$element.on(this._handlers);
/* 1994 */     };
/* 1995 */ 
/* 1996 */     /**
/* 1997 *|      * Default options.
/* 1998 *|      * @public
/* 1999 *|      */
/* 2000 */     AutoHeight.Defaults = {

/* owl.carousel.js */

/* 2001 */         autoHeight: false,
/* 2002 */         autoHeightClass: 'owl2-height'
/* 2003 */     };
/* 2004 */ 
/* 2005 */     /**
/* 2006 *|      * Updates the view.
/* 2007 *|      */
/* 2008 */     AutoHeight.prototype.update = function() {
/* 2009 */         this._core.$stage.parent()
/* 2010 */             .height(this._core.$stage.children().eq(this._core.current()).height())
/* 2011 */             .addClass(this._core.settings.autoHeightClass);
/* 2012 */     };
/* 2013 */ 
/* 2014 */     AutoHeight.prototype.destroy = function() {
/* 2015 */         var handler, property;
/* 2016 */ 
/* 2017 */         for (handler in this._handlers) {
/* 2018 */             this._core.$element.off(handler, this._handlers[handler]);
/* 2019 */         }
/* 2020 */         for (property in Object.getOwnPropertyNames(this)) {
/* 2021 */             typeof this[property] != 'function' && (this[property] = null);
/* 2022 */         }
/* 2023 */     };
/* 2024 */ 
/* 2025 */     $.fn.owlCarousel2.Constructor.Plugins.AutoHeight = AutoHeight;
/* 2026 */ 
/* 2027 */ })(window.Zepto || window.jQuery, window, document);
/* 2028 */ 
/* 2029 */ /**
/* 2030 *|  * Video Plugin
/* 2031 *|  * @version 2.0.0
/* 2032 *|  * @author Bartosz Wojciechowski
/* 2033 *|  * @license The MIT License (MIT)
/* 2034 *|  */
/* 2035 */ ;(function($, window, document, undefined) {
/* 2036 */ 
/* 2037 */     /**
/* 2038 *|      * Creates the video plugin.
/* 2039 *|      * @class The Video Plugin
/* 2040 *|      * @param {Owl2} carousel2 - The Owl2 Carousel
/* 2041 *|      */
/* 2042 */     var Video = function(carousel2) {
/* 2043 */         /**
/* 2044 *|          * Reference to the core.
/* 2045 *|          * @protected
/* 2046 *|          * @type {Owl2}
/* 2047 *|          */
/* 2048 */         this._core = carousel2;
/* 2049 */ 
/* 2050 */         /**

/* owl.carousel.js */

/* 2051 *|          * Cache all video URLs.
/* 2052 *|          * @protected
/* 2053 *|          * @type {Object}
/* 2054 *|          */
/* 2055 */         this._videos = {};
/* 2056 */ 
/* 2057 */         /**
/* 2058 *|          * Current playing item.
/* 2059 *|          * @protected
/* 2060 *|          * @type {jQuery}
/* 2061 *|          */
/* 2062 */         this._playing = null;
/* 2063 */ 
/* 2064 */         /**
/* 2065 *|          * Whether this is in fullscreen or not.
/* 2066 *|          * @protected
/* 2067 *|          * @type {Boolean}
/* 2068 *|          */
/* 2069 */         this._fullscreen = false;
/* 2070 */ 
/* 2071 */         /**
/* 2072 *|          * All event handlers.
/* 2073 *|          * @protected
/* 2074 *|          * @type {Object}
/* 2075 *|          */
/* 2076 */         this._handlers = {
/* 2077 */             'resize.owl.carousel2': $.proxy(function(e) {
/* 2078 */                 if (this._core.settings.video && !this.isInFullScreen()) {
/* 2079 */                     e.preventDefault();
/* 2080 */                 }
/* 2081 */             }, this),
/* 2082 */             'refresh.owl.carousel2 changed.owl.carousel2': $.proxy(function(e) {
/* 2083 */                 if (this._playing) {
/* 2084 */                     this.stop();
/* 2085 */                 }
/* 2086 */             }, this),
/* 2087 */             'prepared.owl.carousel2': $.proxy(function(e) {
/* 2088 */                 var $element = $(e.content).find('.owl2-video');
/* 2089 */                 if ($element.length) {
/* 2090 */                     $element.css('display', 'none');
/* 2091 */                     this.fetch($element, $(e.content));
/* 2092 */                 }
/* 2093 */             }, this)
/* 2094 */         };
/* 2095 */ 
/* 2096 */         // set default options
/* 2097 */         this._core.options = $.extend({}, Video.Defaults, this._core.options);
/* 2098 */ 
/* 2099 */         // register event handlers
/* 2100 */         this._core.$element.on(this._handlers);

/* owl.carousel.js */

/* 2101 */ 
/* 2102 */         this._core.$element.on('click.owl.video', '.owl2-video-play-icon', $.proxy(function(e) {
/* 2103 */             this.play(e);
/* 2104 */         }, this));
/* 2105 */     };
/* 2106 */ 
/* 2107 */     /**
/* 2108 *|      * Default options.
/* 2109 *|      * @public
/* 2110 *|      */
/* 2111 */     Video.Defaults = {
/* 2112 */         video: false,
/* 2113 */         videoHeight: false,
/* 2114 */         videoWidth: false
/* 2115 */     };
/* 2116 */ 
/* 2117 */     /**
/* 2118 *|      * Gets the video ID and the type (YouTube/Vimeo only).
/* 2119 *|      * @protected
/* 2120 *|      * @param {jQuery} target - The target containing the video data.
/* 2121 *|      * @param {jQuery} item - The item containing the video.
/* 2122 *|      */
/* 2123 */     Video.prototype.fetch = function(target, item) {
/* 2124 */ 
/* 2125 */         var type = target.attr('data-vimeo-id') ? 'vimeo' : 'youtube',
/* 2126 */             id = target.attr('data-vimeo-id') || target.attr('data-youtube-id'),
/* 2127 */             width = target.attr('data-width') || this._core.settings.videoWidth,
/* 2128 */             height = target.attr('data-height') || this._core.settings.videoHeight,
/* 2129 */             url = target.attr('href');
/* 2130 */ 
/* 2131 */         if (url) {
/* 2132 */             id = url.match(/(http:|https:|)\/\/(player.|www.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com))\/(video\/|embed\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/);
/* 2133 */ 
/* 2134 */             if (id[3].indexOf('youtu') > -1) {
/* 2135 */                 type = 'youtube';
/* 2136 */             } else if (id[3].indexOf('vimeo') > -1) {
/* 2137 */                 type = 'vimeo';
/* 2138 */             } else {
/* 2139 */                 throw new Error('Video URL not supported.');
/* 2140 */             }
/* 2141 */             id = id[6];
/* 2142 */         } else {
/* 2143 */             throw new Error('Missing video URL.');
/* 2144 */         }
/* 2145 */ 
/* 2146 */         this._videos[url] = {
/* 2147 */             type: type,
/* 2148 */             id: id,
/* 2149 */             width: width,
/* 2150 */             height: height

/* owl.carousel.js */

/* 2151 */         };
/* 2152 */ 
/* 2153 */         item.attr('data-video', url);
/* 2154 */ 
/* 2155 */         this.thumbnail(target, this._videos[url]);
/* 2156 */     };
/* 2157 */ 
/* 2158 */     /**
/* 2159 *|      * Creates video thumbnail.
/* 2160 *|      * @protected
/* 2161 *|      * @param {jQuery} target - The target containing the video data.
/* 2162 *|      * @param {Object} info - The video info object.
/* 2163 *|      * @see `fetch`
/* 2164 *|      */
/* 2165 */     Video.prototype.thumbnail = function(target, video) {
/* 2166 */ 
/* 2167 */         var tnLink,
/* 2168 */             icon,
/* 2169 */             path,
/* 2170 */             dimensions = video.width && video.height ? 'style="width:' + video.width + 'px;height:' + video.height + 'px;"' : '',
/* 2171 */             customTn = target.find('img'),
/* 2172 */             srcType = 'src',
/* 2173 */             lazyClass = '',
/* 2174 */             settings = this._core.settings,
/* 2175 */             create = function(path) {
/* 2176 */                 icon = '<div class="owl2-video-play-icon"></div>';
/* 2177 */ 
/* 2178 */                 if (settings.lazyLoad) {
/* 2179 */                     tnLink = '<div class="owl2-video-tn ' + lazyClass + '" ' + srcType + '="' + path + '"></div>';
/* 2180 */                 } else {
/* 2181 */                     tnLink = '<div class="owl2-video-tn" style="opacity:1;background-image:url(' + path + ')"></div>';
/* 2182 */                 }
/* 2183 */                 target.after(tnLink);
/* 2184 */                 target.after(icon);
/* 2185 */             };
/* 2186 */ 
/* 2187 */         // wrap video content into owl2-video-wrapper div
/* 2188 */         target.wrap('<div class="owl2-video-wrapper"' + dimensions + '></div>');
/* 2189 */ 
/* 2190 */         if (this._core.settings.lazyLoad) {
/* 2191 */             srcType = 'data-src';
/* 2192 */             lazyClass = 'owl2-lazy';
/* 2193 */         }
/* 2194 */ 
/* 2195 */         // custom thumbnail
/* 2196 */         if (customTn.length) {
/* 2197 */             create(customTn.attr(srcType));
/* 2198 */             customTn.remove();
/* 2199 */             return false;
/* 2200 */         }

/* owl.carousel.js */

/* 2201 */ 
/* 2202 */         if (video.type === 'youtube') {
/* 2203 */             path = "http://img.youtube.com/vi/" + video.id + "/hqdefault.jpg";
/* 2204 */             create(path);
/* 2205 */         } else if (video.type === 'vimeo') {
/* 2206 */             $.ajax({
/* 2207 */                 type: 'GET',
/* 2208 */                 url: 'http://vimeo.com/api/v2/video/' + video.id + '.json',
/* 2209 */                 jsonp: 'callback',
/* 2210 */                 dataType: 'jsonp',
/* 2211 */                 success: function(data) {
/* 2212 */                     path = data[0].thumbnail_large;
/* 2213 */                     create(path);
/* 2214 */                 }
/* 2215 */             });
/* 2216 */         }
/* 2217 */     };
/* 2218 */ 
/* 2219 */     /**
/* 2220 *|      * Stops the current video.
/* 2221 *|      * @public
/* 2222 *|      */
/* 2223 */     Video.prototype.stop = function() {
/* 2224 */         this._core.trigger('stop', null, 'video');
/* 2225 */         this._playing.find('.owl2-video-frame').remove();
/* 2226 */         this._playing.removeClass('owl2-video-playing');
/* 2227 */         this._playing = null;
/* 2228 */     };
/* 2229 */ 
/* 2230 */     /**
/* 2231 *|      * Starts the current video.
/* 2232 *|      * @public
/* 2233 *|      * @param {Event} ev - The event arguments.
/* 2234 *|      */
/* 2235 */     Video.prototype.play = function(ev) {
/* 2236 */         this._core.trigger('play', null, 'video');
/* 2237 */ 
/* 2238 */         if (this._playing) {
/* 2239 */             this.stop();
/* 2240 */         }
/* 2241 */ 
/* 2242 */         var target = $(ev.target || ev.srcElement),
/* 2243 */             item = target.closest('.' + this._core.settings.itemClass),
/* 2244 */             video = this._videos[item.attr('data-video')],
/* 2245 */             width = video.width || '100%',
/* 2246 */             height = video.height || this._core.$stage.height(),
/* 2247 */             html, wrap;
/* 2248 */ 
/* 2249 */         if (video.type === 'youtube') {
/* 2250 */             html = '<iframe width="' + width + '" height="' + height + '" src="http://www.youtube.com/embed/'

/* owl.carousel.js */

/* 2251 */             + video.id + '?autoplay=1&v=' + video.id + '" frameborder="0" allowfullscreen></iframe>';
/* 2252 */         } else if (video.type === 'vimeo') {
/* 2253 */             html = '<iframe src="http://player.vimeo.com/video/' + video.id + '?autoplay=1" width="' + width
/* 2254 */             + '" height="' + height
/* 2255 */             + '" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
/* 2256 */         }
/* 2257 */ 
/* 2258 */         item.addClass('owl2-video-playing');
/* 2259 */         this._playing = item;
/* 2260 */ 
/* 2261 */         wrap = $('<div style="height:' + height + 'px; width:' + width + 'px" class="owl2-video-frame">'
/* 2262 */         + html + '</div>');
/* 2263 */         target.after(wrap);
/* 2264 */     };
/* 2265 */ 
/* 2266 */     /**
/* 2267 *|      * Checks whether an video is currently in full screen mode or not.
/* 2268 *|      * @todo Bad style because looks like a readonly method but changes members.
/* 2269 *|      * @protected
/* 2270 *|      * @returns {Boolean}
/* 2271 *|      */
/* 2272 */     Video.prototype.isInFullScreen = function() {
/* 2273 */ 
/* 2274 */         // if Vimeo Fullscreen mode
/* 2275 */         var element = document.fullscreenElement || document.mozFullScreenElement
/* 2276 */             || document.webkitFullscreenElement;
/* 2277 */ 
/* 2278 */         if (element && $(element).parent().hasClass('owl2-video-frame')) {
/* 2279 */             this._core.speed(0);
/* 2280 */             this._fullscreen = true;
/* 2281 */         }
/* 2282 */ 
/* 2283 */         if (element && this._fullscreen && this._playing) {
/* 2284 */             return false;
/* 2285 */         }
/* 2286 */ 
/* 2287 */         // comming back from fullscreen
/* 2288 */         if (this._fullscreen) {
/* 2289 */             this._fullscreen = false;
/* 2290 */             return false;
/* 2291 */         }
/* 2292 */ 
/* 2293 */         // check full screen mode and window orientation
/* 2294 */         if (this._playing) {
/* 2295 */             if (this._core.state.orientation !== window.orientation) {
/* 2296 */                 this._core.state.orientation = window.orientation;
/* 2297 */                 return false;
/* 2298 */             }
/* 2299 */         }
/* 2300 */ 

/* owl.carousel.js */

/* 2301 */         return true;
/* 2302 */     };
/* 2303 */ 
/* 2304 */     /**
/* 2305 *|      * Destroys the plugin.
/* 2306 *|      */
/* 2307 */     Video.prototype.destroy = function() {
/* 2308 */         var handler, property;
/* 2309 */ 
/* 2310 */         this._core.$element.off('click.owl.video');
/* 2311 */ 
/* 2312 */         for (handler in this._handlers) {
/* 2313 */             this._core.$element.off(handler, this._handlers[handler]);
/* 2314 */         }
/* 2315 */         for (property in Object.getOwnPropertyNames(this)) {
/* 2316 */             typeof this[property] != 'function' && (this[property] = null);
/* 2317 */         }
/* 2318 */     };
/* 2319 */ 
/* 2320 */     $.fn.owlCarousel2.Constructor.Plugins.Video = Video;
/* 2321 */ 
/* 2322 */ })(window.Zepto || window.jQuery, window, document);
/* 2323 */ 
/* 2324 */ /**
/* 2325 *|  * Animate Plugin
/* 2326 *|  * @version 2.0.0
/* 2327 *|  * @author Bartosz Wojciechowski
/* 2328 *|  * @license The MIT License (MIT)
/* 2329 *|  */
/* 2330 */ ;(function($, window, document, undefined) {
/* 2331 */ 
/* 2332 */     /**
/* 2333 *|      * Creates the animate plugin.
/* 2334 *|      * @class The Navigation Plugin
/* 2335 *|      * @param {Owl2} scope - The Owl2 Carousel
/* 2336 *|      */
/* 2337 */     var Animate = function(scope) {
/* 2338 */         this.core = scope;
/* 2339 */         this.core.options = $.extend({}, Animate.Defaults, this.core.options);
/* 2340 */         this.swapping = true;
/* 2341 */         this.previous = undefined;
/* 2342 */         this.next = undefined;
/* 2343 */ 
/* 2344 */         this.handlers = {
/* 2345 */             'change.owl.carousel2': $.proxy(function(e) {
/* 2346 */                 if (e.property.name == 'position') {
/* 2347 */                     this.previous = this.core.current();
/* 2348 */                     this.next = e.property.value;
/* 2349 */                 }
/* 2350 */             }, this),

/* owl.carousel.js */

/* 2351 */             'drag.owl.carousel2 dragged.owl.carousel2 translated.owl.carousel2': $.proxy(function(e) {
/* 2352 */                 this.swapping = e.type == 'translated';
/* 2353 */             }, this),
/* 2354 */             'translate.owl.carousel2': $.proxy(function(e) {
/* 2355 */                 if (this.swapping && (this.core.options.animateOut || this.core.options.animateIn)) {
/* 2356 */                     this.swap();
/* 2357 */                 }
/* 2358 */             }, this)
/* 2359 */         };
/* 2360 */ 
/* 2361 */         this.core.$element.on(this.handlers);
/* 2362 */     };
/* 2363 */ 
/* 2364 */     /**
/* 2365 *|      * Default options.
/* 2366 *|      * @public
/* 2367 *|      */
/* 2368 */     Animate.Defaults = {
/* 2369 */         animateOut: false,
/* 2370 */         animateIn: false
/* 2371 */     };
/* 2372 */ 
/* 2373 */     /**
/* 2374 *|      * Toggles the animation classes whenever an translations starts.
/* 2375 *|      * @protected
/* 2376 *|      * @returns {Boolean|undefined}
/* 2377 *|      */
/* 2378 */     Animate.prototype.swap = function() {
/* 2379 */ 
/* 2380 */         if (this.core.settings.items !== 1 || !this.core.support3d) {
/* 2381 */             return;
/* 2382 */         }
/* 2383 */ 
/* 2384 */         this.core.speed(0);
/* 2385 */ 
/* 2386 */         var left,
/* 2387 */             clear = $.proxy(this.clear, this),
/* 2388 */             previous = this.core.$stage.children().eq(this.previous),
/* 2389 */             next = this.core.$stage.children().eq(this.next),
/* 2390 */             incoming = this.core.settings.animateIn,
/* 2391 */             outgoing = this.core.settings.animateOut;
/* 2392 */ 
/* 2393 */         if (this.core.current() === this.previous) {
/* 2394 */             return;
/* 2395 */         }
/* 2396 */ 
/* 2397 */         if (outgoing) {
/* 2398 */             left = this.core.coordinates(this.previous) - this.core.coordinates(this.next);
/* 2399 */             previous.css( { 'left': left + 'px' } )
/* 2400 */                 .addClass('animated owl2-animated-out')

/* owl.carousel.js */

/* 2401 */                 .addClass(outgoing)
/* 2402 */                 .one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', clear);
/* 2403 */         }
/* 2404 */ 
/* 2405 */         if (incoming) {
/* 2406 */             next.addClass('animated owl2-animated-in')
/* 2407 */                 .addClass(incoming)
/* 2408 */                 .one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', clear);
/* 2409 */         }
/* 2410 */     };
/* 2411 */ 
/* 2412 */     Animate.prototype.clear = function(e) {
/* 2413 */         $(e.target).css( { 'left': '' } )
/* 2414 */             .removeClass('animated owl2-animated-out owl2-animated-in')
/* 2415 */             .removeClass(this.core.settings.animateIn)
/* 2416 */             .removeClass(this.core.settings.animateOut);
/* 2417 */         this.core.transitionEnd();
/* 2418 */     }
/* 2419 */ 
/* 2420 */     /**
/* 2421 *|      * Destroys the plugin.
/* 2422 *|      * @public
/* 2423 *|      */
/* 2424 */     Animate.prototype.destroy = function() {
/* 2425 */         var handler, property;
/* 2426 */ 
/* 2427 */         for (handler in this.handlers) {
/* 2428 */             this.core.$element.off(handler, this.handlers[handler]);
/* 2429 */         }
/* 2430 */         for (property in Object.getOwnPropertyNames(this)) {
/* 2431 */             typeof this[property] != 'function' && (this[property] = null);
/* 2432 */         }
/* 2433 */     };
/* 2434 */ 
/* 2435 */     $.fn.owlCarousel2.Constructor.Plugins.Animate = Animate;
/* 2436 */ 
/* 2437 */ })(window.Zepto || window.jQuery, window, document);
/* 2438 */ 
/* 2439 */ /**
/* 2440 *|  * Autoplay Plugin
/* 2441 *|  * @version 2.0.0
/* 2442 *|  * @author Bartosz Wojciechowski
/* 2443 *|  * @license The MIT License (MIT)
/* 2444 *|  */
/* 2445 */ ;(function($, window, document, undefined) {
/* 2446 */ 
/* 2447 */     /**
/* 2448 *|      * Creates the autoplay plugin.
/* 2449 *|      * @class The Autoplay Plugin
/* 2450 *|      * @param {Owl2} scope - The Owl2 Carousel

/* owl.carousel.js */

/* 2451 *|      */
/* 2452 */     var Autoplay = function(scope) {
/* 2453 */         this.core = scope;
/* 2454 */         this.core.options = $.extend({}, Autoplay.Defaults, this.core.options);
/* 2455 */ 
/* 2456 */         this.handlers = {
/* 2457 */             'translated.owl.carousel2 refreshed.owl.carousel2': $.proxy(function() {
/* 2458 */                 this.autoplay();
/* 2459 */             }, this),
/* 2460 */             'play.owl.autoplay': $.proxy(function(e, t, s) {
/* 2461 */                 this.play(t, s);
/* 2462 */             }, this),
/* 2463 */             'stop.owl.autoplay': $.proxy(function() {
/* 2464 */                 this.stop();
/* 2465 */             }, this),
/* 2466 */             'mouseover.owl.autoplay': $.proxy(function() {
/* 2467 */                 if (this.core.settings.autoplayHoverPause) {
/* 2468 */                     this.pause();
/* 2469 */                 }
/* 2470 */ 
/* 2471 */             }, this),
/* 2472 */             'mouseleave.owl.autoplay': $.proxy(function() {
/* 2473 */                 if (this.core.settings.autoplayHoverPause) {
/* 2474 */                     this.autoplay();
/* 2475 */                 }
/* 2476 */ 
/* 2477 */             }, this)
/* 2478 */         };
/* 2479 */ 
/* 2480 */         this.core.$element.on(this.handlers);
/* 2481 */     };
/* 2482 */ 
/* 2483 */     /**
/* 2484 *|      * Default options.
/* 2485 *|      * @public
/* 2486 *|      */
/* 2487 */     Autoplay.Defaults = {
/* 2488 */         autoplay: false,
/* 2489 */         autoplayTimeout: 5000,
/* 2490 */         autoplayHoverPause: false,
/* 2491 */         autoplaySpeed: false
/* 2492 */     };
/* 2493 */ 
/* 2494 */     /**
/* 2495 *|      * @protected
/* 2496 *|      * @todo Must be documented.
/* 2497 *|      */
/* 2498 */     Autoplay.prototype.autoplay = function() {
/* 2499 */         if (this.core.options.autoplay) {
/* 2500 */             this.core.settings.autoplay = true;

/* owl.carousel.js */

/* 2501 */         }
/* 2502 */         if (this.core.settings.autoplay && !this.core.state.videoPlay) {
/* 2503 */             window.clearInterval(this.interval);
/* 2504 */ 
/* 2505 */             this.interval = window.setInterval($.proxy(function() {
/* 2506 */                 this.play();
/* 2507 */             }, this), this.core.settings.autoplayTimeout);
/* 2508 */         } else {
/* 2509 */             window.clearInterval(this.interval);
/* 2510 */         }
/* 2511 */     };
/* 2512 */ 
/* 2513 */     /**
/* 2514 *|      * Starts the autoplay.
/* 2515 *|      * @public
/* 2516 *|      * @param {Number} [timeout] - ...
/* 2517 *|      * @param {Number} [speed] - ...
/* 2518 *|      * @returns {Boolean|undefined} - ...
/* 2519 *|      * @todo Must be documented.
/* 2520 *|      */
/* 2521 */     Autoplay.prototype.play = function(timeout, speed) {
/* 2522 */         // if tab is inactive - doesnt work in <IE10
/* 2523 */         if (this.core.options.autoplay) {
/* 2524 */             this.core.settings.autoplay = true;
/* 2525 */         }
/* 2526 */         if (document.hidden === true) {
/* 2527 */             return;
/* 2528 */         }
/* 2529 */ 
/* 2530 */         if (this.core.state.isTouch || this.core.state.isScrolling
/* 2531 */             || this.core.state.isSwiping || this.core.state.inMotion) {
/* 2532 */             return;
/* 2533 */         }
/* 2534 */ 
/* 2535 */         if (this.core.settings.autoplay === false) {
/* 2536 */             window.clearInterval(this.interval);
/* 2537 */             return;
/* 2538 */         }
/* 2539 */ 
/* 2540 */         this.core.next(this.core.settings.autoplaySpeed);
/* 2541 */     };
/* 2542 */ 
/* 2543 */     /**
/* 2544 *|      * Stops the autoplay.
/* 2545 *|      * @public
/* 2546 *|      */
/* 2547 */     Autoplay.prototype.stop = function() {
/* 2548 */         if (this.core.options.autoplay) {
/* 2549 */             this.core.settings.autoplay = false;
/* 2550 */         }

/* owl.carousel.js */

/* 2551 */         window.clearInterval(this.interval);
/* 2552 */     };
/* 2553 */ 
/* 2554 */     /**
/* 2555 *|      * Pauses the autoplay.
/* 2556 *|      * @public
/* 2557 *|      */
/* 2558 */     Autoplay.prototype.pause = function() {
/* 2559 */         if (this.core.options.autoplay) {
/* 2560 */             this.core.settings.autoplay = false;
/* 2561 */         }
/* 2562 */         window.clearInterval(this.interval);
/* 2563 */     };
/* 2564 */ 
/* 2565 */     /**
/* 2566 *|      * Destroys the plugin.
/* 2567 *|      */
/* 2568 */     Autoplay.prototype.destroy = function() {
/* 2569 */         var handler, property;
/* 2570 */ 
/* 2571 */         window.clearInterval(this.interval);
/* 2572 */ 
/* 2573 */         for (handler in this.handlers) {
/* 2574 */             this.core.$element.off(handler, this.handlers[handler]);
/* 2575 */         }
/* 2576 */         for (property in Object.getOwnPropertyNames(this)) {
/* 2577 */             typeof this[property] != 'function' && (this[property] = null);
/* 2578 */         }
/* 2579 */     };
/* 2580 */ 
/* 2581 */     $.fn.owlCarousel2.Constructor.Plugins.autoplay = Autoplay;
/* 2582 */ 
/* 2583 */ })(window.Zepto || window.jQuery, window, document);
/* 2584 */ 
/* 2585 */ /**
/* 2586 *|  * Navigation Plugin
/* 2587 *|  * @version 2.0.0
/* 2588 *|  * @author Artus Kolanowski
/* 2589 *|  * @license The MIT License (MIT)
/* 2590 *|  */
/* 2591 */ ;(function($, window, document, undefined) {
/* 2592 */     'use strict';
/* 2593 */ 
/* 2594 */     /**
/* 2595 *|      * Creates the navigation plugin.
/* 2596 *|      * @class The Navigation Plugin
/* 2597 *|      * @param {Owl2} carousel2 - The Owl2 Carousel.
/* 2598 *|      */
/* 2599 */     var Navigation = function(carousel2) {
/* 2600 */         /**

/* owl.carousel.js */

/* 2601 *|          * Reference to the core.
/* 2602 *|          * @protected
/* 2603 *|          * @type {Owl2}
/* 2604 *|          */
/* 2605 */         this._core = carousel2;
/* 2606 */ 
/* 2607 */         /**
/* 2608 *|          * Indicates whether the plugin is initialized or not.
/* 2609 *|          * @protected
/* 2610 *|          * @type {Boolean}
/* 2611 *|          */
/* 2612 */         this._initialized = false;
/* 2613 */ 
/* 2614 */         /**
/* 2615 *|          * The current paging indexes.
/* 2616 *|          * @protected
/* 2617 *|          * @type {Array}
/* 2618 *|          */
/* 2619 */         this._pages = [];
/* 2620 */ 
/* 2621 */         /**
/* 2622 *|          * All DOM elements of the user interface.
/* 2623 *|          * @protected
/* 2624 *|          * @type {Object}
/* 2625 *|          */
/* 2626 */         this._controls = {};
/* 2627 */ 
/* 2628 */         /**
/* 2629 *|          * Markup for an indicator.
/* 2630 *|          * @protected
/* 2631 *|          * @type {Array.<String>}
/* 2632 *|          */
/* 2633 */         this._templates = [];
/* 2634 */ 
/* 2635 */         /**
/* 2636 *|          * The carousel2 element.
/* 2637 *|          * @type {jQuery}
/* 2638 *|          */
/* 2639 */         this.$element = this._core.$element;
/* 2640 */ 
/* 2641 */         /**
/* 2642 *|          * Overridden methods of the carousel2.
/* 2643 *|          * @protected
/* 2644 *|          * @type {Object}
/* 2645 *|          */
/* 2646 */         this._overrides = {
/* 2647 */             next: this._core.next,
/* 2648 */             prev: this._core.prev,
/* 2649 */             to: this._core.to
/* 2650 */         };

/* owl.carousel.js */

/* 2651 */ 
/* 2652 */         /**
/* 2653 *|          * All event handlers.
/* 2654 *|          * @protected
/* 2655 *|          * @type {Object}
/* 2656 *|          */
/* 2657 */         this._handlers = {
/* 2658 */             'prepared.owl.carousel2': $.proxy(function(e) {
/* 2659 */                 if (this._core.settings.dotsData) {
/* 2660 */                     this._templates.push($(e.content).find('[data-dot]').andSelf('[data-dot]').attr('data-dot'));
/* 2661 */                 }
/* 2662 */             }, this),
/* 2663 */             'add.owl.carousel2': $.proxy(function(e) {
/* 2664 */                 if (this._core.settings.dotsData) {
/* 2665 */                     this._templates.splice(e.position, 0, $(e.content).find('[data-dot]').andSelf('[data-dot]').attr('data-dot'));
/* 2666 */                 }
/* 2667 */             }, this),
/* 2668 */             'remove.owl.carousel2 prepared.owl.carousel2': $.proxy(function(e) {
/* 2669 */                 if (this._core.settings.dotsData) {
/* 2670 */                     this._templates.splice(e.position, 1);
/* 2671 */                 }
/* 2672 */             }, this),
/* 2673 */             'change.owl.carousel2': $.proxy(function(e) {
/* 2674 */                 if (e.property.name == 'position') {
/* 2675 */                     if (!this._core.state.revert && !this._core.settings.loop && this._core.settings.navRewind) {
/* 2676 */                         var current = this._core.current(),
/* 2677 */                             maximum = this._core.maximum(),
/* 2678 */                             minimum = this._core.minimum();
/* 2679 */                         e.data = e.property.value > maximum
/* 2680 */                             ? current >= maximum ? minimum : maximum
/* 2681 */                             : e.property.value < minimum ? maximum : e.property.value;
/* 2682 */                     }
/* 2683 */                 }
/* 2684 */             }, this),
/* 2685 */             'changed.owl.carousel2': $.proxy(function(e) {
/* 2686 */                 if (e.property.name == 'position') {
/* 2687 */                     this.draw();
/* 2688 */                 }
/* 2689 */             }, this),
/* 2690 */             'refreshed.owl.carousel2': $.proxy(function() {
/* 2691 */                 if (!this._initialized) {
/* 2692 */                     this.initialize();
/* 2693 */                     this._initialized = true;
/* 2694 */                 }
/* 2695 */                 this._core.trigger('refresh', null, 'navigation');
/* 2696 */                 this.update();
/* 2697 */                 this.draw();
/* 2698 */                 this._core.trigger('refreshed', null, 'navigation');
/* 2699 */             }, this)
/* 2700 */         };

/* owl.carousel.js */

/* 2701 */ 
/* 2702 */         // set default options
/* 2703 */         this._core.options = $.extend({}, Navigation.Defaults, this._core.options);
/* 2704 */ 
/* 2705 */         // register event handlers
/* 2706 */         this.$element.on(this._handlers);
/* 2707 */     }
/* 2708 */ 
/* 2709 */     /**
/* 2710 *|      * Default options.
/* 2711 *|      * @public
/* 2712 *|      * @todo Rename `slideBy` to `navBy`
/* 2713 *|      */
/* 2714 */     Navigation.Defaults = {
/* 2715 */         nav: false,
/* 2716 */         navRewind: true,
/* 2717 */         navText: [ 'prev', 'next' ],
/* 2718 */         navSpeed: false,
/* 2719 */         navElement: 'div',
/* 2720 */         navContainer: false,
/* 2721 */         navContainerClass: 'owl2-nav',
/* 2722 */         navClass: [ 'owl2-prev', 'owl2-next' ],
/* 2723 */         slideBy: 1,
/* 2724 */         dotClass: 'owl2-dot',
/* 2725 */         dotsClass: 'owl2-dots',
/* 2726 */         dots: true,
/* 2727 */         dotsEach: false,
/* 2728 */         dotData: false,
/* 2729 */         dotsSpeed: false,
/* 2730 */         dotsContainer: false,
/* 2731 */         controlsClass: 'owl2-controls'
/* 2732 */     }
/* 2733 */ 
/* 2734 */     /**
/* 2735 *|      * Initializes the layout of the plugin and extends the carousel2.
/* 2736 *|      * @protected
/* 2737 *|      */
/* 2738 */     Navigation.prototype.initialize = function() {
/* 2739 */         var $container, override,
/* 2740 */             options = this._core.settings;
/* 2741 */ 
/* 2742 */         // create the indicator template
/* 2743 */         if (!options.dotsData) {
/* 2744 */             this._templates = [ $('<div>')
/* 2745 */                 .addClass(options.dotClass)
/* 2746 */                 .append($('<span>'))
/* 2747 */                 .prop('outerHTML') ];
/* 2748 */         }
/* 2749 */ 
/* 2750 */         // create controls container if needed

/* owl.carousel.js */

/* 2751 */         if (!options.navContainer || !options.dotsContainer) {
/* 2752 */             this._controls.$container = $('<div>')
/* 2753 */                 .addClass(options.controlsClass)
/* 2754 */                 .appendTo(this.$element);
/* 2755 */         }
/* 2756 */ 
/* 2757 */         // create DOM structure for absolute navigation
/* 2758 */         this._controls.$indicators = options.dotsContainer ? $(options.dotsContainer)
/* 2759 */             : $('<div>').hide().addClass(options.dotsClass).appendTo(this._controls.$container);
/* 2760 */ 
/* 2761 */         this._controls.$indicators.on('click', 'div', $.proxy(function(e) {
/* 2762 */             var index = $(e.target).parent().is(this._controls.$indicators)
/* 2763 */                 ? $(e.target).index() : $(e.target).parent().index();
/* 2764 */ 
/* 2765 */             e.preventDefault();
/* 2766 */ 
/* 2767 */             this.to(index, options.dotsSpeed);
/* 2768 */         }, this));
/* 2769 */ 
/* 2770 */         // create DOM structure for relative navigation
/* 2771 */         $container = options.navContainer ? $(options.navContainer)
/* 2772 */             : $('<div>').addClass(options.navContainerClass).prependTo(this._controls.$container);
/* 2773 */ 
/* 2774 */         this._controls.$next = $('<' + options.navElement + '>');
/* 2775 */         this._controls.$previous = this._controls.$next.clone();
/* 2776 */ 
/* 2777 */         this._controls.$previous
/* 2778 */             .addClass(options.navClass[0])
/* 2779 */             .html(options.navText[0])
/* 2780 */             .hide()
/* 2781 */             .prependTo($container)
/* 2782 */             .on('click', $.proxy(function(e) {
/* 2783 */                 this.prev(options.navSpeed);
/* 2784 */             }, this));
/* 2785 */         this._controls.$next
/* 2786 */             .addClass(options.navClass[1])
/* 2787 */             .html(options.navText[1])
/* 2788 */             .hide()
/* 2789 */             .appendTo($container)
/* 2790 */             .on('click', $.proxy(function(e) {
/* 2791 */                 this.next(options.navSpeed);
/* 2792 */             }, this));
/* 2793 */ 
/* 2794 */         // override public methods of the carousel2
/* 2795 */         for (override in this._overrides) {
/* 2796 */             this._core[override] = $.proxy(this[override], this);
/* 2797 */         }
/* 2798 */     }
/* 2799 */ 
/* 2800 */     /**

/* owl.carousel.js */

/* 2801 *|      * Destroys the plugin.
/* 2802 *|      * @protected
/* 2803 *|      */
/* 2804 */     Navigation.prototype.destroy = function() {
/* 2805 */         var handler, control, property, override;
/* 2806 */ 
/* 2807 */         for (handler in this._handlers) {
/* 2808 */             this.$element.off(handler, this._handlers[handler]);
/* 2809 */         }
/* 2810 */         for (control in this._controls) {
/* 2811 */             this._controls[control].remove();
/* 2812 */         }
/* 2813 */         for (override in this.overides) {
/* 2814 */             this._core[override] = this._overrides[override];
/* 2815 */         }
/* 2816 */         for (property in Object.getOwnPropertyNames(this)) {
/* 2817 */             typeof this[property] != 'function' && (this[property] = null);
/* 2818 */         }
/* 2819 */     }
/* 2820 */ 
/* 2821 */     /**
/* 2822 *|      * Updates the internal state.
/* 2823 *|      * @protected
/* 2824 *|      */
/* 2825 */     Navigation.prototype.update = function() {
/* 2826 */         var i, j, k,
/* 2827 */             options = this._core.settings,
/* 2828 */             lower = this._core.clones().length / 2,
/* 2829 */             upper = lower + this._core.items().length,
/* 2830 */             size = options.center || options.autoWidth || options.dotData
/* 2831 */                 ? 1 : options.dotsEach || options.items;
/* 2832 */ 
/* 2833 */         if (options.slideBy !== 'page') {
/* 2834 */             options.slideBy = Math.min(options.slideBy, options.items);
/* 2835 */         }
/* 2836 */ 
/* 2837 */         if (options.dots || options.slideBy == 'page') {
/* 2838 */             this._pages = [];
/* 2839 */ 
/* 2840 */             for (i = lower, j = 0, k = 0; i < upper; i++) {
/* 2841 */                 if (j >= size || j === 0) {
/* 2842 */                     this._pages.push({
/* 2843 */                         start: i - lower,
/* 2844 */                         end: i - lower + size - 1
/* 2845 */                     });
/* 2846 */                     j = 0, ++k;
/* 2847 */                 }
/* 2848 */                 j += this._core.mergers(this._core.relative(i));
/* 2849 */             }
/* 2850 */         }

/* owl.carousel.js */

/* 2851 */     }
/* 2852 */ 
/* 2853 */     /**
/* 2854 *|      * Draws the user interface.
/* 2855 *|      * @todo The option `dotData` wont work.
/* 2856 *|      * @protected
/* 2857 *|      */
/* 2858 */     Navigation.prototype.draw = function() {
/* 2859 */         var difference, i, html = '',
/* 2860 */             options = this._core.settings,
/* 2861 */             $items = this._core.$stage.children(),
/* 2862 */             index = this._core.relative(this._core.current());
/* 2863 */ 
/* 2864 */         if (options.nav && !options.loop && !options.navRewind) {
/* 2865 */             this._controls.$previous.toggleClass('disabled', index <= 0);
/* 2866 */             this._controls.$next.toggleClass('disabled', index >= this._core.maximum());
/* 2867 */         }
/* 2868 */ 
/* 2869 */         this._controls.$previous.toggle(options.nav);
/* 2870 */         this._controls.$next.toggle(options.nav);
/* 2871 */ 
/* 2872 */         if (options.dots) {
/* 2873 */             difference = this._pages.length - this._controls.$indicators.children().length;
/* 2874 */ 
/* 2875 */             if (options.dotData && difference !== 0) {
/* 2876 */                 for (i = 0; i < this._controls.$indicators.children().length; i++) {
/* 2877 */                     html += this._templates[this._core.relative(i)];
/* 2878 */                 }
/* 2879 */                 this._controls.$indicators.html(html);
/* 2880 */             } else if (difference > 0) {
/* 2881 */                 html = new Array(difference + 1).join(this._templates[0]);
/* 2882 */                 this._controls.$indicators.append(html);
/* 2883 */             } else if (difference < 0) {
/* 2884 */                 this._controls.$indicators.children().slice(difference).remove();
/* 2885 */             }
/* 2886 */ 
/* 2887 */             this._controls.$indicators.find('.active').removeClass('active');
/* 2888 */             this._controls.$indicators.children().eq($.inArray(this.current(), this._pages)).addClass('active');
/* 2889 */         }
/* 2890 */ 
/* 2891 */         this._controls.$indicators.toggle(options.dots);
/* 2892 */     }
/* 2893 */ 
/* 2894 */     /**
/* 2895 *|      * Extends event data.
/* 2896 *|      * @protected
/* 2897 *|      * @param {Event} event - The event object which gets thrown.
/* 2898 *|      */
/* 2899 */     Navigation.prototype.onTrigger = function(event) {
/* 2900 */         var settings = this._core.settings;

/* owl.carousel.js */

/* 2901 */ 
/* 2902 */         event.page = {
/* 2903 */             index: $.inArray(this.current(), this._pages),
/* 2904 */             count: this._pages.length,
/* 2905 */             size: settings && (settings.center || settings.autoWidth || settings.dotData
/* 2906 */                 ? 1 : settings.dotsEach || settings.items)
/* 2907 */         };
/* 2908 */     }
/* 2909 */ 
/* 2910 */     /**
/* 2911 *|      * Gets the current page position of the carousel2.
/* 2912 *|      * @protected
/* 2913 *|      * @returns {Number}
/* 2914 *|      */
/* 2915 */     Navigation.prototype.current = function() {
/* 2916 */         var index = this._core.relative(this._core.current());
/* 2917 */         return $.grep(this._pages, function(o) {
/* 2918 */             return o.start <= index && o.end >= index;
/* 2919 */         }).pop();
/* 2920 */     }
/* 2921 */ 
/* 2922 */     /**
/* 2923 *|      * Gets the current succesor/predecessor position.
/* 2924 *|      * @protected
/* 2925 *|      * @returns {Number}
/* 2926 *|      */
/* 2927 */     Navigation.prototype.getPosition = function(successor) {
/* 2928 */         var position, length,
/* 2929 */             options = this._core.settings;
/* 2930 */ 
/* 2931 */         if (options.slideBy == 'page') {
/* 2932 */             position = $.inArray(this.current(), this._pages);
/* 2933 */             length = this._pages.length;
/* 2934 */             successor ? ++position : --position;
/* 2935 */             position = this._pages[((position % length) + length) % length].start;
/* 2936 */         } else {
/* 2937 */             position = this._core.relative(this._core.current());
/* 2938 */             length = this._core.items().length;
/* 2939 */             successor ? position += options.slideBy : position -= options.slideBy;
/* 2940 */         }
/* 2941 */         return position;
/* 2942 */     }
/* 2943 */ 
/* 2944 */     /**
/* 2945 *|      * Slides to the next item or page.
/* 2946 *|      * @public
/* 2947 *|      * @param {Number} [speed=false] - The time in milliseconds for the transition.
/* 2948 *|      */
/* 2949 */     Navigation.prototype.next = function(speed) {
/* 2950 */         $.proxy(this._overrides.to, this._core)(this.getPosition(true), speed);

/* owl.carousel.js */

/* 2951 */     }
/* 2952 */ 
/* 2953 */     /**
/* 2954 *|      * Slides to the previous item or page.
/* 2955 *|      * @public
/* 2956 *|      * @param {Number} [speed=false] - The time in milliseconds for the transition.
/* 2957 *|      */
/* 2958 */     Navigation.prototype.prev = function(speed) {
/* 2959 */         $.proxy(this._overrides.to, this._core)(this.getPosition(false), speed);
/* 2960 */     }
/* 2961 */ 
/* 2962 */     /**
/* 2963 *|      * Slides to the specified item or page.
/* 2964 *|      * @public
/* 2965 *|      * @param {Number} position - The position of the item or page.
/* 2966 *|      * @param {Number} [speed] - The time in milliseconds for the transition.
/* 2967 *|      * @param {Boolean} [standard=false] - Whether to use the standard behaviour or not.
/* 2968 *|      */
/* 2969 */     Navigation.prototype.to = function(position, speed, standard) {
/* 2970 */         var length;
/* 2971 */ 
/* 2972 */         if (!standard) {
/* 2973 */             length = this._pages.length;
/* 2974 */             $.proxy(this._overrides.to, this._core)(this._pages[((position % length) + length) % length].start, speed);
/* 2975 */         } else {
/* 2976 */             $.proxy(this._overrides.to, this._core)(position, speed);
/* 2977 */         }
/* 2978 */     }
/* 2979 */ 
/* 2980 */     $.fn.owlCarousel2.Constructor.Plugins.Navigation = Navigation;
/* 2981 */ 
/* 2982 */ })(window.Zepto || window.jQuery, window, document);
/* 2983 */ 
/* 2984 */ /**
/* 2985 *|  * Hash Plugin
/* 2986 *|  * @version 2.0.0
/* 2987 *|  * @author Artus Kolanowski
/* 2988 *|  * @license The MIT License (MIT)
/* 2989 *|  */
/* 2990 */ ;(function($, window, document, undefined) {
/* 2991 */     'use strict';
/* 2992 */ 
/* 2993 */     /**
/* 2994 *|      * Creates the hash plugin.
/* 2995 *|      * @class The Hash Plugin
/* 2996 *|      * @param {Owl2} carousel2 - The Owl2 Carousel
/* 2997 *|      */
/* 2998 */     var Hash = function(carousel2) {
/* 2999 */         /**
/* 3000 *|          * Reference to the core.

/* owl.carousel.js */

/* 3001 *|          * @protected
/* 3002 *|          * @type {Owl2}
/* 3003 *|          */
/* 3004 */         this._core = carousel2;
/* 3005 */ 
/* 3006 */         /**
/* 3007 *|          * Hash table for the hashes.
/* 3008 *|          * @protected
/* 3009 *|          * @type {Object}
/* 3010 *|          */
/* 3011 */         this._hashes = {};
/* 3012 */ 
/* 3013 */         /**
/* 3014 *|          * The carousel2 element.
/* 3015 *|          * @type {jQuery}
/* 3016 *|          */
/* 3017 */         this.$element = this._core.$element;
/* 3018 */ 
/* 3019 */         /**
/* 3020 *|          * All event handlers.
/* 3021 *|          * @protected
/* 3022 *|          * @type {Object}
/* 3023 *|          */
/* 3024 */         this._handlers = {
/* 3025 */             'initialized.owl.carousel2': $.proxy(function() {
/* 3026 */                 if (this._core.settings.startPosition == 'URLHash') {
/* 3027 */                     $(window).trigger('hashchange.owl.navigation');
/* 3028 */                 }
/* 3029 */             }, this),
/* 3030 */             'prepared.owl.carousel2': $.proxy(function(e) {
/* 3031 */                 var hash = $(e.content).find('[data-hash]').andSelf('[data-hash]').attr('data-hash');
/* 3032 */                 this._hashes[hash] = e.content;
/* 3033 */             }, this)
/* 3034 */         };
/* 3035 */ 
/* 3036 */         // set default options
/* 3037 */         this._core.options = $.extend({}, Hash.Defaults, this._core.options);
/* 3038 */ 
/* 3039 */         // register the event handlers
/* 3040 */         this.$element.on(this._handlers);
/* 3041 */ 
/* 3042 */         // register event listener for hash navigation
/* 3043 */         $(window).on('hashchange.owl.navigation', $.proxy(function() {
/* 3044 */             var hash = window.location.hash.substring(1),
/* 3045 */                 items = this._core.$stage.children(),
/* 3046 */                 position = this._hashes[hash] && items.index(this._hashes[hash]) || 0;
/* 3047 */ 
/* 3048 */             if (!hash) {
/* 3049 */                 return false;
/* 3050 */             }

/* owl.carousel.js */

/* 3051 */ 
/* 3052 */             this._core.to(position, false, true);
/* 3053 */         }, this));
/* 3054 */     }
/* 3055 */ 
/* 3056 */     /**
/* 3057 *|      * Default options.
/* 3058 *|      * @public
/* 3059 *|      */
/* 3060 */     Hash.Defaults = {
/* 3061 */         URLhashListener: false
/* 3062 */     }
/* 3063 */ 
/* 3064 */     /**
/* 3065 *|      * Destroys the plugin.
/* 3066 *|      * @public
/* 3067 *|      */
/* 3068 */     Hash.prototype.destroy = function() {
/* 3069 */         var handler, property;
/* 3070 */ 
/* 3071 */         $(window).off('hashchange.owl.navigation');
/* 3072 */ 
/* 3073 */         for (handler in this._handlers) {
/* 3074 */             this._core.$element.off(handler, this._handlers[handler]);
/* 3075 */         }
/* 3076 */         for (property in Object.getOwnPropertyNames(this)) {
/* 3077 */             typeof this[property] != 'function' && (this[property] = null);
/* 3078 */         }
/* 3079 */     }
/* 3080 */ 
/* 3081 */     $.fn.owlCarousel2.Constructor.Plugins.Hash = Hash;
/* 3082 */ 
/* 3083 */ })(window.Zepto || window.jQuery, window, document);

;
/* moment.js */

/* 1    */ //! moment.js
/* 2    */ //! version : 2.8.3
/* 3    */ //! authors : Tim Wood, Iskren Chernev, Moment.js contributors
/* 4    */ //! license : MIT
/* 5    */ //! momentjs.com
/* 6    */ 
/* 7    */ (function (undefined) {
/* 8    */     /************************************
/* 9    *|         Constants
/* 10   *|     ************************************/
/* 11   */ 
/* 12   */     var moment,
/* 13   */         VERSION = '2.8.3',
/* 14   */         // the global-scope this is NOT the global object in Node.js
/* 15   */         globalScope = typeof global !== 'undefined' ? global : this,
/* 16   */         oldGlobalMoment,
/* 17   */         round = Math.round,
/* 18   */         hasOwnProperty = Object.prototype.hasOwnProperty,
/* 19   */         i,
/* 20   */ 
/* 21   */         YEAR = 0,
/* 22   */         MONTH = 1,
/* 23   */         DATE = 2,
/* 24   */         HOUR = 3,
/* 25   */         MINUTE = 4,
/* 26   */         SECOND = 5,
/* 27   */         MILLISECOND = 6,
/* 28   */ 
/* 29   */         // internal storage for locale config files
/* 30   */         locales = {},
/* 31   */ 
/* 32   */         // extra moment internal properties (plugins register props here)
/* 33   */         momentProperties = [],
/* 34   */ 
/* 35   */         // check for nodeJS
/* 36   */         hasModule = (typeof module !== 'undefined' && module.exports),
/* 37   */ 
/* 38   */         // ASP.NET json date format regex
/* 39   */         aspNetJsonRegex = /^\/?Date\((\-?\d+)/i,
/* 40   */         aspNetTimeSpanJsonRegex = /(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/,
/* 41   */ 
/* 42   */         // from http://docs.closure-library.googlecode.com/git/closure_goog_date_date.js.source.html
/* 43   */         // somewhat more in line with 4.4.3.2 2004 spec, but allows decimal anywhere
/* 44   */         isoDurationRegex = /^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/,
/* 45   */ 
/* 46   */         // format tokens
/* 47   */         formattingTokens = /(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Q|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|S{1,4}|X|zz?|ZZ?|.)/g,
/* 48   */         localFormattingTokens = /(\[[^\[]*\])|(\\)?(LT|LL?L?L?|l{1,4})/g,
/* 49   */ 
/* 50   */         // parsing token regexes

/* moment.js */

/* 51   */         parseTokenOneOrTwoDigits = /\d\d?/, // 0 - 99
/* 52   */         parseTokenOneToThreeDigits = /\d{1,3}/, // 0 - 999
/* 53   */         parseTokenOneToFourDigits = /\d{1,4}/, // 0 - 9999
/* 54   */         parseTokenOneToSixDigits = /[+\-]?\d{1,6}/, // -999,999 - 999,999
/* 55   */         parseTokenDigits = /\d+/, // nonzero number of digits
/* 56   */         parseTokenWord = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i, // any word (or two) characters or numbers including two/three word month in arabic.
/* 57   */         parseTokenTimezone = /Z|[\+\-]\d\d:?\d\d/gi, // +00:00 -00:00 +0000 -0000 or Z
/* 58   */         parseTokenT = /T/i, // T (ISO separator)
/* 59   */         parseTokenTimestampMs = /[\+\-]?\d+(\.\d{1,3})?/, // 123456789 123456789.123
/* 60   */         parseTokenOrdinal = /\d{1,2}/,
/* 61   */ 
/* 62   */         //strict parsing regexes
/* 63   */         parseTokenOneDigit = /\d/, // 0 - 9
/* 64   */         parseTokenTwoDigits = /\d\d/, // 00 - 99
/* 65   */         parseTokenThreeDigits = /\d{3}/, // 000 - 999
/* 66   */         parseTokenFourDigits = /\d{4}/, // 0000 - 9999
/* 67   */         parseTokenSixDigits = /[+-]?\d{6}/, // -999,999 - 999,999
/* 68   */         parseTokenSignedNumber = /[+-]?\d+/, // -inf - inf
/* 69   */ 
/* 70   */         // iso 8601 regex
/* 71   */         // 0000-00-00 0000-W00 or 0000-W00-0 + T + 00 or 00:00 or 00:00:00 or 00:00:00.000 + +00:00 or +0000 or +00)
/* 72   */         isoRegex = /^\s*(?:[+-]\d{6}|\d{4})-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d+)?)?)?)?([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/,
/* 73   */ 
/* 74   */         isoFormat = 'YYYY-MM-DDTHH:mm:ssZ',
/* 75   */ 
/* 76   */         isoDates = [
/* 77   */             ['YYYYYY-MM-DD', /[+-]\d{6}-\d{2}-\d{2}/],
/* 78   */             ['YYYY-MM-DD', /\d{4}-\d{2}-\d{2}/],
/* 79   */             ['GGGG-[W]WW-E', /\d{4}-W\d{2}-\d/],
/* 80   */             ['GGGG-[W]WW', /\d{4}-W\d{2}/],
/* 81   */             ['YYYY-DDD', /\d{4}-\d{3}/]
/* 82   */         ],
/* 83   */ 
/* 84   */         // iso time formats and regexes
/* 85   */         isoTimes = [
/* 86   */             ['HH:mm:ss.SSSS', /(T| )\d\d:\d\d:\d\d\.\d+/],
/* 87   */             ['HH:mm:ss', /(T| )\d\d:\d\d:\d\d/],
/* 88   */             ['HH:mm', /(T| )\d\d:\d\d/],
/* 89   */             ['HH', /(T| )\d\d/]
/* 90   */         ],
/* 91   */ 
/* 92   */         // timezone chunker '+10:00' > ['10', '00'] or '-1530' > ['-15', '30']
/* 93   */         parseTimezoneChunker = /([\+\-]|\d\d)/gi,
/* 94   */ 
/* 95   */         // getter and setter names
/* 96   */         proxyGettersAndSetters = 'Date|Hours|Minutes|Seconds|Milliseconds'.split('|'),
/* 97   */         unitMillisecondFactors = {
/* 98   */             'Milliseconds' : 1,
/* 99   */             'Seconds' : 1e3,
/* 100  */             'Minutes' : 6e4,

/* moment.js */

/* 101  */             'Hours' : 36e5,
/* 102  */             'Days' : 864e5,
/* 103  */             'Months' : 2592e6,
/* 104  */             'Years' : 31536e6
/* 105  */         },
/* 106  */ 
/* 107  */         unitAliases = {
/* 108  */             ms : 'millisecond',
/* 109  */             s : 'second',
/* 110  */             m : 'minute',
/* 111  */             h : 'hour',
/* 112  */             d : 'day',
/* 113  */             D : 'date',
/* 114  */             w : 'week',
/* 115  */             W : 'isoWeek',
/* 116  */             M : 'month',
/* 117  */             Q : 'quarter',
/* 118  */             y : 'year',
/* 119  */             DDD : 'dayOfYear',
/* 120  */             e : 'weekday',
/* 121  */             E : 'isoWeekday',
/* 122  */             gg: 'weekYear',
/* 123  */             GG: 'isoWeekYear'
/* 124  */         },
/* 125  */ 
/* 126  */         camelFunctions = {
/* 127  */             dayofyear : 'dayOfYear',
/* 128  */             isoweekday : 'isoWeekday',
/* 129  */             isoweek : 'isoWeek',
/* 130  */             weekyear : 'weekYear',
/* 131  */             isoweekyear : 'isoWeekYear'
/* 132  */         },
/* 133  */ 
/* 134  */         // format function strings
/* 135  */         formatFunctions = {},
/* 136  */ 
/* 137  */         // default relative time thresholds
/* 138  */         relativeTimeThresholds = {
/* 139  */             s: 45,  // seconds to minute
/* 140  */             m: 45,  // minutes to hour
/* 141  */             h: 22,  // hours to day
/* 142  */             d: 26,  // days to month
/* 143  */             M: 11   // months to year
/* 144  */         },
/* 145  */ 
/* 146  */         // tokens to ordinalize and pad
/* 147  */         ordinalizeTokens = 'DDD w W M D d'.split(' '),
/* 148  */         paddedTokens = 'M D H h m s w W'.split(' '),
/* 149  */ 
/* 150  */         formatTokenFunctions = {

/* moment.js */

/* 151  */             M    : function () {
/* 152  */                 return this.month() + 1;
/* 153  */             },
/* 154  */             MMM  : function (format) {
/* 155  */                 return this.localeData().monthsShort(this, format);
/* 156  */             },
/* 157  */             MMMM : function (format) {
/* 158  */                 return this.localeData().months(this, format);
/* 159  */             },
/* 160  */             D    : function () {
/* 161  */                 return this.date();
/* 162  */             },
/* 163  */             DDD  : function () {
/* 164  */                 return this.dayOfYear();
/* 165  */             },
/* 166  */             d    : function () {
/* 167  */                 return this.day();
/* 168  */             },
/* 169  */             dd   : function (format) {
/* 170  */                 return this.localeData().weekdaysMin(this, format);
/* 171  */             },
/* 172  */             ddd  : function (format) {
/* 173  */                 return this.localeData().weekdaysShort(this, format);
/* 174  */             },
/* 175  */             dddd : function (format) {
/* 176  */                 return this.localeData().weekdays(this, format);
/* 177  */             },
/* 178  */             w    : function () {
/* 179  */                 return this.week();
/* 180  */             },
/* 181  */             W    : function () {
/* 182  */                 return this.isoWeek();
/* 183  */             },
/* 184  */             YY   : function () {
/* 185  */                 return leftZeroFill(this.year() % 100, 2);
/* 186  */             },
/* 187  */             YYYY : function () {
/* 188  */                 return leftZeroFill(this.year(), 4);
/* 189  */             },
/* 190  */             YYYYY : function () {
/* 191  */                 return leftZeroFill(this.year(), 5);
/* 192  */             },
/* 193  */             YYYYYY : function () {
/* 194  */                 var y = this.year(), sign = y >= 0 ? '+' : '-';
/* 195  */                 return sign + leftZeroFill(Math.abs(y), 6);
/* 196  */             },
/* 197  */             gg   : function () {
/* 198  */                 return leftZeroFill(this.weekYear() % 100, 2);
/* 199  */             },
/* 200  */             gggg : function () {

/* moment.js */

/* 201  */                 return leftZeroFill(this.weekYear(), 4);
/* 202  */             },
/* 203  */             ggggg : function () {
/* 204  */                 return leftZeroFill(this.weekYear(), 5);
/* 205  */             },
/* 206  */             GG   : function () {
/* 207  */                 return leftZeroFill(this.isoWeekYear() % 100, 2);
/* 208  */             },
/* 209  */             GGGG : function () {
/* 210  */                 return leftZeroFill(this.isoWeekYear(), 4);
/* 211  */             },
/* 212  */             GGGGG : function () {
/* 213  */                 return leftZeroFill(this.isoWeekYear(), 5);
/* 214  */             },
/* 215  */             e : function () {
/* 216  */                 return this.weekday();
/* 217  */             },
/* 218  */             E : function () {
/* 219  */                 return this.isoWeekday();
/* 220  */             },
/* 221  */             a    : function () {
/* 222  */                 return this.localeData().meridiem(this.hours(), this.minutes(), true);
/* 223  */             },
/* 224  */             A    : function () {
/* 225  */                 return this.localeData().meridiem(this.hours(), this.minutes(), false);
/* 226  */             },
/* 227  */             H    : function () {
/* 228  */                 return this.hours();
/* 229  */             },
/* 230  */             h    : function () {
/* 231  */                 return this.hours() % 12 || 12;
/* 232  */             },
/* 233  */             m    : function () {
/* 234  */                 return this.minutes();
/* 235  */             },
/* 236  */             s    : function () {
/* 237  */                 return this.seconds();
/* 238  */             },
/* 239  */             S    : function () {
/* 240  */                 return toInt(this.milliseconds() / 100);
/* 241  */             },
/* 242  */             SS   : function () {
/* 243  */                 return leftZeroFill(toInt(this.milliseconds() / 10), 2);
/* 244  */             },
/* 245  */             SSS  : function () {
/* 246  */                 return leftZeroFill(this.milliseconds(), 3);
/* 247  */             },
/* 248  */             SSSS : function () {
/* 249  */                 return leftZeroFill(this.milliseconds(), 3);
/* 250  */             },

/* moment.js */

/* 251  */             Z    : function () {
/* 252  */                 var a = -this.zone(),
/* 253  */                     b = '+';
/* 254  */                 if (a < 0) {
/* 255  */                     a = -a;
/* 256  */                     b = '-';
/* 257  */                 }
/* 258  */                 return b + leftZeroFill(toInt(a / 60), 2) + ':' + leftZeroFill(toInt(a) % 60, 2);
/* 259  */             },
/* 260  */             ZZ   : function () {
/* 261  */                 var a = -this.zone(),
/* 262  */                     b = '+';
/* 263  */                 if (a < 0) {
/* 264  */                     a = -a;
/* 265  */                     b = '-';
/* 266  */                 }
/* 267  */                 return b + leftZeroFill(toInt(a / 60), 2) + leftZeroFill(toInt(a) % 60, 2);
/* 268  */             },
/* 269  */             z : function () {
/* 270  */                 return this.zoneAbbr();
/* 271  */             },
/* 272  */             zz : function () {
/* 273  */                 return this.zoneName();
/* 274  */             },
/* 275  */             X    : function () {
/* 276  */                 return this.unix();
/* 277  */             },
/* 278  */             Q : function () {
/* 279  */                 return this.quarter();
/* 280  */             }
/* 281  */         },
/* 282  */ 
/* 283  */         deprecations = {},
/* 284  */ 
/* 285  */         lists = ['months', 'monthsShort', 'weekdays', 'weekdaysShort', 'weekdaysMin'];
/* 286  */ 
/* 287  */     // Pick the first defined of two or three arguments. dfl comes from
/* 288  */     // default.
/* 289  */     function dfl(a, b, c) {
/* 290  */         switch (arguments.length) {
/* 291  */             case 2: return a != null ? a : b;
/* 292  */             case 3: return a != null ? a : b != null ? b : c;
/* 293  */             default: throw new Error('Implement me');
/* 294  */         }
/* 295  */     }
/* 296  */ 
/* 297  */     function hasOwnProp(a, b) {
/* 298  */         return hasOwnProperty.call(a, b);
/* 299  */     }
/* 300  */ 

/* moment.js */

/* 301  */     function defaultParsingFlags() {
/* 302  */         // We need to deep clone this object, and es5 standard is not very
/* 303  */         // helpful.
/* 304  */         return {
/* 305  */             empty : false,
/* 306  */             unusedTokens : [],
/* 307  */             unusedInput : [],
/* 308  */             overflow : -2,
/* 309  */             charsLeftOver : 0,
/* 310  */             nullInput : false,
/* 311  */             invalidMonth : null,
/* 312  */             invalidFormat : false,
/* 313  */             userInvalidated : false,
/* 314  */             iso: false
/* 315  */         };
/* 316  */     }
/* 317  */ 
/* 318  */     function printMsg(msg) {
/* 319  */         if (moment.suppressDeprecationWarnings === false &&
/* 320  */                 typeof console !== 'undefined' && console.warn) {
/* 321  */             console.warn('Deprecation warning: ' + msg);
/* 322  */         }
/* 323  */     }
/* 324  */ 
/* 325  */     function deprecate(msg, fn) {
/* 326  */         var firstTime = true;
/* 327  */         return extend(function () {
/* 328  */             if (firstTime) {
/* 329  */                 printMsg(msg);
/* 330  */                 firstTime = false;
/* 331  */             }
/* 332  */             return fn.apply(this, arguments);
/* 333  */         }, fn);
/* 334  */     }
/* 335  */ 
/* 336  */     function deprecateSimple(name, msg) {
/* 337  */         if (!deprecations[name]) {
/* 338  */             printMsg(msg);
/* 339  */             deprecations[name] = true;
/* 340  */         }
/* 341  */     }
/* 342  */ 
/* 343  */     function padToken(func, count) {
/* 344  */         return function (a) {
/* 345  */             return leftZeroFill(func.call(this, a), count);
/* 346  */         };
/* 347  */     }
/* 348  */     function ordinalizeToken(func, period) {
/* 349  */         return function (a) {
/* 350  */             return this.localeData().ordinal(func.call(this, a), period);

/* moment.js */

/* 351  */         };
/* 352  */     }
/* 353  */ 
/* 354  */     while (ordinalizeTokens.length) {
/* 355  */         i = ordinalizeTokens.pop();
/* 356  */         formatTokenFunctions[i + 'o'] = ordinalizeToken(formatTokenFunctions[i], i);
/* 357  */     }
/* 358  */     while (paddedTokens.length) {
/* 359  */         i = paddedTokens.pop();
/* 360  */         formatTokenFunctions[i + i] = padToken(formatTokenFunctions[i], 2);
/* 361  */     }
/* 362  */     formatTokenFunctions.DDDD = padToken(formatTokenFunctions.DDD, 3);
/* 363  */ 
/* 364  */ 
/* 365  */     /************************************
/* 366  *|         Constructors
/* 367  *|     ************************************/
/* 368  */ 
/* 369  */     function Locale() {
/* 370  */     }
/* 371  */ 
/* 372  */     // Moment prototype object
/* 373  */     function Moment(config, skipOverflow) {
/* 374  */         if (skipOverflow !== false) {
/* 375  */             checkOverflow(config);
/* 376  */         }
/* 377  */         copyConfig(this, config);
/* 378  */         this._d = new Date(+config._d);
/* 379  */     }
/* 380  */ 
/* 381  */     // Duration Constructor
/* 382  */     function Duration(duration) {
/* 383  */         var normalizedInput = normalizeObjectUnits(duration),
/* 384  */             years = normalizedInput.year || 0,
/* 385  */             quarters = normalizedInput.quarter || 0,
/* 386  */             months = normalizedInput.month || 0,
/* 387  */             weeks = normalizedInput.week || 0,
/* 388  */             days = normalizedInput.day || 0,
/* 389  */             hours = normalizedInput.hour || 0,
/* 390  */             minutes = normalizedInput.minute || 0,
/* 391  */             seconds = normalizedInput.second || 0,
/* 392  */             milliseconds = normalizedInput.millisecond || 0;
/* 393  */ 
/* 394  */         // representation for dateAddRemove
/* 395  */         this._milliseconds = +milliseconds +
/* 396  */             seconds * 1e3 + // 1000
/* 397  */             minutes * 6e4 + // 1000 * 60
/* 398  */             hours * 36e5; // 1000 * 60 * 60
/* 399  */         // Because of dateAddRemove treats 24 hours as different from a
/* 400  */         // day when working around DST, we need to store them separately

/* moment.js */

/* 401  */         this._days = +days +
/* 402  */             weeks * 7;
/* 403  */         // It is impossible translate months into days without knowing
/* 404  */         // which months you are are talking about, so we have to store
/* 405  */         // it separately.
/* 406  */         this._months = +months +
/* 407  */             quarters * 3 +
/* 408  */             years * 12;
/* 409  */ 
/* 410  */         this._data = {};
/* 411  */ 
/* 412  */         this._locale = moment.localeData();
/* 413  */ 
/* 414  */         this._bubble();
/* 415  */     }
/* 416  */ 
/* 417  */     /************************************
/* 418  *|         Helpers
/* 419  *|     ************************************/
/* 420  */ 
/* 421  */ 
/* 422  */     function extend(a, b) {
/* 423  */         for (var i in b) {
/* 424  */             if (hasOwnProp(b, i)) {
/* 425  */                 a[i] = b[i];
/* 426  */             }
/* 427  */         }
/* 428  */ 
/* 429  */         if (hasOwnProp(b, 'toString')) {
/* 430  */             a.toString = b.toString;
/* 431  */         }
/* 432  */ 
/* 433  */         if (hasOwnProp(b, 'valueOf')) {
/* 434  */             a.valueOf = b.valueOf;
/* 435  */         }
/* 436  */ 
/* 437  */         return a;
/* 438  */     }
/* 439  */ 
/* 440  */     function copyConfig(to, from) {
/* 441  */         var i, prop, val;
/* 442  */ 
/* 443  */         if (typeof from._isAMomentObject !== 'undefined') {
/* 444  */             to._isAMomentObject = from._isAMomentObject;
/* 445  */         }
/* 446  */         if (typeof from._i !== 'undefined') {
/* 447  */             to._i = from._i;
/* 448  */         }
/* 449  */         if (typeof from._f !== 'undefined') {
/* 450  */             to._f = from._f;

/* moment.js */

/* 451  */         }
/* 452  */         if (typeof from._l !== 'undefined') {
/* 453  */             to._l = from._l;
/* 454  */         }
/* 455  */         if (typeof from._strict !== 'undefined') {
/* 456  */             to._strict = from._strict;
/* 457  */         }
/* 458  */         if (typeof from._tzm !== 'undefined') {
/* 459  */             to._tzm = from._tzm;
/* 460  */         }
/* 461  */         if (typeof from._isUTC !== 'undefined') {
/* 462  */             to._isUTC = from._isUTC;
/* 463  */         }
/* 464  */         if (typeof from._offset !== 'undefined') {
/* 465  */             to._offset = from._offset;
/* 466  */         }
/* 467  */         if (typeof from._pf !== 'undefined') {
/* 468  */             to._pf = from._pf;
/* 469  */         }
/* 470  */         if (typeof from._locale !== 'undefined') {
/* 471  */             to._locale = from._locale;
/* 472  */         }
/* 473  */ 
/* 474  */         if (momentProperties.length > 0) {
/* 475  */             for (i in momentProperties) {
/* 476  */                 prop = momentProperties[i];
/* 477  */                 val = from[prop];
/* 478  */                 if (typeof val !== 'undefined') {
/* 479  */                     to[prop] = val;
/* 480  */                 }
/* 481  */             }
/* 482  */         }
/* 483  */ 
/* 484  */         return to;
/* 485  */     }
/* 486  */ 
/* 487  */     function absRound(number) {
/* 488  */         if (number < 0) {
/* 489  */             return Math.ceil(number);
/* 490  */         } else {
/* 491  */             return Math.floor(number);
/* 492  */         }
/* 493  */     }
/* 494  */ 
/* 495  */     // left zero fill a number
/* 496  */     // see http://jsperf.com/left-zero-filling for performance comparison
/* 497  */     function leftZeroFill(number, targetLength, forceSign) {
/* 498  */         var output = '' + Math.abs(number),
/* 499  */             sign = number >= 0;
/* 500  */ 

/* moment.js */

/* 501  */         while (output.length < targetLength) {
/* 502  */             output = '0' + output;
/* 503  */         }
/* 504  */         return (sign ? (forceSign ? '+' : '') : '-') + output;
/* 505  */     }
/* 506  */ 
/* 507  */     function positiveMomentsDifference(base, other) {
/* 508  */         var res = {milliseconds: 0, months: 0};
/* 509  */ 
/* 510  */         res.months = other.month() - base.month() +
/* 511  */             (other.year() - base.year()) * 12;
/* 512  */         if (base.clone().add(res.months, 'M').isAfter(other)) {
/* 513  */             --res.months;
/* 514  */         }
/* 515  */ 
/* 516  */         res.milliseconds = +other - +(base.clone().add(res.months, 'M'));
/* 517  */ 
/* 518  */         return res;
/* 519  */     }
/* 520  */ 
/* 521  */     function momentsDifference(base, other) {
/* 522  */         var res;
/* 523  */         other = makeAs(other, base);
/* 524  */         if (base.isBefore(other)) {
/* 525  */             res = positiveMomentsDifference(base, other);
/* 526  */         } else {
/* 527  */             res = positiveMomentsDifference(other, base);
/* 528  */             res.milliseconds = -res.milliseconds;
/* 529  */             res.months = -res.months;
/* 530  */         }
/* 531  */ 
/* 532  */         return res;
/* 533  */     }
/* 534  */ 
/* 535  */     // TODO: remove 'name' arg after deprecation is removed
/* 536  */     function createAdder(direction, name) {
/* 537  */         return function (val, period) {
/* 538  */             var dur, tmp;
/* 539  */             //invert the arguments, but complain about it
/* 540  */             if (period !== null && !isNaN(+period)) {
/* 541  */                 deprecateSimple(name, 'moment().' + name  + '(period, number) is deprecated. Please use moment().' + name + '(number, period).');
/* 542  */                 tmp = val; val = period; period = tmp;
/* 543  */             }
/* 544  */ 
/* 545  */             val = typeof val === 'string' ? +val : val;
/* 546  */             dur = moment.duration(val, period);
/* 547  */             addOrSubtractDurationFromMoment(this, dur, direction);
/* 548  */             return this;
/* 549  */         };
/* 550  */     }

/* moment.js */

/* 551  */ 
/* 552  */     function addOrSubtractDurationFromMoment(mom, duration, isAdding, updateOffset) {
/* 553  */         var milliseconds = duration._milliseconds,
/* 554  */             days = duration._days,
/* 555  */             months = duration._months;
/* 556  */         updateOffset = updateOffset == null ? true : updateOffset;
/* 557  */ 
/* 558  */         if (milliseconds) {
/* 559  */             mom._d.setTime(+mom._d + milliseconds * isAdding);
/* 560  */         }
/* 561  */         if (days) {
/* 562  */             rawSetter(mom, 'Date', rawGetter(mom, 'Date') + days * isAdding);
/* 563  */         }
/* 564  */         if (months) {
/* 565  */             rawMonthSetter(mom, rawGetter(mom, 'Month') + months * isAdding);
/* 566  */         }
/* 567  */         if (updateOffset) {
/* 568  */             moment.updateOffset(mom, days || months);
/* 569  */         }
/* 570  */     }
/* 571  */ 
/* 572  */     // check if is an array
/* 573  */     function isArray(input) {
/* 574  */         return Object.prototype.toString.call(input) === '[object Array]';
/* 575  */     }
/* 576  */ 
/* 577  */     function isDate(input) {
/* 578  */         return Object.prototype.toString.call(input) === '[object Date]' ||
/* 579  */             input instanceof Date;
/* 580  */     }
/* 581  */ 
/* 582  */     // compare two arrays, return the number of differences
/* 583  */     function compareArrays(array1, array2, dontConvert) {
/* 584  */         var len = Math.min(array1.length, array2.length),
/* 585  */             lengthDiff = Math.abs(array1.length - array2.length),
/* 586  */             diffs = 0,
/* 587  */             i;
/* 588  */         for (i = 0; i < len; i++) {
/* 589  */             if ((dontConvert && array1[i] !== array2[i]) ||
/* 590  */                 (!dontConvert && toInt(array1[i]) !== toInt(array2[i]))) {
/* 591  */                 diffs++;
/* 592  */             }
/* 593  */         }
/* 594  */         return diffs + lengthDiff;
/* 595  */     }
/* 596  */ 
/* 597  */     function normalizeUnits(units) {
/* 598  */         if (units) {
/* 599  */             var lowered = units.toLowerCase().replace(/(.)s$/, '$1');
/* 600  */             units = unitAliases[units] || camelFunctions[lowered] || lowered;

/* moment.js */

/* 601  */         }
/* 602  */         return units;
/* 603  */     }
/* 604  */ 
/* 605  */     function normalizeObjectUnits(inputObject) {
/* 606  */         var normalizedInput = {},
/* 607  */             normalizedProp,
/* 608  */             prop;
/* 609  */ 
/* 610  */         for (prop in inputObject) {
/* 611  */             if (hasOwnProp(inputObject, prop)) {
/* 612  */                 normalizedProp = normalizeUnits(prop);
/* 613  */                 if (normalizedProp) {
/* 614  */                     normalizedInput[normalizedProp] = inputObject[prop];
/* 615  */                 }
/* 616  */             }
/* 617  */         }
/* 618  */ 
/* 619  */         return normalizedInput;
/* 620  */     }
/* 621  */ 
/* 622  */     function makeList(field) {
/* 623  */         var count, setter;
/* 624  */ 
/* 625  */         if (field.indexOf('week') === 0) {
/* 626  */             count = 7;
/* 627  */             setter = 'day';
/* 628  */         }
/* 629  */         else if (field.indexOf('month') === 0) {
/* 630  */             count = 12;
/* 631  */             setter = 'month';
/* 632  */         }
/* 633  */         else {
/* 634  */             return;
/* 635  */         }
/* 636  */ 
/* 637  */         moment[field] = function (format, index) {
/* 638  */             var i, getter,
/* 639  */                 method = moment._locale[field],
/* 640  */                 results = [];
/* 641  */ 
/* 642  */             if (typeof format === 'number') {
/* 643  */                 index = format;
/* 644  */                 format = undefined;
/* 645  */             }
/* 646  */ 
/* 647  */             getter = function (i) {
/* 648  */                 var m = moment().utc().set(setter, i);
/* 649  */                 return method.call(moment._locale, m, format || '');
/* 650  */             };

/* moment.js */

/* 651  */ 
/* 652  */             if (index != null) {
/* 653  */                 return getter(index);
/* 654  */             }
/* 655  */             else {
/* 656  */                 for (i = 0; i < count; i++) {
/* 657  */                     results.push(getter(i));
/* 658  */                 }
/* 659  */                 return results;
/* 660  */             }
/* 661  */         };
/* 662  */     }
/* 663  */ 
/* 664  */     function toInt(argumentForCoercion) {
/* 665  */         var coercedNumber = +argumentForCoercion,
/* 666  */             value = 0;
/* 667  */ 
/* 668  */         if (coercedNumber !== 0 && isFinite(coercedNumber)) {
/* 669  */             if (coercedNumber >= 0) {
/* 670  */                 value = Math.floor(coercedNumber);
/* 671  */             } else {
/* 672  */                 value = Math.ceil(coercedNumber);
/* 673  */             }
/* 674  */         }
/* 675  */ 
/* 676  */         return value;
/* 677  */     }
/* 678  */ 
/* 679  */     function daysInMonth(year, month) {
/* 680  */         return new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
/* 681  */     }
/* 682  */ 
/* 683  */     function weeksInYear(year, dow, doy) {
/* 684  */         return weekOfYear(moment([year, 11, 31 + dow - doy]), dow, doy).week;
/* 685  */     }
/* 686  */ 
/* 687  */     function daysInYear(year) {
/* 688  */         return isLeapYear(year) ? 366 : 365;
/* 689  */     }
/* 690  */ 
/* 691  */     function isLeapYear(year) {
/* 692  */         return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
/* 693  */     }
/* 694  */ 
/* 695  */     function checkOverflow(m) {
/* 696  */         var overflow;
/* 697  */         if (m._a && m._pf.overflow === -2) {
/* 698  */             overflow =
/* 699  */                 m._a[MONTH] < 0 || m._a[MONTH] > 11 ? MONTH :
/* 700  */                 m._a[DATE] < 1 || m._a[DATE] > daysInMonth(m._a[YEAR], m._a[MONTH]) ? DATE :

/* moment.js */

/* 701  */                 m._a[HOUR] < 0 || m._a[HOUR] > 23 ? HOUR :
/* 702  */                 m._a[MINUTE] < 0 || m._a[MINUTE] > 59 ? MINUTE :
/* 703  */                 m._a[SECOND] < 0 || m._a[SECOND] > 59 ? SECOND :
/* 704  */                 m._a[MILLISECOND] < 0 || m._a[MILLISECOND] > 999 ? MILLISECOND :
/* 705  */                 -1;
/* 706  */ 
/* 707  */             if (m._pf._overflowDayOfYear && (overflow < YEAR || overflow > DATE)) {
/* 708  */                 overflow = DATE;
/* 709  */             }
/* 710  */ 
/* 711  */             m._pf.overflow = overflow;
/* 712  */         }
/* 713  */     }
/* 714  */ 
/* 715  */     function isValid(m) {
/* 716  */         if (m._isValid == null) {
/* 717  */             m._isValid = !isNaN(m._d.getTime()) &&
/* 718  */                 m._pf.overflow < 0 &&
/* 719  */                 !m._pf.empty &&
/* 720  */                 !m._pf.invalidMonth &&
/* 721  */                 !m._pf.nullInput &&
/* 722  */                 !m._pf.invalidFormat &&
/* 723  */                 !m._pf.userInvalidated;
/* 724  */ 
/* 725  */             if (m._strict) {
/* 726  */                 m._isValid = m._isValid &&
/* 727  */                     m._pf.charsLeftOver === 0 &&
/* 728  */                     m._pf.unusedTokens.length === 0;
/* 729  */             }
/* 730  */         }
/* 731  */         return m._isValid;
/* 732  */     }
/* 733  */ 
/* 734  */     function normalizeLocale(key) {
/* 735  */         return key ? key.toLowerCase().replace('_', '-') : key;
/* 736  */     }
/* 737  */ 
/* 738  */     // pick the locale from the array
/* 739  */     // try ['en-au', 'en-gb'] as 'en-au', 'en-gb', 'en', as in move through the list trying each
/* 740  */     // substring from most specific to least, but move to the next array item if it's a more specific variant than the current root
/* 741  */     function chooseLocale(names) {
/* 742  */         var i = 0, j, next, locale, split;
/* 743  */ 
/* 744  */         while (i < names.length) {
/* 745  */             split = normalizeLocale(names[i]).split('-');
/* 746  */             j = split.length;
/* 747  */             next = normalizeLocale(names[i + 1]);
/* 748  */             next = next ? next.split('-') : null;
/* 749  */             while (j > 0) {
/* 750  */                 locale = loadLocale(split.slice(0, j).join('-'));

/* moment.js */

/* 751  */                 if (locale) {
/* 752  */                     return locale;
/* 753  */                 }
/* 754  */                 if (next && next.length >= j && compareArrays(split, next, true) >= j - 1) {
/* 755  */                     //the next array item is better than a shallower substring of this one
/* 756  */                     break;
/* 757  */                 }
/* 758  */                 j--;
/* 759  */             }
/* 760  */             i++;
/* 761  */         }
/* 762  */         return null;
/* 763  */     }
/* 764  */ 
/* 765  */     function loadLocale(name) {
/* 766  */         var oldLocale = null;
/* 767  */         if (!locales[name] && hasModule) {
/* 768  */             try {
/* 769  */                 oldLocale = moment.locale();
/* 770  */                 require('./locale/' + name);
/* 771  */                 // because defineLocale currently also sets the global locale, we want to undo that for lazy loaded locales
/* 772  */                 moment.locale(oldLocale);
/* 773  */             } catch (e) { }
/* 774  */         }
/* 775  */         return locales[name];
/* 776  */     }
/* 777  */ 
/* 778  */     // Return a moment from input, that is local/utc/zone equivalent to model.
/* 779  */     function makeAs(input, model) {
/* 780  */         return model._isUTC ? moment(input).zone(model._offset || 0) :
/* 781  */             moment(input).local();
/* 782  */     }
/* 783  */ 
/* 784  */     /************************************
/* 785  *|         Locale
/* 786  *|     ************************************/
/* 787  */ 
/* 788  */ 
/* 789  */     extend(Locale.prototype, {
/* 790  */ 
/* 791  */         set : function (config) {
/* 792  */             var prop, i;
/* 793  */             for (i in config) {
/* 794  */                 prop = config[i];
/* 795  */                 if (typeof prop === 'function') {
/* 796  */                     this[i] = prop;
/* 797  */                 } else {
/* 798  */                     this['_' + i] = prop;
/* 799  */                 }
/* 800  */             }

/* moment.js */

/* 801  */         },
/* 802  */ 
/* 803  */         _months : 'January_February_March_April_May_June_July_August_September_October_November_December'.split('_'),
/* 804  */         months : function (m) {
/* 805  */             return this._months[m.month()];
/* 806  */         },
/* 807  */ 
/* 808  */         _monthsShort : 'Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec'.split('_'),
/* 809  */         monthsShort : function (m) {
/* 810  */             return this._monthsShort[m.month()];
/* 811  */         },
/* 812  */ 
/* 813  */         monthsParse : function (monthName) {
/* 814  */             var i, mom, regex;
/* 815  */ 
/* 816  */             if (!this._monthsParse) {
/* 817  */                 this._monthsParse = [];
/* 818  */             }
/* 819  */ 
/* 820  */             for (i = 0; i < 12; i++) {
/* 821  */                 // make the regex if we don't have it already
/* 822  */                 if (!this._monthsParse[i]) {
/* 823  */                     mom = moment.utc([2000, i]);
/* 824  */                     regex = '^' + this.months(mom, '') + '|^' + this.monthsShort(mom, '');
/* 825  */                     this._monthsParse[i] = new RegExp(regex.replace('.', ''), 'i');
/* 826  */                 }
/* 827  */                 // test the regex
/* 828  */                 if (this._monthsParse[i].test(monthName)) {
/* 829  */                     return i;
/* 830  */                 }
/* 831  */             }
/* 832  */         },
/* 833  */ 
/* 834  */         _weekdays : 'Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday'.split('_'),
/* 835  */         weekdays : function (m) {
/* 836  */             return this._weekdays[m.day()];
/* 837  */         },
/* 838  */ 
/* 839  */         _weekdaysShort : 'Sun_Mon_Tue_Wed_Thu_Fri_Sat'.split('_'),
/* 840  */         weekdaysShort : function (m) {
/* 841  */             return this._weekdaysShort[m.day()];
/* 842  */         },
/* 843  */ 
/* 844  */         _weekdaysMin : 'Su_Mo_Tu_We_Th_Fr_Sa'.split('_'),
/* 845  */         weekdaysMin : function (m) {
/* 846  */             return this._weekdaysMin[m.day()];
/* 847  */         },
/* 848  */ 
/* 849  */         weekdaysParse : function (weekdayName) {
/* 850  */             var i, mom, regex;

/* moment.js */

/* 851  */ 
/* 852  */             if (!this._weekdaysParse) {
/* 853  */                 this._weekdaysParse = [];
/* 854  */             }
/* 855  */ 
/* 856  */             for (i = 0; i < 7; i++) {
/* 857  */                 // make the regex if we don't have it already
/* 858  */                 if (!this._weekdaysParse[i]) {
/* 859  */                     mom = moment([2000, 1]).day(i);
/* 860  */                     regex = '^' + this.weekdays(mom, '') + '|^' + this.weekdaysShort(mom, '') + '|^' + this.weekdaysMin(mom, '');
/* 861  */                     this._weekdaysParse[i] = new RegExp(regex.replace('.', ''), 'i');
/* 862  */                 }
/* 863  */                 // test the regex
/* 864  */                 if (this._weekdaysParse[i].test(weekdayName)) {
/* 865  */                     return i;
/* 866  */                 }
/* 867  */             }
/* 868  */         },
/* 869  */ 
/* 870  */         _longDateFormat : {
/* 871  */             LT : 'h:mm A',
/* 872  */             L : 'MM/DD/YYYY',
/* 873  */             LL : 'MMMM D, YYYY',
/* 874  */             LLL : 'MMMM D, YYYY LT',
/* 875  */             LLLL : 'dddd, MMMM D, YYYY LT'
/* 876  */         },
/* 877  */         longDateFormat : function (key) {
/* 878  */             var output = this._longDateFormat[key];
/* 879  */             if (!output && this._longDateFormat[key.toUpperCase()]) {
/* 880  */                 output = this._longDateFormat[key.toUpperCase()].replace(/MMMM|MM|DD|dddd/g, function (val) {
/* 881  */                     return val.slice(1);
/* 882  */                 });
/* 883  */                 this._longDateFormat[key] = output;
/* 884  */             }
/* 885  */             return output;
/* 886  */         },
/* 887  */ 
/* 888  */         isPM : function (input) {
/* 889  */             // IE8 Quirks Mode & IE7 Standards Mode do not allow accessing strings like arrays
/* 890  */             // Using charAt should be more compatible.
/* 891  */             return ((input + '').toLowerCase().charAt(0) === 'p');
/* 892  */         },
/* 893  */ 
/* 894  */         _meridiemParse : /[ap]\.?m?\.?/i,
/* 895  */         meridiem : function (hours, minutes, isLower) {
/* 896  */             if (hours > 11) {
/* 897  */                 return isLower ? 'pm' : 'PM';
/* 898  */             } else {
/* 899  */                 return isLower ? 'am' : 'AM';
/* 900  */             }

/* moment.js */

/* 901  */         },
/* 902  */ 
/* 903  */         _calendar : {
/* 904  */             sameDay : '[Today at] LT',
/* 905  */             nextDay : '[Tomorrow at] LT',
/* 906  */             nextWeek : 'dddd [at] LT',
/* 907  */             lastDay : '[Yesterday at] LT',
/* 908  */             lastWeek : '[Last] dddd [at] LT',
/* 909  */             sameElse : 'L'
/* 910  */         },
/* 911  */         calendar : function (key, mom) {
/* 912  */             var output = this._calendar[key];
/* 913  */             return typeof output === 'function' ? output.apply(mom) : output;
/* 914  */         },
/* 915  */ 
/* 916  */         _relativeTime : {
/* 917  */             future : 'in %s',
/* 918  */             past : '%s ago',
/* 919  */             s : 'a few seconds',
/* 920  */             m : 'a minute',
/* 921  */             mm : '%d minutes',
/* 922  */             h : 'an hour',
/* 923  */             hh : '%d hours',
/* 924  */             d : 'a day',
/* 925  */             dd : '%d days',
/* 926  */             M : 'a month',
/* 927  */             MM : '%d months',
/* 928  */             y : 'a year',
/* 929  */             yy : '%d years'
/* 930  */         },
/* 931  */ 
/* 932  */         relativeTime : function (number, withoutSuffix, string, isFuture) {
/* 933  */             var output = this._relativeTime[string];
/* 934  */             return (typeof output === 'function') ?
/* 935  */                 output(number, withoutSuffix, string, isFuture) :
/* 936  */                 output.replace(/%d/i, number);
/* 937  */         },
/* 938  */ 
/* 939  */         pastFuture : function (diff, output) {
/* 940  */             var format = this._relativeTime[diff > 0 ? 'future' : 'past'];
/* 941  */             return typeof format === 'function' ? format(output) : format.replace(/%s/i, output);
/* 942  */         },
/* 943  */ 
/* 944  */         ordinal : function (number) {
/* 945  */             return this._ordinal.replace('%d', number);
/* 946  */         },
/* 947  */         _ordinal : '%d',
/* 948  */ 
/* 949  */         preparse : function (string) {
/* 950  */             return string;

/* moment.js */

/* 951  */         },
/* 952  */ 
/* 953  */         postformat : function (string) {
/* 954  */             return string;
/* 955  */         },
/* 956  */ 
/* 957  */         week : function (mom) {
/* 958  */             return weekOfYear(mom, this._week.dow, this._week.doy).week;
/* 959  */         },
/* 960  */ 
/* 961  */         _week : {
/* 962  */             dow : 0, // Sunday is the first day of the week.
/* 963  */             doy : 6  // The week that contains Jan 1st is the first week of the year.
/* 964  */         },
/* 965  */ 
/* 966  */         _invalidDate: 'Invalid date',
/* 967  */         invalidDate: function () {
/* 968  */             return this._invalidDate;
/* 969  */         }
/* 970  */     });
/* 971  */ 
/* 972  */     /************************************
/* 973  *|         Formatting
/* 974  *|     ************************************/
/* 975  */ 
/* 976  */ 
/* 977  */     function removeFormattingTokens(input) {
/* 978  */         if (input.match(/\[[\s\S]/)) {
/* 979  */             return input.replace(/^\[|\]$/g, '');
/* 980  */         }
/* 981  */         return input.replace(/\\/g, '');
/* 982  */     }
/* 983  */ 
/* 984  */     function makeFormatFunction(format) {
/* 985  */         var array = format.match(formattingTokens), i, length;
/* 986  */ 
/* 987  */         for (i = 0, length = array.length; i < length; i++) {
/* 988  */             if (formatTokenFunctions[array[i]]) {
/* 989  */                 array[i] = formatTokenFunctions[array[i]];
/* 990  */             } else {
/* 991  */                 array[i] = removeFormattingTokens(array[i]);
/* 992  */             }
/* 993  */         }
/* 994  */ 
/* 995  */         return function (mom) {
/* 996  */             var output = '';
/* 997  */             for (i = 0; i < length; i++) {
/* 998  */                 output += array[i] instanceof Function ? array[i].call(mom, format) : array[i];
/* 999  */             }
/* 1000 */             return output;

/* moment.js */

/* 1001 */         };
/* 1002 */     }
/* 1003 */ 
/* 1004 */     // format date using native date object
/* 1005 */     function formatMoment(m, format) {
/* 1006 */         if (!m.isValid()) {
/* 1007 */             return m.localeData().invalidDate();
/* 1008 */         }
/* 1009 */ 
/* 1010 */         format = expandFormat(format, m.localeData());
/* 1011 */ 
/* 1012 */         if (!formatFunctions[format]) {
/* 1013 */             formatFunctions[format] = makeFormatFunction(format);
/* 1014 */         }
/* 1015 */ 
/* 1016 */         return formatFunctions[format](m);
/* 1017 */     }
/* 1018 */ 
/* 1019 */     function expandFormat(format, locale) {
/* 1020 */         var i = 5;
/* 1021 */ 
/* 1022 */         function replaceLongDateFormatTokens(input) {
/* 1023 */             return locale.longDateFormat(input) || input;
/* 1024 */         }
/* 1025 */ 
/* 1026 */         localFormattingTokens.lastIndex = 0;
/* 1027 */         while (i >= 0 && localFormattingTokens.test(format)) {
/* 1028 */             format = format.replace(localFormattingTokens, replaceLongDateFormatTokens);
/* 1029 */             localFormattingTokens.lastIndex = 0;
/* 1030 */             i -= 1;
/* 1031 */         }
/* 1032 */ 
/* 1033 */         return format;
/* 1034 */     }
/* 1035 */ 
/* 1036 */ 
/* 1037 */     /************************************
/* 1038 *|         Parsing
/* 1039 *|     ************************************/
/* 1040 */ 
/* 1041 */ 
/* 1042 */     // get the regex to find the next token
/* 1043 */     function getParseRegexForToken(token, config) {
/* 1044 */         var a, strict = config._strict;
/* 1045 */         switch (token) {
/* 1046 */         case 'Q':
/* 1047 */             return parseTokenOneDigit;
/* 1048 */         case 'DDDD':
/* 1049 */             return parseTokenThreeDigits;
/* 1050 */         case 'YYYY':

/* moment.js */

/* 1051 */         case 'GGGG':
/* 1052 */         case 'gggg':
/* 1053 */             return strict ? parseTokenFourDigits : parseTokenOneToFourDigits;
/* 1054 */         case 'Y':
/* 1055 */         case 'G':
/* 1056 */         case 'g':
/* 1057 */             return parseTokenSignedNumber;
/* 1058 */         case 'YYYYYY':
/* 1059 */         case 'YYYYY':
/* 1060 */         case 'GGGGG':
/* 1061 */         case 'ggggg':
/* 1062 */             return strict ? parseTokenSixDigits : parseTokenOneToSixDigits;
/* 1063 */         case 'S':
/* 1064 */             if (strict) {
/* 1065 */                 return parseTokenOneDigit;
/* 1066 */             }
/* 1067 */             /* falls through */
/* 1068 */         case 'SS':
/* 1069 */             if (strict) {
/* 1070 */                 return parseTokenTwoDigits;
/* 1071 */             }
/* 1072 */             /* falls through */
/* 1073 */         case 'SSS':
/* 1074 */             if (strict) {
/* 1075 */                 return parseTokenThreeDigits;
/* 1076 */             }
/* 1077 */             /* falls through */
/* 1078 */         case 'DDD':
/* 1079 */             return parseTokenOneToThreeDigits;
/* 1080 */         case 'MMM':
/* 1081 */         case 'MMMM':
/* 1082 */         case 'dd':
/* 1083 */         case 'ddd':
/* 1084 */         case 'dddd':
/* 1085 */             return parseTokenWord;
/* 1086 */         case 'a':
/* 1087 */         case 'A':
/* 1088 */             return config._locale._meridiemParse;
/* 1089 */         case 'X':
/* 1090 */             return parseTokenTimestampMs;
/* 1091 */         case 'Z':
/* 1092 */         case 'ZZ':
/* 1093 */             return parseTokenTimezone;
/* 1094 */         case 'T':
/* 1095 */             return parseTokenT;
/* 1096 */         case 'SSSS':
/* 1097 */             return parseTokenDigits;
/* 1098 */         case 'MM':
/* 1099 */         case 'DD':
/* 1100 */         case 'YY':

/* moment.js */

/* 1101 */         case 'GG':
/* 1102 */         case 'gg':
/* 1103 */         case 'HH':
/* 1104 */         case 'hh':
/* 1105 */         case 'mm':
/* 1106 */         case 'ss':
/* 1107 */         case 'ww':
/* 1108 */         case 'WW':
/* 1109 */             return strict ? parseTokenTwoDigits : parseTokenOneOrTwoDigits;
/* 1110 */         case 'M':
/* 1111 */         case 'D':
/* 1112 */         case 'd':
/* 1113 */         case 'H':
/* 1114 */         case 'h':
/* 1115 */         case 'm':
/* 1116 */         case 's':
/* 1117 */         case 'w':
/* 1118 */         case 'W':
/* 1119 */         case 'e':
/* 1120 */         case 'E':
/* 1121 */             return parseTokenOneOrTwoDigits;
/* 1122 */         case 'Do':
/* 1123 */             return parseTokenOrdinal;
/* 1124 */         default :
/* 1125 */             a = new RegExp(regexpEscape(unescapeFormat(token.replace('\\', '')), 'i'));
/* 1126 */             return a;
/* 1127 */         }
/* 1128 */     }
/* 1129 */ 
/* 1130 */     function timezoneMinutesFromString(string) {
/* 1131 */         string = string || '';
/* 1132 */         var possibleTzMatches = (string.match(parseTokenTimezone) || []),
/* 1133 */             tzChunk = possibleTzMatches[possibleTzMatches.length - 1] || [],
/* 1134 */             parts = (tzChunk + '').match(parseTimezoneChunker) || ['-', 0, 0],
/* 1135 */             minutes = +(parts[1] * 60) + toInt(parts[2]);
/* 1136 */ 
/* 1137 */         return parts[0] === '+' ? -minutes : minutes;
/* 1138 */     }
/* 1139 */ 
/* 1140 */     // function to convert string input to date
/* 1141 */     function addTimeToArrayFromToken(token, input, config) {
/* 1142 */         var a, datePartArray = config._a;
/* 1143 */ 
/* 1144 */         switch (token) {
/* 1145 */         // QUARTER
/* 1146 */         case 'Q':
/* 1147 */             if (input != null) {
/* 1148 */                 datePartArray[MONTH] = (toInt(input) - 1) * 3;
/* 1149 */             }
/* 1150 */             break;

/* moment.js */

/* 1151 */         // MONTH
/* 1152 */         case 'M' : // fall through to MM
/* 1153 */         case 'MM' :
/* 1154 */             if (input != null) {
/* 1155 */                 datePartArray[MONTH] = toInt(input) - 1;
/* 1156 */             }
/* 1157 */             break;
/* 1158 */         case 'MMM' : // fall through to MMMM
/* 1159 */         case 'MMMM' :
/* 1160 */             a = config._locale.monthsParse(input);
/* 1161 */             // if we didn't find a month name, mark the date as invalid.
/* 1162 */             if (a != null) {
/* 1163 */                 datePartArray[MONTH] = a;
/* 1164 */             } else {
/* 1165 */                 config._pf.invalidMonth = input;
/* 1166 */             }
/* 1167 */             break;
/* 1168 */         // DAY OF MONTH
/* 1169 */         case 'D' : // fall through to DD
/* 1170 */         case 'DD' :
/* 1171 */             if (input != null) {
/* 1172 */                 datePartArray[DATE] = toInt(input);
/* 1173 */             }
/* 1174 */             break;
/* 1175 */         case 'Do' :
/* 1176 */             if (input != null) {
/* 1177 */                 datePartArray[DATE] = toInt(parseInt(input, 10));
/* 1178 */             }
/* 1179 */             break;
/* 1180 */         // DAY OF YEAR
/* 1181 */         case 'DDD' : // fall through to DDDD
/* 1182 */         case 'DDDD' :
/* 1183 */             if (input != null) {
/* 1184 */                 config._dayOfYear = toInt(input);
/* 1185 */             }
/* 1186 */ 
/* 1187 */             break;
/* 1188 */         // YEAR
/* 1189 */         case 'YY' :
/* 1190 */             datePartArray[YEAR] = moment.parseTwoDigitYear(input);
/* 1191 */             break;
/* 1192 */         case 'YYYY' :
/* 1193 */         case 'YYYYY' :
/* 1194 */         case 'YYYYYY' :
/* 1195 */             datePartArray[YEAR] = toInt(input);
/* 1196 */             break;
/* 1197 */         // AM / PM
/* 1198 */         case 'a' : // fall through to A
/* 1199 */         case 'A' :
/* 1200 */             config._isPm = config._locale.isPM(input);

/* moment.js */

/* 1201 */             break;
/* 1202 */         // 24 HOUR
/* 1203 */         case 'H' : // fall through to hh
/* 1204 */         case 'HH' : // fall through to hh
/* 1205 */         case 'h' : // fall through to hh
/* 1206 */         case 'hh' :
/* 1207 */             datePartArray[HOUR] = toInt(input);
/* 1208 */             break;
/* 1209 */         // MINUTE
/* 1210 */         case 'm' : // fall through to mm
/* 1211 */         case 'mm' :
/* 1212 */             datePartArray[MINUTE] = toInt(input);
/* 1213 */             break;
/* 1214 */         // SECOND
/* 1215 */         case 's' : // fall through to ss
/* 1216 */         case 'ss' :
/* 1217 */             datePartArray[SECOND] = toInt(input);
/* 1218 */             break;
/* 1219 */         // MILLISECOND
/* 1220 */         case 'S' :
/* 1221 */         case 'SS' :
/* 1222 */         case 'SSS' :
/* 1223 */         case 'SSSS' :
/* 1224 */             datePartArray[MILLISECOND] = toInt(('0.' + input) * 1000);
/* 1225 */             break;
/* 1226 */         // UNIX TIMESTAMP WITH MS
/* 1227 */         case 'X':
/* 1228 */             config._d = new Date(parseFloat(input) * 1000);
/* 1229 */             break;
/* 1230 */         // TIMEZONE
/* 1231 */         case 'Z' : // fall through to ZZ
/* 1232 */         case 'ZZ' :
/* 1233 */             config._useUTC = true;
/* 1234 */             config._tzm = timezoneMinutesFromString(input);
/* 1235 */             break;
/* 1236 */         // WEEKDAY - human
/* 1237 */         case 'dd':
/* 1238 */         case 'ddd':
/* 1239 */         case 'dddd':
/* 1240 */             a = config._locale.weekdaysParse(input);
/* 1241 */             // if we didn't get a weekday name, mark the date as invalid
/* 1242 */             if (a != null) {
/* 1243 */                 config._w = config._w || {};
/* 1244 */                 config._w['d'] = a;
/* 1245 */             } else {
/* 1246 */                 config._pf.invalidWeekday = input;
/* 1247 */             }
/* 1248 */             break;
/* 1249 */         // WEEK, WEEK DAY - numeric
/* 1250 */         case 'w':

/* moment.js */

/* 1251 */         case 'ww':
/* 1252 */         case 'W':
/* 1253 */         case 'WW':
/* 1254 */         case 'd':
/* 1255 */         case 'e':
/* 1256 */         case 'E':
/* 1257 */             token = token.substr(0, 1);
/* 1258 */             /* falls through */
/* 1259 */         case 'gggg':
/* 1260 */         case 'GGGG':
/* 1261 */         case 'GGGGG':
/* 1262 */             token = token.substr(0, 2);
/* 1263 */             if (input) {
/* 1264 */                 config._w = config._w || {};
/* 1265 */                 config._w[token] = toInt(input);
/* 1266 */             }
/* 1267 */             break;
/* 1268 */         case 'gg':
/* 1269 */         case 'GG':
/* 1270 */             config._w = config._w || {};
/* 1271 */             config._w[token] = moment.parseTwoDigitYear(input);
/* 1272 */         }
/* 1273 */     }
/* 1274 */ 
/* 1275 */     function dayOfYearFromWeekInfo(config) {
/* 1276 */         var w, weekYear, week, weekday, dow, doy, temp;
/* 1277 */ 
/* 1278 */         w = config._w;
/* 1279 */         if (w.GG != null || w.W != null || w.E != null) {
/* 1280 */             dow = 1;
/* 1281 */             doy = 4;
/* 1282 */ 
/* 1283 */             // TODO: We need to take the current isoWeekYear, but that depends on
/* 1284 */             // how we interpret now (local, utc, fixed offset). So create
/* 1285 */             // a now version of current config (take local/utc/offset flags, and
/* 1286 */             // create now).
/* 1287 */             weekYear = dfl(w.GG, config._a[YEAR], weekOfYear(moment(), 1, 4).year);
/* 1288 */             week = dfl(w.W, 1);
/* 1289 */             weekday = dfl(w.E, 1);
/* 1290 */         } else {
/* 1291 */             dow = config._locale._week.dow;
/* 1292 */             doy = config._locale._week.doy;
/* 1293 */ 
/* 1294 */             weekYear = dfl(w.gg, config._a[YEAR], weekOfYear(moment(), dow, doy).year);
/* 1295 */             week = dfl(w.w, 1);
/* 1296 */ 
/* 1297 */             if (w.d != null) {
/* 1298 */                 // weekday -- low day numbers are considered next week
/* 1299 */                 weekday = w.d;
/* 1300 */                 if (weekday < dow) {

/* moment.js */

/* 1301 */                     ++week;
/* 1302 */                 }
/* 1303 */             } else if (w.e != null) {
/* 1304 */                 // local weekday -- counting starts from begining of week
/* 1305 */                 weekday = w.e + dow;
/* 1306 */             } else {
/* 1307 */                 // default to begining of week
/* 1308 */                 weekday = dow;
/* 1309 */             }
/* 1310 */         }
/* 1311 */         temp = dayOfYearFromWeeks(weekYear, week, weekday, doy, dow);
/* 1312 */ 
/* 1313 */         config._a[YEAR] = temp.year;
/* 1314 */         config._dayOfYear = temp.dayOfYear;
/* 1315 */     }
/* 1316 */ 
/* 1317 */     // convert an array to a date.
/* 1318 */     // the array should mirror the parameters below
/* 1319 */     // note: all values past the year are optional and will default to the lowest possible value.
/* 1320 */     // [year, month, day , hour, minute, second, millisecond]
/* 1321 */     function dateFromConfig(config) {
/* 1322 */         var i, date, input = [], currentDate, yearToUse;
/* 1323 */ 
/* 1324 */         if (config._d) {
/* 1325 */             return;
/* 1326 */         }
/* 1327 */ 
/* 1328 */         currentDate = currentDateArray(config);
/* 1329 */ 
/* 1330 */         //compute day of the year from weeks and weekdays
/* 1331 */         if (config._w && config._a[DATE] == null && config._a[MONTH] == null) {
/* 1332 */             dayOfYearFromWeekInfo(config);
/* 1333 */         }
/* 1334 */ 
/* 1335 */         //if the day of the year is set, figure out what it is
/* 1336 */         if (config._dayOfYear) {
/* 1337 */             yearToUse = dfl(config._a[YEAR], currentDate[YEAR]);
/* 1338 */ 
/* 1339 */             if (config._dayOfYear > daysInYear(yearToUse)) {
/* 1340 */                 config._pf._overflowDayOfYear = true;
/* 1341 */             }
/* 1342 */ 
/* 1343 */             date = makeUTCDate(yearToUse, 0, config._dayOfYear);
/* 1344 */             config._a[MONTH] = date.getUTCMonth();
/* 1345 */             config._a[DATE] = date.getUTCDate();
/* 1346 */         }
/* 1347 */ 
/* 1348 */         // Default to current date.
/* 1349 */         // * if no year, month, day of month are given, default to today
/* 1350 */         // * if day of month is given, default month and year

/* moment.js */

/* 1351 */         // * if month is given, default only year
/* 1352 */         // * if year is given, don't default anything
/* 1353 */         for (i = 0; i < 3 && config._a[i] == null; ++i) {
/* 1354 */             config._a[i] = input[i] = currentDate[i];
/* 1355 */         }
/* 1356 */ 
/* 1357 */         // Zero out whatever was not defaulted, including time
/* 1358 */         for (; i < 7; i++) {
/* 1359 */             config._a[i] = input[i] = (config._a[i] == null) ? (i === 2 ? 1 : 0) : config._a[i];
/* 1360 */         }
/* 1361 */ 
/* 1362 */         config._d = (config._useUTC ? makeUTCDate : makeDate).apply(null, input);
/* 1363 */         // Apply timezone offset from input. The actual zone can be changed
/* 1364 */         // with parseZone.
/* 1365 */         if (config._tzm != null) {
/* 1366 */             config._d.setUTCMinutes(config._d.getUTCMinutes() + config._tzm);
/* 1367 */         }
/* 1368 */     }
/* 1369 */ 
/* 1370 */     function dateFromObject(config) {
/* 1371 */         var normalizedInput;
/* 1372 */ 
/* 1373 */         if (config._d) {
/* 1374 */             return;
/* 1375 */         }
/* 1376 */ 
/* 1377 */         normalizedInput = normalizeObjectUnits(config._i);
/* 1378 */         config._a = [
/* 1379 */             normalizedInput.year,
/* 1380 */             normalizedInput.month,
/* 1381 */             normalizedInput.day,
/* 1382 */             normalizedInput.hour,
/* 1383 */             normalizedInput.minute,
/* 1384 */             normalizedInput.second,
/* 1385 */             normalizedInput.millisecond
/* 1386 */         ];
/* 1387 */ 
/* 1388 */         dateFromConfig(config);
/* 1389 */     }
/* 1390 */ 
/* 1391 */     function currentDateArray(config) {
/* 1392 */         var now = new Date();
/* 1393 */         if (config._useUTC) {
/* 1394 */             return [
/* 1395 */                 now.getUTCFullYear(),
/* 1396 */                 now.getUTCMonth(),
/* 1397 */                 now.getUTCDate()
/* 1398 */             ];
/* 1399 */         } else {
/* 1400 */             return [now.getFullYear(), now.getMonth(), now.getDate()];

/* moment.js */

/* 1401 */         }
/* 1402 */     }
/* 1403 */ 
/* 1404 */     // date from string and format string
/* 1405 */     function makeDateFromStringAndFormat(config) {
/* 1406 */         if (config._f === moment.ISO_8601) {
/* 1407 */             parseISO(config);
/* 1408 */             return;
/* 1409 */         }
/* 1410 */ 
/* 1411 */         config._a = [];
/* 1412 */         config._pf.empty = true;
/* 1413 */ 
/* 1414 */         // This array is used to make a Date, either with `new Date` or `Date.UTC`
/* 1415 */         var string = '' + config._i,
/* 1416 */             i, parsedInput, tokens, token, skipped,
/* 1417 */             stringLength = string.length,
/* 1418 */             totalParsedInputLength = 0;
/* 1419 */ 
/* 1420 */         tokens = expandFormat(config._f, config._locale).match(formattingTokens) || [];
/* 1421 */ 
/* 1422 */         for (i = 0; i < tokens.length; i++) {
/* 1423 */             token = tokens[i];
/* 1424 */             parsedInput = (string.match(getParseRegexForToken(token, config)) || [])[0];
/* 1425 */             if (parsedInput) {
/* 1426 */                 skipped = string.substr(0, string.indexOf(parsedInput));
/* 1427 */                 if (skipped.length > 0) {
/* 1428 */                     config._pf.unusedInput.push(skipped);
/* 1429 */                 }
/* 1430 */                 string = string.slice(string.indexOf(parsedInput) + parsedInput.length);
/* 1431 */                 totalParsedInputLength += parsedInput.length;
/* 1432 */             }
/* 1433 */             // don't parse if it's not a known token
/* 1434 */             if (formatTokenFunctions[token]) {
/* 1435 */                 if (parsedInput) {
/* 1436 */                     config._pf.empty = false;
/* 1437 */                 }
/* 1438 */                 else {
/* 1439 */                     config._pf.unusedTokens.push(token);
/* 1440 */                 }
/* 1441 */                 addTimeToArrayFromToken(token, parsedInput, config);
/* 1442 */             }
/* 1443 */             else if (config._strict && !parsedInput) {
/* 1444 */                 config._pf.unusedTokens.push(token);
/* 1445 */             }
/* 1446 */         }
/* 1447 */ 
/* 1448 */         // add remaining unparsed input length to the string
/* 1449 */         config._pf.charsLeftOver = stringLength - totalParsedInputLength;
/* 1450 */         if (string.length > 0) {

/* moment.js */

/* 1451 */             config._pf.unusedInput.push(string);
/* 1452 */         }
/* 1453 */ 
/* 1454 */         // handle am pm
/* 1455 */         if (config._isPm && config._a[HOUR] < 12) {
/* 1456 */             config._a[HOUR] += 12;
/* 1457 */         }
/* 1458 */         // if is 12 am, change hours to 0
/* 1459 */         if (config._isPm === false && config._a[HOUR] === 12) {
/* 1460 */             config._a[HOUR] = 0;
/* 1461 */         }
/* 1462 */ 
/* 1463 */         dateFromConfig(config);
/* 1464 */         checkOverflow(config);
/* 1465 */     }
/* 1466 */ 
/* 1467 */     function unescapeFormat(s) {
/* 1468 */         return s.replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function (matched, p1, p2, p3, p4) {
/* 1469 */             return p1 || p2 || p3 || p4;
/* 1470 */         });
/* 1471 */     }
/* 1472 */ 
/* 1473 */     // Code from http://stackoverflow.com/questions/3561493/is-there-a-regexp-escape-function-in-javascript
/* 1474 */     function regexpEscape(s) {
/* 1475 */         return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
/* 1476 */     }
/* 1477 */ 
/* 1478 */     // date from string and array of format strings
/* 1479 */     function makeDateFromStringAndArray(config) {
/* 1480 */         var tempConfig,
/* 1481 */             bestMoment,
/* 1482 */ 
/* 1483 */             scoreToBeat,
/* 1484 */             i,
/* 1485 */             currentScore;
/* 1486 */ 
/* 1487 */         if (config._f.length === 0) {
/* 1488 */             config._pf.invalidFormat = true;
/* 1489 */             config._d = new Date(NaN);
/* 1490 */             return;
/* 1491 */         }
/* 1492 */ 
/* 1493 */         for (i = 0; i < config._f.length; i++) {
/* 1494 */             currentScore = 0;
/* 1495 */             tempConfig = copyConfig({}, config);
/* 1496 */             if (config._useUTC != null) {
/* 1497 */                 tempConfig._useUTC = config._useUTC;
/* 1498 */             }
/* 1499 */             tempConfig._pf = defaultParsingFlags();
/* 1500 */             tempConfig._f = config._f[i];

/* moment.js */

/* 1501 */             makeDateFromStringAndFormat(tempConfig);
/* 1502 */ 
/* 1503 */             if (!isValid(tempConfig)) {
/* 1504 */                 continue;
/* 1505 */             }
/* 1506 */ 
/* 1507 */             // if there is any input that was not parsed add a penalty for that format
/* 1508 */             currentScore += tempConfig._pf.charsLeftOver;
/* 1509 */ 
/* 1510 */             //or tokens
/* 1511 */             currentScore += tempConfig._pf.unusedTokens.length * 10;
/* 1512 */ 
/* 1513 */             tempConfig._pf.score = currentScore;
/* 1514 */ 
/* 1515 */             if (scoreToBeat == null || currentScore < scoreToBeat) {
/* 1516 */                 scoreToBeat = currentScore;
/* 1517 */                 bestMoment = tempConfig;
/* 1518 */             }
/* 1519 */         }
/* 1520 */ 
/* 1521 */         extend(config, bestMoment || tempConfig);
/* 1522 */     }
/* 1523 */ 
/* 1524 */     // date from iso format
/* 1525 */     function parseISO(config) {
/* 1526 */         var i, l,
/* 1527 */             string = config._i,
/* 1528 */             match = isoRegex.exec(string);
/* 1529 */ 
/* 1530 */         if (match) {
/* 1531 */             config._pf.iso = true;
/* 1532 */             for (i = 0, l = isoDates.length; i < l; i++) {
/* 1533 */                 if (isoDates[i][1].exec(string)) {
/* 1534 */                     // match[5] should be 'T' or undefined
/* 1535 */                     config._f = isoDates[i][0] + (match[6] || ' ');
/* 1536 */                     break;
/* 1537 */                 }
/* 1538 */             }
/* 1539 */             for (i = 0, l = isoTimes.length; i < l; i++) {
/* 1540 */                 if (isoTimes[i][1].exec(string)) {
/* 1541 */                     config._f += isoTimes[i][0];
/* 1542 */                     break;
/* 1543 */                 }
/* 1544 */             }
/* 1545 */             if (string.match(parseTokenTimezone)) {
/* 1546 */                 config._f += 'Z';
/* 1547 */             }
/* 1548 */             makeDateFromStringAndFormat(config);
/* 1549 */         } else {
/* 1550 */             config._isValid = false;

/* moment.js */

/* 1551 */         }
/* 1552 */     }
/* 1553 */ 
/* 1554 */     // date from iso format or fallback
/* 1555 */     function makeDateFromString(config) {
/* 1556 */         parseISO(config);
/* 1557 */         if (config._isValid === false) {
/* 1558 */             delete config._isValid;
/* 1559 */             moment.createFromInputFallback(config);
/* 1560 */         }
/* 1561 */     }
/* 1562 */ 
/* 1563 */     function map(arr, fn) {
/* 1564 */         var res = [], i;
/* 1565 */         for (i = 0; i < arr.length; ++i) {
/* 1566 */             res.push(fn(arr[i], i));
/* 1567 */         }
/* 1568 */         return res;
/* 1569 */     }
/* 1570 */ 
/* 1571 */     function makeDateFromInput(config) {
/* 1572 */         var input = config._i, matched;
/* 1573 */         if (input === undefined) {
/* 1574 */             config._d = new Date();
/* 1575 */         } else if (isDate(input)) {
/* 1576 */             config._d = new Date(+input);
/* 1577 */         } else if ((matched = aspNetJsonRegex.exec(input)) !== null) {
/* 1578 */             config._d = new Date(+matched[1]);
/* 1579 */         } else if (typeof input === 'string') {
/* 1580 */             makeDateFromString(config);
/* 1581 */         } else if (isArray(input)) {
/* 1582 */             config._a = map(input.slice(0), function (obj) {
/* 1583 */                 return parseInt(obj, 10);
/* 1584 */             });
/* 1585 */             dateFromConfig(config);
/* 1586 */         } else if (typeof(input) === 'object') {
/* 1587 */             dateFromObject(config);
/* 1588 */         } else if (typeof(input) === 'number') {
/* 1589 */             // from milliseconds
/* 1590 */             config._d = new Date(input);
/* 1591 */         } else {
/* 1592 */             moment.createFromInputFallback(config);
/* 1593 */         }
/* 1594 */     }
/* 1595 */ 
/* 1596 */     function makeDate(y, m, d, h, M, s, ms) {
/* 1597 */         //can't just apply() to create a date:
/* 1598 */         //http://stackoverflow.com/questions/181348/instantiating-a-javascript-object-by-calling-prototype-constructor-apply
/* 1599 */         var date = new Date(y, m, d, h, M, s, ms);
/* 1600 */ 

/* moment.js */

/* 1601 */         //the date constructor doesn't accept years < 1970
/* 1602 */         if (y < 1970) {
/* 1603 */             date.setFullYear(y);
/* 1604 */         }
/* 1605 */         return date;
/* 1606 */     }
/* 1607 */ 
/* 1608 */     function makeUTCDate(y) {
/* 1609 */         var date = new Date(Date.UTC.apply(null, arguments));
/* 1610 */         if (y < 1970) {
/* 1611 */             date.setUTCFullYear(y);
/* 1612 */         }
/* 1613 */         return date;
/* 1614 */     }
/* 1615 */ 
/* 1616 */     function parseWeekday(input, locale) {
/* 1617 */         if (typeof input === 'string') {
/* 1618 */             if (!isNaN(input)) {
/* 1619 */                 input = parseInt(input, 10);
/* 1620 */             }
/* 1621 */             else {
/* 1622 */                 input = locale.weekdaysParse(input);
/* 1623 */                 if (typeof input !== 'number') {
/* 1624 */                     return null;
/* 1625 */                 }
/* 1626 */             }
/* 1627 */         }
/* 1628 */         return input;
/* 1629 */     }
/* 1630 */ 
/* 1631 */     /************************************
/* 1632 *|         Relative Time
/* 1633 *|     ************************************/
/* 1634 */ 
/* 1635 */ 
/* 1636 */     // helper function for moment.fn.from, moment.fn.fromNow, and moment.duration.fn.humanize
/* 1637 */     function substituteTimeAgo(string, number, withoutSuffix, isFuture, locale) {
/* 1638 */         return locale.relativeTime(number || 1, !!withoutSuffix, string, isFuture);
/* 1639 */     }
/* 1640 */ 
/* 1641 */     function relativeTime(posNegDuration, withoutSuffix, locale) {
/* 1642 */         var duration = moment.duration(posNegDuration).abs(),
/* 1643 */             seconds = round(duration.as('s')),
/* 1644 */             minutes = round(duration.as('m')),
/* 1645 */             hours = round(duration.as('h')),
/* 1646 */             days = round(duration.as('d')),
/* 1647 */             months = round(duration.as('M')),
/* 1648 */             years = round(duration.as('y')),
/* 1649 */ 
/* 1650 */             args = seconds < relativeTimeThresholds.s && ['s', seconds] ||

/* moment.js */

/* 1651 */                 minutes === 1 && ['m'] ||
/* 1652 */                 minutes < relativeTimeThresholds.m && ['mm', minutes] ||
/* 1653 */                 hours === 1 && ['h'] ||
/* 1654 */                 hours < relativeTimeThresholds.h && ['hh', hours] ||
/* 1655 */                 days === 1 && ['d'] ||
/* 1656 */                 days < relativeTimeThresholds.d && ['dd', days] ||
/* 1657 */                 months === 1 && ['M'] ||
/* 1658 */                 months < relativeTimeThresholds.M && ['MM', months] ||
/* 1659 */                 years === 1 && ['y'] || ['yy', years];
/* 1660 */ 
/* 1661 */         args[2] = withoutSuffix;
/* 1662 */         args[3] = +posNegDuration > 0;
/* 1663 */         args[4] = locale;
/* 1664 */         return substituteTimeAgo.apply({}, args);
/* 1665 */     }
/* 1666 */ 
/* 1667 */ 
/* 1668 */     /************************************
/* 1669 *|         Week of Year
/* 1670 *|     ************************************/
/* 1671 */ 
/* 1672 */ 
/* 1673 */     // firstDayOfWeek       0 = sun, 6 = sat
/* 1674 */     //                      the day of the week that starts the week
/* 1675 */     //                      (usually sunday or monday)
/* 1676 */     // firstDayOfWeekOfYear 0 = sun, 6 = sat
/* 1677 */     //                      the first week is the week that contains the first
/* 1678 */     //                      of this day of the week
/* 1679 */     //                      (eg. ISO weeks use thursday (4))
/* 1680 */     function weekOfYear(mom, firstDayOfWeek, firstDayOfWeekOfYear) {
/* 1681 */         var end = firstDayOfWeekOfYear - firstDayOfWeek,
/* 1682 */             daysToDayOfWeek = firstDayOfWeekOfYear - mom.day(),
/* 1683 */             adjustedMoment;
/* 1684 */ 
/* 1685 */ 
/* 1686 */         if (daysToDayOfWeek > end) {
/* 1687 */             daysToDayOfWeek -= 7;
/* 1688 */         }
/* 1689 */ 
/* 1690 */         if (daysToDayOfWeek < end - 7) {
/* 1691 */             daysToDayOfWeek += 7;
/* 1692 */         }
/* 1693 */ 
/* 1694 */         adjustedMoment = moment(mom).add(daysToDayOfWeek, 'd');
/* 1695 */         return {
/* 1696 */             week: Math.ceil(adjustedMoment.dayOfYear() / 7),
/* 1697 */             year: adjustedMoment.year()
/* 1698 */         };
/* 1699 */     }
/* 1700 */ 

/* moment.js */

/* 1701 */     //http://en.wikipedia.org/wiki/ISO_week_date#Calculating_a_date_given_the_year.2C_week_number_and_weekday
/* 1702 */     function dayOfYearFromWeeks(year, week, weekday, firstDayOfWeekOfYear, firstDayOfWeek) {
/* 1703 */         var d = makeUTCDate(year, 0, 1).getUTCDay(), daysToAdd, dayOfYear;
/* 1704 */ 
/* 1705 */         d = d === 0 ? 7 : d;
/* 1706 */         weekday = weekday != null ? weekday : firstDayOfWeek;
/* 1707 */         daysToAdd = firstDayOfWeek - d + (d > firstDayOfWeekOfYear ? 7 : 0) - (d < firstDayOfWeek ? 7 : 0);
/* 1708 */         dayOfYear = 7 * (week - 1) + (weekday - firstDayOfWeek) + daysToAdd + 1;
/* 1709 */ 
/* 1710 */         return {
/* 1711 */             year: dayOfYear > 0 ? year : year - 1,
/* 1712 */             dayOfYear: dayOfYear > 0 ?  dayOfYear : daysInYear(year - 1) + dayOfYear
/* 1713 */         };
/* 1714 */     }
/* 1715 */ 
/* 1716 */     /************************************
/* 1717 *|         Top Level Functions
/* 1718 *|     ************************************/
/* 1719 */ 
/* 1720 */     function makeMoment(config) {
/* 1721 */         var input = config._i,
/* 1722 */             format = config._f;
/* 1723 */ 
/* 1724 */         config._locale = config._locale || moment.localeData(config._l);
/* 1725 */ 
/* 1726 */         if (input === null || (format === undefined && input === '')) {
/* 1727 */             return moment.invalid({nullInput: true});
/* 1728 */         }
/* 1729 */ 
/* 1730 */         if (typeof input === 'string') {
/* 1731 */             config._i = input = config._locale.preparse(input);
/* 1732 */         }
/* 1733 */ 
/* 1734 */         if (moment.isMoment(input)) {
/* 1735 */             return new Moment(input, true);
/* 1736 */         } else if (format) {
/* 1737 */             if (isArray(format)) {
/* 1738 */                 makeDateFromStringAndArray(config);
/* 1739 */             } else {
/* 1740 */                 makeDateFromStringAndFormat(config);
/* 1741 */             }
/* 1742 */         } else {
/* 1743 */             makeDateFromInput(config);
/* 1744 */         }
/* 1745 */ 
/* 1746 */         return new Moment(config);
/* 1747 */     }
/* 1748 */ 
/* 1749 */     moment = function (input, format, locale, strict) {
/* 1750 */         var c;

/* moment.js */

/* 1751 */ 
/* 1752 */         if (typeof(locale) === 'boolean') {
/* 1753 */             strict = locale;
/* 1754 */             locale = undefined;
/* 1755 */         }
/* 1756 */         // object construction must be done this way.
/* 1757 */         // https://github.com/moment/moment/issues/1423
/* 1758 */         c = {};
/* 1759 */         c._isAMomentObject = true;
/* 1760 */         c._i = input;
/* 1761 */         c._f = format;
/* 1762 */         c._l = locale;
/* 1763 */         c._strict = strict;
/* 1764 */         c._isUTC = false;
/* 1765 */         c._pf = defaultParsingFlags();
/* 1766 */ 
/* 1767 */         return makeMoment(c);
/* 1768 */     };
/* 1769 */ 
/* 1770 */     moment.suppressDeprecationWarnings = false;
/* 1771 */ 
/* 1772 */     moment.createFromInputFallback = deprecate(
/* 1773 */         'moment construction falls back to js Date. This is ' +
/* 1774 */         'discouraged and will be removed in upcoming major ' +
/* 1775 */         'release. Please refer to ' +
/* 1776 */         'https://github.com/moment/moment/issues/1407 for more info.',
/* 1777 */         function (config) {
/* 1778 */             config._d = new Date(config._i);
/* 1779 */         }
/* 1780 */     );
/* 1781 */ 
/* 1782 */     // Pick a moment m from moments so that m[fn](other) is true for all
/* 1783 */     // other. This relies on the function fn to be transitive.
/* 1784 */     //
/* 1785 */     // moments should either be an array of moment objects or an array, whose
/* 1786 */     // first element is an array of moment objects.
/* 1787 */     function pickBy(fn, moments) {
/* 1788 */         var res, i;
/* 1789 */         if (moments.length === 1 && isArray(moments[0])) {
/* 1790 */             moments = moments[0];
/* 1791 */         }
/* 1792 */         if (!moments.length) {
/* 1793 */             return moment();
/* 1794 */         }
/* 1795 */         res = moments[0];
/* 1796 */         for (i = 1; i < moments.length; ++i) {
/* 1797 */             if (moments[i][fn](res)) {
/* 1798 */                 res = moments[i];
/* 1799 */             }
/* 1800 */         }

/* moment.js */

/* 1801 */         return res;
/* 1802 */     }
/* 1803 */ 
/* 1804 */     moment.min = function () {
/* 1805 */         var args = [].slice.call(arguments, 0);
/* 1806 */ 
/* 1807 */         return pickBy('isBefore', args);
/* 1808 */     };
/* 1809 */ 
/* 1810 */     moment.max = function () {
/* 1811 */         var args = [].slice.call(arguments, 0);
/* 1812 */ 
/* 1813 */         return pickBy('isAfter', args);
/* 1814 */     };
/* 1815 */ 
/* 1816 */     // creating with utc
/* 1817 */     moment.utc = function (input, format, locale, strict) {
/* 1818 */         var c;
/* 1819 */ 
/* 1820 */         if (typeof(locale) === 'boolean') {
/* 1821 */             strict = locale;
/* 1822 */             locale = undefined;
/* 1823 */         }
/* 1824 */         // object construction must be done this way.
/* 1825 */         // https://github.com/moment/moment/issues/1423
/* 1826 */         c = {};
/* 1827 */         c._isAMomentObject = true;
/* 1828 */         c._useUTC = true;
/* 1829 */         c._isUTC = true;
/* 1830 */         c._l = locale;
/* 1831 */         c._i = input;
/* 1832 */         c._f = format;
/* 1833 */         c._strict = strict;
/* 1834 */         c._pf = defaultParsingFlags();
/* 1835 */ 
/* 1836 */         return makeMoment(c).utc();
/* 1837 */     };
/* 1838 */ 
/* 1839 */     // creating with unix timestamp (in seconds)
/* 1840 */     moment.unix = function (input) {
/* 1841 */         return moment(input * 1000);
/* 1842 */     };
/* 1843 */ 
/* 1844 */     // duration
/* 1845 */     moment.duration = function (input, key) {
/* 1846 */         var duration = input,
/* 1847 */             // matching against regexp is expensive, do it on demand
/* 1848 */             match = null,
/* 1849 */             sign,
/* 1850 */             ret,

/* moment.js */

/* 1851 */             parseIso,
/* 1852 */             diffRes;
/* 1853 */ 
/* 1854 */         if (moment.isDuration(input)) {
/* 1855 */             duration = {
/* 1856 */                 ms: input._milliseconds,
/* 1857 */                 d: input._days,
/* 1858 */                 M: input._months
/* 1859 */             };
/* 1860 */         } else if (typeof input === 'number') {
/* 1861 */             duration = {};
/* 1862 */             if (key) {
/* 1863 */                 duration[key] = input;
/* 1864 */             } else {
/* 1865 */                 duration.milliseconds = input;
/* 1866 */             }
/* 1867 */         } else if (!!(match = aspNetTimeSpanJsonRegex.exec(input))) {
/* 1868 */             sign = (match[1] === '-') ? -1 : 1;
/* 1869 */             duration = {
/* 1870 */                 y: 0,
/* 1871 */                 d: toInt(match[DATE]) * sign,
/* 1872 */                 h: toInt(match[HOUR]) * sign,
/* 1873 */                 m: toInt(match[MINUTE]) * sign,
/* 1874 */                 s: toInt(match[SECOND]) * sign,
/* 1875 */                 ms: toInt(match[MILLISECOND]) * sign
/* 1876 */             };
/* 1877 */         } else if (!!(match = isoDurationRegex.exec(input))) {
/* 1878 */             sign = (match[1] === '-') ? -1 : 1;
/* 1879 */             parseIso = function (inp) {
/* 1880 */                 // We'd normally use ~~inp for this, but unfortunately it also
/* 1881 */                 // converts floats to ints.
/* 1882 */                 // inp may be undefined, so careful calling replace on it.
/* 1883 */                 var res = inp && parseFloat(inp.replace(',', '.'));
/* 1884 */                 // apply sign while we're at it
/* 1885 */                 return (isNaN(res) ? 0 : res) * sign;
/* 1886 */             };
/* 1887 */             duration = {
/* 1888 */                 y: parseIso(match[2]),
/* 1889 */                 M: parseIso(match[3]),
/* 1890 */                 d: parseIso(match[4]),
/* 1891 */                 h: parseIso(match[5]),
/* 1892 */                 m: parseIso(match[6]),
/* 1893 */                 s: parseIso(match[7]),
/* 1894 */                 w: parseIso(match[8])
/* 1895 */             };
/* 1896 */         } else if (typeof duration === 'object' &&
/* 1897 */                 ('from' in duration || 'to' in duration)) {
/* 1898 */             diffRes = momentsDifference(moment(duration.from), moment(duration.to));
/* 1899 */ 
/* 1900 */             duration = {};

/* moment.js */

/* 1901 */             duration.ms = diffRes.milliseconds;
/* 1902 */             duration.M = diffRes.months;
/* 1903 */         }
/* 1904 */ 
/* 1905 */         ret = new Duration(duration);
/* 1906 */ 
/* 1907 */         if (moment.isDuration(input) && hasOwnProp(input, '_locale')) {
/* 1908 */             ret._locale = input._locale;
/* 1909 */         }
/* 1910 */ 
/* 1911 */         return ret;
/* 1912 */     };
/* 1913 */ 
/* 1914 */     // version number
/* 1915 */     moment.version = VERSION;
/* 1916 */ 
/* 1917 */     // default format
/* 1918 */     moment.defaultFormat = isoFormat;
/* 1919 */ 
/* 1920 */     // constant that refers to the ISO standard
/* 1921 */     moment.ISO_8601 = function () {};
/* 1922 */ 
/* 1923 */     // Plugins that add properties should also add the key here (null value),
/* 1924 */     // so we can properly clone ourselves.
/* 1925 */     moment.momentProperties = momentProperties;
/* 1926 */ 
/* 1927 */     // This function will be called whenever a moment is mutated.
/* 1928 */     // It is intended to keep the offset in sync with the timezone.
/* 1929 */     moment.updateOffset = function () {};
/* 1930 */ 
/* 1931 */     // This function allows you to set a threshold for relative time strings
/* 1932 */     moment.relativeTimeThreshold = function (threshold, limit) {
/* 1933 */         if (relativeTimeThresholds[threshold] === undefined) {
/* 1934 */             return false;
/* 1935 */         }
/* 1936 */         if (limit === undefined) {
/* 1937 */             return relativeTimeThresholds[threshold];
/* 1938 */         }
/* 1939 */         relativeTimeThresholds[threshold] = limit;
/* 1940 */         return true;
/* 1941 */     };
/* 1942 */ 
/* 1943 */     moment.lang = deprecate(
/* 1944 */         'moment.lang is deprecated. Use moment.locale instead.',
/* 1945 */         function (key, value) {
/* 1946 */             return moment.locale(key, value);
/* 1947 */         }
/* 1948 */     );
/* 1949 */ 
/* 1950 */     // This function will load locale and then set the global locale.  If

/* moment.js */

/* 1951 */     // no arguments are passed in, it will simply return the current global
/* 1952 */     // locale key.
/* 1953 */     moment.locale = function (key, values) {
/* 1954 */         var data;
/* 1955 */         if (key) {
/* 1956 */             if (typeof(values) !== 'undefined') {
/* 1957 */                 data = moment.defineLocale(key, values);
/* 1958 */             }
/* 1959 */             else {
/* 1960 */                 data = moment.localeData(key);
/* 1961 */             }
/* 1962 */ 
/* 1963 */             if (data) {
/* 1964 */                 moment.duration._locale = moment._locale = data;
/* 1965 */             }
/* 1966 */         }
/* 1967 */ 
/* 1968 */         return moment._locale._abbr;
/* 1969 */     };
/* 1970 */ 
/* 1971 */     moment.defineLocale = function (name, values) {
/* 1972 */         if (values !== null) {
/* 1973 */             values.abbr = name;
/* 1974 */             if (!locales[name]) {
/* 1975 */                 locales[name] = new Locale();
/* 1976 */             }
/* 1977 */             locales[name].set(values);
/* 1978 */ 
/* 1979 */             // backwards compat for now: also set the locale
/* 1980 */             moment.locale(name);
/* 1981 */ 
/* 1982 */             return locales[name];
/* 1983 */         } else {
/* 1984 */             // useful for testing
/* 1985 */             delete locales[name];
/* 1986 */             return null;
/* 1987 */         }
/* 1988 */     };
/* 1989 */ 
/* 1990 */     moment.langData = deprecate(
/* 1991 */         'moment.langData is deprecated. Use moment.localeData instead.',
/* 1992 */         function (key) {
/* 1993 */             return moment.localeData(key);
/* 1994 */         }
/* 1995 */     );
/* 1996 */ 
/* 1997 */     // returns locale data
/* 1998 */     moment.localeData = function (key) {
/* 1999 */         var locale;
/* 2000 */ 

/* moment.js */

/* 2001 */         if (key && key._locale && key._locale._abbr) {
/* 2002 */             key = key._locale._abbr;
/* 2003 */         }
/* 2004 */ 
/* 2005 */         if (!key) {
/* 2006 */             return moment._locale;
/* 2007 */         }
/* 2008 */ 
/* 2009 */         if (!isArray(key)) {
/* 2010 */             //short-circuit everything else
/* 2011 */             locale = loadLocale(key);
/* 2012 */             if (locale) {
/* 2013 */                 return locale;
/* 2014 */             }
/* 2015 */             key = [key];
/* 2016 */         }
/* 2017 */ 
/* 2018 */         return chooseLocale(key);
/* 2019 */     };
/* 2020 */ 
/* 2021 */     // compare moment object
/* 2022 */     moment.isMoment = function (obj) {
/* 2023 */         return obj instanceof Moment ||
/* 2024 */             (obj != null && hasOwnProp(obj, '_isAMomentObject'));
/* 2025 */     };
/* 2026 */ 
/* 2027 */     // for typechecking Duration objects
/* 2028 */     moment.isDuration = function (obj) {
/* 2029 */         return obj instanceof Duration;
/* 2030 */     };
/* 2031 */ 
/* 2032 */     for (i = lists.length - 1; i >= 0; --i) {
/* 2033 */         makeList(lists[i]);
/* 2034 */     }
/* 2035 */ 
/* 2036 */     moment.normalizeUnits = function (units) {
/* 2037 */         return normalizeUnits(units);
/* 2038 */     };
/* 2039 */ 
/* 2040 */     moment.invalid = function (flags) {
/* 2041 */         var m = moment.utc(NaN);
/* 2042 */         if (flags != null) {
/* 2043 */             extend(m._pf, flags);
/* 2044 */         }
/* 2045 */         else {
/* 2046 */             m._pf.userInvalidated = true;
/* 2047 */         }
/* 2048 */ 
/* 2049 */         return m;
/* 2050 */     };

/* moment.js */

/* 2051 */ 
/* 2052 */     moment.parseZone = function () {
/* 2053 */         return moment.apply(null, arguments).parseZone();
/* 2054 */     };
/* 2055 */ 
/* 2056 */     moment.parseTwoDigitYear = function (input) {
/* 2057 */         return toInt(input) + (toInt(input) > 68 ? 1900 : 2000);
/* 2058 */     };
/* 2059 */ 
/* 2060 */     /************************************
/* 2061 *|         Moment Prototype
/* 2062 *|     ************************************/
/* 2063 */ 
/* 2064 */ 
/* 2065 */     extend(moment.fn = Moment.prototype, {
/* 2066 */ 
/* 2067 */         clone : function () {
/* 2068 */             return moment(this);
/* 2069 */         },
/* 2070 */ 
/* 2071 */         valueOf : function () {
/* 2072 */             return +this._d + ((this._offset || 0) * 60000);
/* 2073 */         },
/* 2074 */ 
/* 2075 */         unix : function () {
/* 2076 */             return Math.floor(+this / 1000);
/* 2077 */         },
/* 2078 */ 
/* 2079 */         toString : function () {
/* 2080 */             return this.clone().locale('en').format('ddd MMM DD YYYY HH:mm:ss [GMT]ZZ');
/* 2081 */         },
/* 2082 */ 
/* 2083 */         toDate : function () {
/* 2084 */             return this._offset ? new Date(+this) : this._d;
/* 2085 */         },
/* 2086 */ 
/* 2087 */         toISOString : function () {
/* 2088 */             var m = moment(this).utc();
/* 2089 */             if (0 < m.year() && m.year() <= 9999) {
/* 2090 */                 return formatMoment(m, 'YYYY-MM-DD[T]HH:mm:ss.SSS[Z]');
/* 2091 */             } else {
/* 2092 */                 return formatMoment(m, 'YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]');
/* 2093 */             }
/* 2094 */         },
/* 2095 */ 
/* 2096 */         toArray : function () {
/* 2097 */             var m = this;
/* 2098 */             return [
/* 2099 */                 m.year(),
/* 2100 */                 m.month(),

/* moment.js */

/* 2101 */                 m.date(),
/* 2102 */                 m.hours(),
/* 2103 */                 m.minutes(),
/* 2104 */                 m.seconds(),
/* 2105 */                 m.milliseconds()
/* 2106 */             ];
/* 2107 */         },
/* 2108 */ 
/* 2109 */         isValid : function () {
/* 2110 */             return isValid(this);
/* 2111 */         },
/* 2112 */ 
/* 2113 */         isDSTShifted : function () {
/* 2114 */             if (this._a) {
/* 2115 */                 return this.isValid() && compareArrays(this._a, (this._isUTC ? moment.utc(this._a) : moment(this._a)).toArray()) > 0;
/* 2116 */             }
/* 2117 */ 
/* 2118 */             return false;
/* 2119 */         },
/* 2120 */ 
/* 2121 */         parsingFlags : function () {
/* 2122 */             return extend({}, this._pf);
/* 2123 */         },
/* 2124 */ 
/* 2125 */         invalidAt: function () {
/* 2126 */             return this._pf.overflow;
/* 2127 */         },
/* 2128 */ 
/* 2129 */         utc : function (keepLocalTime) {
/* 2130 */             return this.zone(0, keepLocalTime);
/* 2131 */         },
/* 2132 */ 
/* 2133 */         local : function (keepLocalTime) {
/* 2134 */             if (this._isUTC) {
/* 2135 */                 this.zone(0, keepLocalTime);
/* 2136 */                 this._isUTC = false;
/* 2137 */ 
/* 2138 */                 if (keepLocalTime) {
/* 2139 */                     this.add(this._dateTzOffset(), 'm');
/* 2140 */                 }
/* 2141 */             }
/* 2142 */             return this;
/* 2143 */         },
/* 2144 */ 
/* 2145 */         format : function (inputString) {
/* 2146 */             var output = formatMoment(this, inputString || moment.defaultFormat);
/* 2147 */             return this.localeData().postformat(output);
/* 2148 */         },
/* 2149 */ 
/* 2150 */         add : createAdder(1, 'add'),

/* moment.js */

/* 2151 */ 
/* 2152 */         subtract : createAdder(-1, 'subtract'),
/* 2153 */ 
/* 2154 */         diff : function (input, units, asFloat) {
/* 2155 */             var that = makeAs(input, this),
/* 2156 */                 zoneDiff = (this.zone() - that.zone()) * 6e4,
/* 2157 */                 diff, output, daysAdjust;
/* 2158 */ 
/* 2159 */             units = normalizeUnits(units);
/* 2160 */ 
/* 2161 */             if (units === 'year' || units === 'month') {
/* 2162 */                 // average number of days in the months in the given dates
/* 2163 */                 diff = (this.daysInMonth() + that.daysInMonth()) * 432e5; // 24 * 60 * 60 * 1000 / 2
/* 2164 */                 // difference in months
/* 2165 */                 output = ((this.year() - that.year()) * 12) + (this.month() - that.month());
/* 2166 */                 // adjust by taking difference in days, average number of days
/* 2167 */                 // and dst in the given months.
/* 2168 */                 daysAdjust = (this - moment(this).startOf('month')) -
/* 2169 */                     (that - moment(that).startOf('month'));
/* 2170 */                 // same as above but with zones, to negate all dst
/* 2171 */                 daysAdjust -= ((this.zone() - moment(this).startOf('month').zone()) -
/* 2172 */                         (that.zone() - moment(that).startOf('month').zone())) * 6e4;
/* 2173 */                 output += daysAdjust / diff;
/* 2174 */                 if (units === 'year') {
/* 2175 */                     output = output / 12;
/* 2176 */                 }
/* 2177 */             } else {
/* 2178 */                 diff = (this - that);
/* 2179 */                 output = units === 'second' ? diff / 1e3 : // 1000
/* 2180 */                     units === 'minute' ? diff / 6e4 : // 1000 * 60
/* 2181 */                     units === 'hour' ? diff / 36e5 : // 1000 * 60 * 60
/* 2182 */                     units === 'day' ? (diff - zoneDiff) / 864e5 : // 1000 * 60 * 60 * 24, negate dst
/* 2183 */                     units === 'week' ? (diff - zoneDiff) / 6048e5 : // 1000 * 60 * 60 * 24 * 7, negate dst
/* 2184 */                     diff;
/* 2185 */             }
/* 2186 */             return asFloat ? output : absRound(output);
/* 2187 */         },
/* 2188 */ 
/* 2189 */         from : function (time, withoutSuffix) {
/* 2190 */             return moment.duration({to: this, from: time}).locale(this.locale()).humanize(!withoutSuffix);
/* 2191 */         },
/* 2192 */ 
/* 2193 */         fromNow : function (withoutSuffix) {
/* 2194 */             return this.from(moment(), withoutSuffix);
/* 2195 */         },
/* 2196 */ 
/* 2197 */         calendar : function (time) {
/* 2198 */             // We want to compare the start of today, vs this.
/* 2199 */             // Getting start-of-today depends on whether we're zone'd or not.
/* 2200 */             var now = time || moment(),

/* moment.js */

/* 2201 */                 sod = makeAs(now, this).startOf('day'),
/* 2202 */                 diff = this.diff(sod, 'days', true),
/* 2203 */                 format = diff < -6 ? 'sameElse' :
/* 2204 */                     diff < -1 ? 'lastWeek' :
/* 2205 */                     diff < 0 ? 'lastDay' :
/* 2206 */                     diff < 1 ? 'sameDay' :
/* 2207 */                     diff < 2 ? 'nextDay' :
/* 2208 */                     diff < 7 ? 'nextWeek' : 'sameElse';
/* 2209 */             return this.format(this.localeData().calendar(format, this));
/* 2210 */         },
/* 2211 */ 
/* 2212 */         isLeapYear : function () {
/* 2213 */             return isLeapYear(this.year());
/* 2214 */         },
/* 2215 */ 
/* 2216 */         isDST : function () {
/* 2217 */             return (this.zone() < this.clone().month(0).zone() ||
/* 2218 */                 this.zone() < this.clone().month(5).zone());
/* 2219 */         },
/* 2220 */ 
/* 2221 */         day : function (input) {
/* 2222 */             var day = this._isUTC ? this._d.getUTCDay() : this._d.getDay();
/* 2223 */             if (input != null) {
/* 2224 */                 input = parseWeekday(input, this.localeData());
/* 2225 */                 return this.add(input - day, 'd');
/* 2226 */             } else {
/* 2227 */                 return day;
/* 2228 */             }
/* 2229 */         },
/* 2230 */ 
/* 2231 */         month : makeAccessor('Month', true),
/* 2232 */ 
/* 2233 */         startOf : function (units) {
/* 2234 */             units = normalizeUnits(units);
/* 2235 */             // the following switch intentionally omits break keywords
/* 2236 */             // to utilize falling through the cases.
/* 2237 */             switch (units) {
/* 2238 */             case 'year':
/* 2239 */                 this.month(0);
/* 2240 */                 /* falls through */
/* 2241 */             case 'quarter':
/* 2242 */             case 'month':
/* 2243 */                 this.date(1);
/* 2244 */                 /* falls through */
/* 2245 */             case 'week':
/* 2246 */             case 'isoWeek':
/* 2247 */             case 'day':
/* 2248 */                 this.hours(0);
/* 2249 */                 /* falls through */
/* 2250 */             case 'hour':

/* moment.js */

/* 2251 */                 this.minutes(0);
/* 2252 */                 /* falls through */
/* 2253 */             case 'minute':
/* 2254 */                 this.seconds(0);
/* 2255 */                 /* falls through */
/* 2256 */             case 'second':
/* 2257 */                 this.milliseconds(0);
/* 2258 */                 /* falls through */
/* 2259 */             }
/* 2260 */ 
/* 2261 */             // weeks are a special case
/* 2262 */             if (units === 'week') {
/* 2263 */                 this.weekday(0);
/* 2264 */             } else if (units === 'isoWeek') {
/* 2265 */                 this.isoWeekday(1);
/* 2266 */             }
/* 2267 */ 
/* 2268 */             // quarters are also special
/* 2269 */             if (units === 'quarter') {
/* 2270 */                 this.month(Math.floor(this.month() / 3) * 3);
/* 2271 */             }
/* 2272 */ 
/* 2273 */             return this;
/* 2274 */         },
/* 2275 */ 
/* 2276 */         endOf: function (units) {
/* 2277 */             units = normalizeUnits(units);
/* 2278 */             return this.startOf(units).add(1, (units === 'isoWeek' ? 'week' : units)).subtract(1, 'ms');
/* 2279 */         },
/* 2280 */ 
/* 2281 */         isAfter: function (input, units) {
/* 2282 */             units = normalizeUnits(typeof units !== 'undefined' ? units : 'millisecond');
/* 2283 */             if (units === 'millisecond') {
/* 2284 */                 input = moment.isMoment(input) ? input : moment(input);
/* 2285 */                 return +this > +input;
/* 2286 */             } else {
/* 2287 */                 return +this.clone().startOf(units) > +moment(input).startOf(units);
/* 2288 */             }
/* 2289 */         },
/* 2290 */ 
/* 2291 */         isBefore: function (input, units) {
/* 2292 */             units = normalizeUnits(typeof units !== 'undefined' ? units : 'millisecond');
/* 2293 */             if (units === 'millisecond') {
/* 2294 */                 input = moment.isMoment(input) ? input : moment(input);
/* 2295 */                 return +this < +input;
/* 2296 */             } else {
/* 2297 */                 return +this.clone().startOf(units) < +moment(input).startOf(units);
/* 2298 */             }
/* 2299 */         },
/* 2300 */ 

/* moment.js */

/* 2301 */         isSame: function (input, units) {
/* 2302 */             units = normalizeUnits(units || 'millisecond');
/* 2303 */             if (units === 'millisecond') {
/* 2304 */                 input = moment.isMoment(input) ? input : moment(input);
/* 2305 */                 return +this === +input;
/* 2306 */             } else {
/* 2307 */                 return +this.clone().startOf(units) === +makeAs(input, this).startOf(units);
/* 2308 */             }
/* 2309 */         },
/* 2310 */ 
/* 2311 */         min: deprecate(
/* 2312 */                  'moment().min is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548',
/* 2313 */                  function (other) {
/* 2314 */                      other = moment.apply(null, arguments);
/* 2315 */                      return other < this ? this : other;
/* 2316 */                  }
/* 2317 */          ),
/* 2318 */ 
/* 2319 */         max: deprecate(
/* 2320 */                 'moment().max is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548',
/* 2321 */                 function (other) {
/* 2322 */                     other = moment.apply(null, arguments);
/* 2323 */                     return other > this ? this : other;
/* 2324 */                 }
/* 2325 */         ),
/* 2326 */ 
/* 2327 */         // keepLocalTime = true means only change the timezone, without
/* 2328 */         // affecting the local hour. So 5:31:26 +0300 --[zone(2, true)]-->
/* 2329 */         // 5:31:26 +0200 It is possible that 5:31:26 doesn't exist int zone
/* 2330 */         // +0200, so we adjust the time as needed, to be valid.
/* 2331 */         //
/* 2332 */         // Keeping the time actually adds/subtracts (one hour)
/* 2333 */         // from the actual represented time. That is why we call updateOffset
/* 2334 */         // a second time. In case it wants us to change the offset again
/* 2335 */         // _changeInProgress == true case, then we have to adjust, because
/* 2336 */         // there is no such time in the given timezone.
/* 2337 */         zone : function (input, keepLocalTime) {
/* 2338 */             var offset = this._offset || 0,
/* 2339 */                 localAdjust;
/* 2340 */             if (input != null) {
/* 2341 */                 if (typeof input === 'string') {
/* 2342 */                     input = timezoneMinutesFromString(input);
/* 2343 */                 }
/* 2344 */                 if (Math.abs(input) < 16) {
/* 2345 */                     input = input * 60;
/* 2346 */                 }
/* 2347 */                 if (!this._isUTC && keepLocalTime) {
/* 2348 */                     localAdjust = this._dateTzOffset();
/* 2349 */                 }
/* 2350 */                 this._offset = input;

/* moment.js */

/* 2351 */                 this._isUTC = true;
/* 2352 */                 if (localAdjust != null) {
/* 2353 */                     this.subtract(localAdjust, 'm');
/* 2354 */                 }
/* 2355 */                 if (offset !== input) {
/* 2356 */                     if (!keepLocalTime || this._changeInProgress) {
/* 2357 */                         addOrSubtractDurationFromMoment(this,
/* 2358 */                                 moment.duration(offset - input, 'm'), 1, false);
/* 2359 */                     } else if (!this._changeInProgress) {
/* 2360 */                         this._changeInProgress = true;
/* 2361 */                         moment.updateOffset(this, true);
/* 2362 */                         this._changeInProgress = null;
/* 2363 */                     }
/* 2364 */                 }
/* 2365 */             } else {
/* 2366 */                 return this._isUTC ? offset : this._dateTzOffset();
/* 2367 */             }
/* 2368 */             return this;
/* 2369 */         },
/* 2370 */ 
/* 2371 */         zoneAbbr : function () {
/* 2372 */             return this._isUTC ? 'UTC' : '';
/* 2373 */         },
/* 2374 */ 
/* 2375 */         zoneName : function () {
/* 2376 */             return this._isUTC ? 'Coordinated Universal Time' : '';
/* 2377 */         },
/* 2378 */ 
/* 2379 */         parseZone : function () {
/* 2380 */             if (this._tzm) {
/* 2381 */                 this.zone(this._tzm);
/* 2382 */             } else if (typeof this._i === 'string') {
/* 2383 */                 this.zone(this._i);
/* 2384 */             }
/* 2385 */             return this;
/* 2386 */         },
/* 2387 */ 
/* 2388 */         hasAlignedHourOffset : function (input) {
/* 2389 */             if (!input) {
/* 2390 */                 input = 0;
/* 2391 */             }
/* 2392 */             else {
/* 2393 */                 input = moment(input).zone();
/* 2394 */             }
/* 2395 */ 
/* 2396 */             return (this.zone() - input) % 60 === 0;
/* 2397 */         },
/* 2398 */ 
/* 2399 */         daysInMonth : function () {
/* 2400 */             return daysInMonth(this.year(), this.month());

/* moment.js */

/* 2401 */         },
/* 2402 */ 
/* 2403 */         dayOfYear : function (input) {
/* 2404 */             var dayOfYear = round((moment(this).startOf('day') - moment(this).startOf('year')) / 864e5) + 1;
/* 2405 */             return input == null ? dayOfYear : this.add((input - dayOfYear), 'd');
/* 2406 */         },
/* 2407 */ 
/* 2408 */         quarter : function (input) {
/* 2409 */             return input == null ? Math.ceil((this.month() + 1) / 3) : this.month((input - 1) * 3 + this.month() % 3);
/* 2410 */         },
/* 2411 */ 
/* 2412 */         weekYear : function (input) {
/* 2413 */             var year = weekOfYear(this, this.localeData()._week.dow, this.localeData()._week.doy).year;
/* 2414 */             return input == null ? year : this.add((input - year), 'y');
/* 2415 */         },
/* 2416 */ 
/* 2417 */         isoWeekYear : function (input) {
/* 2418 */             var year = weekOfYear(this, 1, 4).year;
/* 2419 */             return input == null ? year : this.add((input - year), 'y');
/* 2420 */         },
/* 2421 */ 
/* 2422 */         week : function (input) {
/* 2423 */             var week = this.localeData().week(this);
/* 2424 */             return input == null ? week : this.add((input - week) * 7, 'd');
/* 2425 */         },
/* 2426 */ 
/* 2427 */         isoWeek : function (input) {
/* 2428 */             var week = weekOfYear(this, 1, 4).week;
/* 2429 */             return input == null ? week : this.add((input - week) * 7, 'd');
/* 2430 */         },
/* 2431 */ 
/* 2432 */         weekday : function (input) {
/* 2433 */             var weekday = (this.day() + 7 - this.localeData()._week.dow) % 7;
/* 2434 */             return input == null ? weekday : this.add(input - weekday, 'd');
/* 2435 */         },
/* 2436 */ 
/* 2437 */         isoWeekday : function (input) {
/* 2438 */             // behaves the same as moment#day except
/* 2439 */             // as a getter, returns 7 instead of 0 (1-7 range instead of 0-6)
/* 2440 */             // as a setter, sunday should belong to the previous week.
/* 2441 */             return input == null ? this.day() || 7 : this.day(this.day() % 7 ? input : input - 7);
/* 2442 */         },
/* 2443 */ 
/* 2444 */         isoWeeksInYear : function () {
/* 2445 */             return weeksInYear(this.year(), 1, 4);
/* 2446 */         },
/* 2447 */ 
/* 2448 */         weeksInYear : function () {
/* 2449 */             var weekInfo = this.localeData()._week;
/* 2450 */             return weeksInYear(this.year(), weekInfo.dow, weekInfo.doy);

/* moment.js */

/* 2451 */         },
/* 2452 */ 
/* 2453 */         get : function (units) {
/* 2454 */             units = normalizeUnits(units);
/* 2455 */             return this[units]();
/* 2456 */         },
/* 2457 */ 
/* 2458 */         set : function (units, value) {
/* 2459 */             units = normalizeUnits(units);
/* 2460 */             if (typeof this[units] === 'function') {
/* 2461 */                 this[units](value);
/* 2462 */             }
/* 2463 */             return this;
/* 2464 */         },
/* 2465 */ 
/* 2466 */         // If passed a locale key, it will set the locale for this
/* 2467 */         // instance.  Otherwise, it will return the locale configuration
/* 2468 */         // variables for this instance.
/* 2469 */         locale : function (key) {
/* 2470 */             var newLocaleData;
/* 2471 */ 
/* 2472 */             if (key === undefined) {
/* 2473 */                 return this._locale._abbr;
/* 2474 */             } else {
/* 2475 */                 newLocaleData = moment.localeData(key);
/* 2476 */                 if (newLocaleData != null) {
/* 2477 */                     this._locale = newLocaleData;
/* 2478 */                 }
/* 2479 */                 return this;
/* 2480 */             }
/* 2481 */         },
/* 2482 */ 
/* 2483 */         lang : deprecate(
/* 2484 */             'moment().lang() is deprecated. Use moment().localeData() instead.',
/* 2485 */             function (key) {
/* 2486 */                 if (key === undefined) {
/* 2487 */                     return this.localeData();
/* 2488 */                 } else {
/* 2489 */                     return this.locale(key);
/* 2490 */                 }
/* 2491 */             }
/* 2492 */         ),
/* 2493 */ 
/* 2494 */         localeData : function () {
/* 2495 */             return this._locale;
/* 2496 */         },
/* 2497 */ 
/* 2498 */         _dateTzOffset : function () {
/* 2499 */             // On Firefox.24 Date#getTimezoneOffset returns a floating point.
/* 2500 */             // https://github.com/moment/moment/pull/1871

/* moment.js */

/* 2501 */             return Math.round(this._d.getTimezoneOffset() / 15) * 15;
/* 2502 */         }
/* 2503 */     });
/* 2504 */ 
/* 2505 */     function rawMonthSetter(mom, value) {
/* 2506 */         var dayOfMonth;
/* 2507 */ 
/* 2508 */         // TODO: Move this out of here!
/* 2509 */         if (typeof value === 'string') {
/* 2510 */             value = mom.localeData().monthsParse(value);
/* 2511 */             // TODO: Another silent failure?
/* 2512 */             if (typeof value !== 'number') {
/* 2513 */                 return mom;
/* 2514 */             }
/* 2515 */         }
/* 2516 */ 
/* 2517 */         dayOfMonth = Math.min(mom.date(),
/* 2518 */                 daysInMonth(mom.year(), value));
/* 2519 */         mom._d['set' + (mom._isUTC ? 'UTC' : '') + 'Month'](value, dayOfMonth);
/* 2520 */         return mom;
/* 2521 */     }
/* 2522 */ 
/* 2523 */     function rawGetter(mom, unit) {
/* 2524 */         return mom._d['get' + (mom._isUTC ? 'UTC' : '') + unit]();
/* 2525 */     }
/* 2526 */ 
/* 2527 */     function rawSetter(mom, unit, value) {
/* 2528 */         if (unit === 'Month') {
/* 2529 */             return rawMonthSetter(mom, value);
/* 2530 */         } else {
/* 2531 */             return mom._d['set' + (mom._isUTC ? 'UTC' : '') + unit](value);
/* 2532 */         }
/* 2533 */     }
/* 2534 */ 
/* 2535 */     function makeAccessor(unit, keepTime) {
/* 2536 */         return function (value) {
/* 2537 */             if (value != null) {
/* 2538 */                 rawSetter(this, unit, value);
/* 2539 */                 moment.updateOffset(this, keepTime);
/* 2540 */                 return this;
/* 2541 */             } else {
/* 2542 */                 return rawGetter(this, unit);
/* 2543 */             }
/* 2544 */         };
/* 2545 */     }
/* 2546 */ 
/* 2547 */     moment.fn.millisecond = moment.fn.milliseconds = makeAccessor('Milliseconds', false);
/* 2548 */     moment.fn.second = moment.fn.seconds = makeAccessor('Seconds', false);
/* 2549 */     moment.fn.minute = moment.fn.minutes = makeAccessor('Minutes', false);
/* 2550 */     // Setting the hour should keep the time, because the user explicitly

/* moment.js */

/* 2551 */     // specified which hour he wants. So trying to maintain the same hour (in
/* 2552 */     // a new timezone) makes sense. Adding/subtracting hours does not follow
/* 2553 */     // this rule.
/* 2554 */     moment.fn.hour = moment.fn.hours = makeAccessor('Hours', true);
/* 2555 */     // moment.fn.month is defined separately
/* 2556 */     moment.fn.date = makeAccessor('Date', true);
/* 2557 */     moment.fn.dates = deprecate('dates accessor is deprecated. Use date instead.', makeAccessor('Date', true));
/* 2558 */     moment.fn.year = makeAccessor('FullYear', true);
/* 2559 */     moment.fn.years = deprecate('years accessor is deprecated. Use year instead.', makeAccessor('FullYear', true));
/* 2560 */ 
/* 2561 */     // add plural methods
/* 2562 */     moment.fn.days = moment.fn.day;
/* 2563 */     moment.fn.months = moment.fn.month;
/* 2564 */     moment.fn.weeks = moment.fn.week;
/* 2565 */     moment.fn.isoWeeks = moment.fn.isoWeek;
/* 2566 */     moment.fn.quarters = moment.fn.quarter;
/* 2567 */ 
/* 2568 */     // add aliased format methods
/* 2569 */     moment.fn.toJSON = moment.fn.toISOString;
/* 2570 */ 
/* 2571 */     /************************************
/* 2572 *|         Duration Prototype
/* 2573 *|     ************************************/
/* 2574 */ 
/* 2575 */ 
/* 2576 */     function daysToYears (days) {
/* 2577 */         // 400 years have 146097 days (taking into account leap year rules)
/* 2578 */         return days * 400 / 146097;
/* 2579 */     }
/* 2580 */ 
/* 2581 */     function yearsToDays (years) {
/* 2582 */         // years * 365 + absRound(years / 4) -
/* 2583 */         //     absRound(years / 100) + absRound(years / 400);
/* 2584 */         return years * 146097 / 400;
/* 2585 */     }
/* 2586 */ 
/* 2587 */     extend(moment.duration.fn = Duration.prototype, {
/* 2588 */ 
/* 2589 */         _bubble : function () {
/* 2590 */             var milliseconds = this._milliseconds,
/* 2591 */                 days = this._days,
/* 2592 */                 months = this._months,
/* 2593 */                 data = this._data,
/* 2594 */                 seconds, minutes, hours, years = 0;
/* 2595 */ 
/* 2596 */             // The following code bubbles up values, see the tests for
/* 2597 */             // examples of what that means.
/* 2598 */             data.milliseconds = milliseconds % 1000;
/* 2599 */ 
/* 2600 */             seconds = absRound(milliseconds / 1000);

/* moment.js */

/* 2601 */             data.seconds = seconds % 60;
/* 2602 */ 
/* 2603 */             minutes = absRound(seconds / 60);
/* 2604 */             data.minutes = minutes % 60;
/* 2605 */ 
/* 2606 */             hours = absRound(minutes / 60);
/* 2607 */             data.hours = hours % 24;
/* 2608 */ 
/* 2609 */             days += absRound(hours / 24);
/* 2610 */ 
/* 2611 */             // Accurately convert days to years, assume start from year 0.
/* 2612 */             years = absRound(daysToYears(days));
/* 2613 */             days -= absRound(yearsToDays(years));
/* 2614 */ 
/* 2615 */             // 30 days to a month
/* 2616 */             // TODO (iskren): Use anchor date (like 1st Jan) to compute this.
/* 2617 */             months += absRound(days / 30);
/* 2618 */             days %= 30;
/* 2619 */ 
/* 2620 */             // 12 months -> 1 year
/* 2621 */             years += absRound(months / 12);
/* 2622 */             months %= 12;
/* 2623 */ 
/* 2624 */             data.days = days;
/* 2625 */             data.months = months;
/* 2626 */             data.years = years;
/* 2627 */         },
/* 2628 */ 
/* 2629 */         abs : function () {
/* 2630 */             this._milliseconds = Math.abs(this._milliseconds);
/* 2631 */             this._days = Math.abs(this._days);
/* 2632 */             this._months = Math.abs(this._months);
/* 2633 */ 
/* 2634 */             this._data.milliseconds = Math.abs(this._data.milliseconds);
/* 2635 */             this._data.seconds = Math.abs(this._data.seconds);
/* 2636 */             this._data.minutes = Math.abs(this._data.minutes);
/* 2637 */             this._data.hours = Math.abs(this._data.hours);
/* 2638 */             this._data.months = Math.abs(this._data.months);
/* 2639 */             this._data.years = Math.abs(this._data.years);
/* 2640 */ 
/* 2641 */             return this;
/* 2642 */         },
/* 2643 */ 
/* 2644 */         weeks : function () {
/* 2645 */             return absRound(this.days() / 7);
/* 2646 */         },
/* 2647 */ 
/* 2648 */         valueOf : function () {
/* 2649 */             return this._milliseconds +
/* 2650 */               this._days * 864e5 +

/* moment.js */

/* 2651 */               (this._months % 12) * 2592e6 +
/* 2652 */               toInt(this._months / 12) * 31536e6;
/* 2653 */         },
/* 2654 */ 
/* 2655 */         humanize : function (withSuffix) {
/* 2656 */             var output = relativeTime(this, !withSuffix, this.localeData());
/* 2657 */ 
/* 2658 */             if (withSuffix) {
/* 2659 */                 output = this.localeData().pastFuture(+this, output);
/* 2660 */             }
/* 2661 */ 
/* 2662 */             return this.localeData().postformat(output);
/* 2663 */         },
/* 2664 */ 
/* 2665 */         add : function (input, val) {
/* 2666 */             // supports only 2.0-style add(1, 's') or add(moment)
/* 2667 */             var dur = moment.duration(input, val);
/* 2668 */ 
/* 2669 */             this._milliseconds += dur._milliseconds;
/* 2670 */             this._days += dur._days;
/* 2671 */             this._months += dur._months;
/* 2672 */ 
/* 2673 */             this._bubble();
/* 2674 */ 
/* 2675 */             return this;
/* 2676 */         },
/* 2677 */ 
/* 2678 */         subtract : function (input, val) {
/* 2679 */             var dur = moment.duration(input, val);
/* 2680 */ 
/* 2681 */             this._milliseconds -= dur._milliseconds;
/* 2682 */             this._days -= dur._days;
/* 2683 */             this._months -= dur._months;
/* 2684 */ 
/* 2685 */             this._bubble();
/* 2686 */ 
/* 2687 */             return this;
/* 2688 */         },
/* 2689 */ 
/* 2690 */         get : function (units) {
/* 2691 */             units = normalizeUnits(units);
/* 2692 */             return this[units.toLowerCase() + 's']();
/* 2693 */         },
/* 2694 */ 
/* 2695 */         as : function (units) {
/* 2696 */             var days, months;
/* 2697 */             units = normalizeUnits(units);
/* 2698 */ 
/* 2699 */             if (units === 'month' || units === 'year') {
/* 2700 */                 days = this._days + this._milliseconds / 864e5;

/* moment.js */

/* 2701 */                 months = this._months + daysToYears(days) * 12;
/* 2702 */                 return units === 'month' ? months : months / 12;
/* 2703 */             } else {
/* 2704 */                 // handle milliseconds separately because of floating point math errors (issue #1867)
/* 2705 */                 days = this._days + yearsToDays(this._months / 12);
/* 2706 */                 switch (units) {
/* 2707 */                     case 'week': return days / 7 + this._milliseconds / 6048e5;
/* 2708 */                     case 'day': return days + this._milliseconds / 864e5;
/* 2709 */                     case 'hour': return days * 24 + this._milliseconds / 36e5;
/* 2710 */                     case 'minute': return days * 24 * 60 + this._milliseconds / 6e4;
/* 2711 */                     case 'second': return days * 24 * 60 * 60 + this._milliseconds / 1000;
/* 2712 */                     // Math.floor prevents floating point math errors here
/* 2713 */                     case 'millisecond': return Math.floor(days * 24 * 60 * 60 * 1000) + this._milliseconds;
/* 2714 */                     default: throw new Error('Unknown unit ' + units);
/* 2715 */                 }
/* 2716 */             }
/* 2717 */         },
/* 2718 */ 
/* 2719 */         lang : moment.fn.lang,
/* 2720 */         locale : moment.fn.locale,
/* 2721 */ 
/* 2722 */         toIsoString : deprecate(
/* 2723 */             'toIsoString() is deprecated. Please use toISOString() instead ' +
/* 2724 */             '(notice the capitals)',
/* 2725 */             function () {
/* 2726 */                 return this.toISOString();
/* 2727 */             }
/* 2728 */         ),
/* 2729 */ 
/* 2730 */         toISOString : function () {
/* 2731 */             // inspired by https://github.com/dordille/moment-isoduration/blob/master/moment.isoduration.js
/* 2732 */             var years = Math.abs(this.years()),
/* 2733 */                 months = Math.abs(this.months()),
/* 2734 */                 days = Math.abs(this.days()),
/* 2735 */                 hours = Math.abs(this.hours()),
/* 2736 */                 minutes = Math.abs(this.minutes()),
/* 2737 */                 seconds = Math.abs(this.seconds() + this.milliseconds() / 1000);
/* 2738 */ 
/* 2739 */             if (!this.asSeconds()) {
/* 2740 */                 // this is the same as C#'s (Noda) and python (isodate)...
/* 2741 */                 // but not other JS (goog.date)
/* 2742 */                 return 'P0D';
/* 2743 */             }
/* 2744 */ 
/* 2745 */             return (this.asSeconds() < 0 ? '-' : '') +
/* 2746 */                 'P' +
/* 2747 */                 (years ? years + 'Y' : '') +
/* 2748 */                 (months ? months + 'M' : '') +
/* 2749 */                 (days ? days + 'D' : '') +
/* 2750 */                 ((hours || minutes || seconds) ? 'T' : '') +

/* moment.js */

/* 2751 */                 (hours ? hours + 'H' : '') +
/* 2752 */                 (minutes ? minutes + 'M' : '') +
/* 2753 */                 (seconds ? seconds + 'S' : '');
/* 2754 */         },
/* 2755 */ 
/* 2756 */         localeData : function () {
/* 2757 */             return this._locale;
/* 2758 */         }
/* 2759 */     });
/* 2760 */ 
/* 2761 */     moment.duration.fn.toString = moment.duration.fn.toISOString;
/* 2762 */ 
/* 2763 */     function makeDurationGetter(name) {
/* 2764 */         moment.duration.fn[name] = function () {
/* 2765 */             return this._data[name];
/* 2766 */         };
/* 2767 */     }
/* 2768 */ 
/* 2769 */     for (i in unitMillisecondFactors) {
/* 2770 */         if (hasOwnProp(unitMillisecondFactors, i)) {
/* 2771 */             makeDurationGetter(i.toLowerCase());
/* 2772 */         }
/* 2773 */     }
/* 2774 */ 
/* 2775 */     moment.duration.fn.asMilliseconds = function () {
/* 2776 */         return this.as('ms');
/* 2777 */     };
/* 2778 */     moment.duration.fn.asSeconds = function () {
/* 2779 */         return this.as('s');
/* 2780 */     };
/* 2781 */     moment.duration.fn.asMinutes = function () {
/* 2782 */         return this.as('m');
/* 2783 */     };
/* 2784 */     moment.duration.fn.asHours = function () {
/* 2785 */         return this.as('h');
/* 2786 */     };
/* 2787 */     moment.duration.fn.asDays = function () {
/* 2788 */         return this.as('d');
/* 2789 */     };
/* 2790 */     moment.duration.fn.asWeeks = function () {
/* 2791 */         return this.as('weeks');
/* 2792 */     };
/* 2793 */     moment.duration.fn.asMonths = function () {
/* 2794 */         return this.as('M');
/* 2795 */     };
/* 2796 */     moment.duration.fn.asYears = function () {
/* 2797 */         return this.as('y');
/* 2798 */     };
/* 2799 */ 
/* 2800 */     /************************************

/* moment.js */

/* 2801 *|         Default Locale
/* 2802 *|     ************************************/
/* 2803 */ 
/* 2804 */ 
/* 2805 */     // Set default locale, other locale will inherit from English.
/* 2806 */     moment.locale('en', {
/* 2807 */         ordinal : function (number) {
/* 2808 */             var b = number % 10,
/* 2809 */                 output = (toInt(number % 100 / 10) === 1) ? 'th' :
/* 2810 */                 (b === 1) ? 'st' :
/* 2811 */                 (b === 2) ? 'nd' :
/* 2812 */                 (b === 3) ? 'rd' : 'th';
/* 2813 */             return number + output;
/* 2814 */         }
/* 2815 */     });
/* 2816 */ 
/* 2817 */     /* EMBED_LOCALES */
/* 2818 */ 
/* 2819 */     /************************************
/* 2820 *|         Exposing Moment
/* 2821 *|     ************************************/
/* 2822 */ 
/* 2823 */     function makeGlobal(shouldDeprecate) {
/* 2824 */         /*global ender:false */
/* 2825 */         if (typeof ender !== 'undefined') {
/* 2826 */             return;
/* 2827 */         }
/* 2828 */         oldGlobalMoment = globalScope.moment;
/* 2829 */         if (shouldDeprecate) {
/* 2830 */             globalScope.moment = deprecate(
/* 2831 */                     'Accessing Moment through the global scope is ' +
/* 2832 */                     'deprecated, and will be removed in an upcoming ' +
/* 2833 */                     'release.',
/* 2834 */                     moment);
/* 2835 */         } else {
/* 2836 */             globalScope.moment = moment;
/* 2837 */         }
/* 2838 */     }
/* 2839 */ 
/* 2840 */     // CommonJS module is defined
/* 2841 */     if (hasModule) {
/* 2842 */         module.exports = moment;
/* 2843 */     } else if (typeof define === 'function' && define.amd) {
/* 2844 */         define('moment', function (require, exports, module) {
/* 2845 */             if (module.config && module.config() && module.config().noGlobal === true) {
/* 2846 */                 // release the global variable
/* 2847 */                 globalScope.moment = oldGlobalMoment;
/* 2848 */             }
/* 2849 */ 
/* 2850 */             return moment;

/* moment.js */

/* 2851 */         });
/* 2852 */         makeGlobal(true);
/* 2853 */     } else {
/* 2854 */         makeGlobal();
/* 2855 */     }
/* 2856 */ }).call(this);
/* 2857 */ 

;
/* bootstrap-datetimepicker.min.js */

/* 1 */ !function(a,b){"use strict";if("function"==typeof define&&define.amd)define(["jquery","moment"],b);else if("object"==typeof exports)b(require("jquery"),require("moment"));else{if(!jQuery)throw new Error("bootstrap-datetimepicker requires jQuery to be loaded first");if(!moment)throw new Error("bootstrap-datetimepicker requires moment.js to be loaded first");b(a.jQuery,moment)}}(this,function(a,b){"use strict";if("undefined"==typeof b)throw new Error("momentjs is required");var c=0,d=function(d,e){var f,g=a.fn.datetimepicker.defaults,h={time:"glyphicon glyphicon-time",date:"glyphicon glyphicon-calendar",up:"glyphicon glyphicon-chevron-up",down:"glyphicon glyphicon-chevron-down"},i=this,j=!1,k=function(){var f,j,k=!1;if(i.options=a.extend({},g,e),i.options.icons=a.extend({},h,i.options.icons),i.element=a(d),m(),!i.options.pickTime&&!i.options.pickDate)throw new Error("Must choose at least one picker");if(i.id=c++,b.locale(i.options.language),i.date=b(),i.unset=!1,i.isInput=i.element.is("input"),i.component=!1,i.element.hasClass("input-group")&&(i.component=i.element.find(0===i.element.find(".datepickerbutton").size()?'[class^="input-group-"]':".datepickerbutton")),i.format=i.options.format,f=b().localeData(),i.format||(i.format=i.options.pickDate?f.longDateFormat("L"):"",i.options.pickDate&&i.options.pickTime&&(i.format+=" "),i.format+=i.options.pickTime?f.longDateFormat("LT"):"",i.options.useSeconds&&(-1!==f.longDateFormat("LT").indexOf(" A")?i.format=i.format.split(" A")[0]+":ss A":i.format+=":ss")),i.use24hours=i.format.toLowerCase().indexOf("a")<0&&i.format.indexOf("h")<0,i.component&&(k=i.component.find("span")),i.options.pickTime&&k&&k.addClass(i.options.icons.time),i.options.pickDate&&k&&(k.removeClass(i.options.icons.time),k.addClass(i.options.icons.date)),i.options.widgetParent="string"==typeof i.options.widgetParent&&i.options.widgetParent||i.element.parents().filter(function(){return"scroll"===a(this).css("overflow-y")}).get(0)||"body",i.widget=a(Q()).appendTo(i.options.widgetParent),i.minViewMode=i.options.minViewMode||0,"string"==typeof i.minViewMode)switch(i.minViewMode){case"months":i.minViewMode=1;break;case"years":i.minViewMode=2;break;default:i.minViewMode=0}if(i.viewMode=i.options.viewMode||0,"string"==typeof i.viewMode)switch(i.viewMode){case"months":i.viewMode=1;break;case"years":i.viewMode=2;break;default:i.viewMode=0}i.viewMode=Math.max(i.viewMode,i.minViewMode),i.options.disabledDates=O(i.options.disabledDates),i.options.enabledDates=O(i.options.enabledDates),i.startViewMode=i.viewMode,i.setMinDate(i.options.minDate),i.setMaxDate(i.options.maxDate),r(),s(),u(),v(),w(),q(),E(),l().prop("disabled")||F(),""!==i.options.defaultDate&&""===l().val()&&i.setValue(i.options.defaultDate),1!==i.options.minuteStepping&&(j=i.options.minuteStepping,i.date.minutes(Math.round(i.date.minutes()/j)*j%60).seconds(0))},l=function(){var a;if(i.isInput)return i.element;if(a=i.element.find(".datepickerinput"),0===a.size())a=i.element.find("input");else if(!a.is("input"))throw new Error('CSS class "datepickerinput" cannot be applied to non input element');return a},m=function(){var a;a=i.element.is("input")?i.element.data():i.element.find("input").data(),void 0!==a.dateFormat&&(i.options.format=a.dateFormat),void 0!==a.datePickdate&&(i.options.pickDate=a.datePickdate),void 0!==a.datePicktime&&(i.options.pickTime=a.datePicktime),void 0!==a.dateUseminutes&&(i.options.useMinutes=a.dateUseminutes),void 0!==a.dateUseseconds&&(i.options.useSeconds=a.dateUseseconds),void 0!==a.dateUsecurrent&&(i.options.useCurrent=a.dateUsecurrent),void 0!==a.calendarWeeks&&(i.options.calendarWeeks=a.calendarWeeks),void 0!==a.dateMinutestepping&&(i.options.minuteStepping=a.dateMinutestepping),void 0!==a.dateMindate&&(i.options.minDate=a.dateMindate),void 0!==a.dateMaxdate&&(i.options.maxDate=a.dateMaxdate),void 0!==a.dateShowtoday&&(i.options.showToday=a.dateShowtoday),void 0!==a.dateCollapse&&(i.options.collapse=a.dateCollapse),void 0!==a.dateLanguage&&(i.options.language=a.dateLanguage),void 0!==a.dateDefaultdate&&(i.options.defaultDate=a.dateDefaultdate),void 0!==a.dateDisableddates&&(i.options.disabledDates=a.dateDisableddates),void 0!==a.dateEnableddates&&(i.options.enabledDates=a.dateEnableddates),void 0!==a.dateIcons&&(i.options.icons=a.dateIcons),void 0!==a.dateUsestrict&&(i.options.useStrict=a.dateUsestrict),void 0!==a.dateDirection&&(i.options.direction=a.dateDirection),void 0!==a.dateSidebyside&&(i.options.sideBySide=a.dateSidebyside),void 0!==a.dateDaysofweekdisabled&&(i.options.daysOfWeekDisabled=a.dateDaysofweekdisabled)},n=function(){var b,c="absolute",d=i.component?i.component.offset():i.element.offset(),e=a(window);i.width=i.component?i.component.outerWidth():i.element.outerWidth(),d.top=d.top+i.element.outerHeight(),"up"===i.options.direction?b="top":"bottom"===i.options.direction?b="bottom":"auto"===i.options.direction&&(b=d.top+i.widget.height()>e.height()+e.scrollTop()&&i.widget.height()+i.element.outerHeight()<d.top?"top":"bottom"),"top"===b?(d.bottom=e.height()-d.top+i.element.outerHeight()+3,i.widget.addClass("top").removeClass("bottom")):(d.top+=1,i.widget.addClass("bottom").removeClass("top")),void 0!==i.options.width&&i.widget.width(i.options.width),"left"===i.options.orientation&&(i.widget.addClass("left-oriented"),d.left=d.left-i.widget.width()+20),J()&&(c="fixed",d.top-=e.scrollTop(),d.left-=e.scrollLeft()),e.width()<d.left+i.widget.outerWidth()?(d.right=e.width()-d.left-i.width,d.left="auto",i.widget.addClass("pull-right")):(d.right="auto",i.widget.removeClass("pull-right")),i.widget.css("top"===b?{position:c,bottom:d.bottom,top:"auto",left:d.left,right:d.right}:{position:c,top:d.top,bottom:"auto",left:d.left,right:d.right})},o=function(a,c){(!b(i.date).isSame(b(a))||j)&&(j=!1,i.element.trigger({type:"dp.change",date:b(i.date),oldDate:b(a)}),"change"!==c&&i.element.change())},p=function(a){j=!0,i.element.trigger({type:"dp.error",date:b(a,i.format,i.options.useStrict)})},q=function(a){b.locale(i.options.language);var c=a;c||(c=l().val(),c&&(i.date=b(c,i.format,i.options.useStrict)),i.date||(i.date=b())),i.viewDate=b(i.date).startOf("month"),t(),x()},r=function(){b.locale(i.options.language);var c,d=a("<tr>"),e=b.weekdaysMin();if(i.options.calendarWeeks===!0&&d.append('<th class="cw">#</th>'),0===b().localeData()._week.dow)for(c=0;7>c;c++)d.append('<th class="dow">'+e[c]+"</th>");else for(c=1;8>c;c++)d.append(7===c?'<th class="dow">'+e[0]+"</th>":'<th class="dow">'+e[c]+"</th>");i.widget.find(".datepicker-days thead").append(d)},s=function(){b.locale(i.options.language);var a,c="",d=b.monthsShort();for(a=0;12>a;a++)c+='<span class="month">'+d[a]+"</span>";i.widget.find(".datepicker-months td").append(c)},t=function(){if(i.options.pickDate){b.locale(i.options.language);var c,d,e,f,g,h,j,k,l,m=i.viewDate.year(),n=i.viewDate.month(),o=i.options.minDate.year(),p=i.options.minDate.month(),q=i.options.maxDate.year(),r=i.options.maxDate.month(),s=[],t=b.months();for(i.widget.find(".datepicker-days").find(".disabled").removeClass("disabled"),i.widget.find(".datepicker-months").find(".disabled").removeClass("disabled"),i.widget.find(".datepicker-years").find(".disabled").removeClass("disabled"),i.widget.find(".datepicker-days th:eq(1)").text(t[n]+" "+m),d=b(i.viewDate,i.format,i.options.useStrict).subtract(1,"months"),j=d.daysInMonth(),d.date(j).startOf("week"),(m===o&&p>=n||o>m)&&i.widget.find(".datepicker-days th:eq(0)").addClass("disabled"),(m===q&&n>=r||m>q)&&i.widget.find(".datepicker-days th:eq(2)").addClass("disabled"),e=b(d).add(42,"d");d.isBefore(e);){if(d.weekday()===b().startOf("week").weekday()&&(f=a("<tr>"),s.push(f),i.options.calendarWeeks===!0&&f.append('<td class="cw">'+d.week()+"</td>")),g="",d.year()<m||d.year()===m&&d.month()<n?g+=" old":(d.year()>m||d.year()===m&&d.month()>n)&&(g+=" new"),d.isSame(b({y:i.date.year(),M:i.date.month(),d:i.date.date()}))&&(g+=" active"),(M(d,"day")||!N(d))&&(g+=" disabled"),i.options.showToday===!0&&d.isSame(b(),"day")&&(g+=" today"),i.options.daysOfWeekDisabled)for(h=0;h<i.options.daysOfWeekDisabled.length;h++)if(d.day()===i.options.daysOfWeekDisabled[h]){g+=" disabled";break}f.append('<td class="day'+g+'">'+d.date()+"</td>"),c=d.date(),d.add(1,"d"),c===d.date()&&d.add(1,"d")}for(i.widget.find(".datepicker-days tbody").empty().append(s),l=i.date.year(),t=i.widget.find(".datepicker-months").find("th:eq(1)").text(m).end().find("span").removeClass("active"),l===m&&t.eq(i.date.month()).addClass("active"),o>m-1&&i.widget.find(".datepicker-months th:eq(0)").addClass("disabled"),m+1>q&&i.widget.find(".datepicker-months th:eq(2)").addClass("disabled"),h=0;12>h;h++)m===o&&p>h||o>m?a(t[h]).addClass("disabled"):(m===q&&h>r||m>q)&&a(t[h]).addClass("disabled");for(s="",m=10*parseInt(m/10,10),k=i.widget.find(".datepicker-years").find("th:eq(1)").text(m+"-"+(m+9)).parents("table").find("td"),i.widget.find(".datepicker-years").find("th").removeClass("disabled"),o>m&&i.widget.find(".datepicker-years").find("th:eq(0)").addClass("disabled"),m+9>q&&i.widget.find(".datepicker-years").find("th:eq(2)").addClass("disabled"),m-=1,h=-1;11>h;h++)s+='<span class="year'+(-1===h||10===h?" old":"")+(l===m?" active":"")+(o>m||m>q?" disabled":"")+'">'+m+"</span>",m+=1;k.html(s)}},u=function(){b.locale(i.options.language);var a,c,d,e=i.widget.find(".timepicker .timepicker-hours table"),f="";if(e.parent().hide(),i.use24hours)for(a=0,c=0;6>c;c+=1){for(f+="<tr>",d=0;4>d;d+=1)f+='<td class="hour">'+P(a.toString())+"</td>",a++;f+="</tr>"}else for(a=1,c=0;3>c;c+=1){for(f+="<tr>",d=0;4>d;d+=1)f+='<td class="hour">'+P(a.toString())+"</td>",a++;f+="</tr>"}e.html(f)},v=function(){var a,b,c=i.widget.find(".timepicker .timepicker-minutes table"),d="",e=0,f=i.options.minuteStepping;for(c.parent().hide(),1===f&&(f=5),a=0;a<Math.ceil(60/f/4);a++){for(d+="<tr>",b=0;4>b;b+=1)60>e?(d+='<td class="minute">'+P(e.toString())+"</td>",e+=f):d+="<td></td>";d+="</tr>"}c.html(d)},w=function(){var a,b,c=i.widget.find(".timepicker .timepicker-seconds table"),d="",e=0;for(c.parent().hide(),a=0;3>a;a++){for(d+="<tr>",b=0;4>b;b+=1)d+='<td class="second">'+P(e.toString())+"</td>",e+=5;d+="</tr>"}c.html(d)},x=function(){if(i.date){var a=i.widget.find(".timepicker span[data-time-component]"),b=i.date.hours(),c=i.date.format("A");i.use24hours||(0===b?b=12:12!==b&&(b%=12),i.widget.find(".timepicker [data-action=togglePeriod]").text(c)),a.filter("[data-time-component=hours]").text(P(b)),a.filter("[data-time-component=minutes]").text(P(i.date.minutes())),a.filter("[data-time-component=seconds]").text(P(i.date.second()))}},y=function(c){c.stopPropagation(),c.preventDefault(),i.unset=!1;var d,e,f,g,h=a(c.target).closest("span, td, th"),j=b(i.date);if(1===h.length&&!h.is(".disabled"))switch(h[0].nodeName.toLowerCase()){case"th":switch(h[0].className){case"picker-switch":E(1);break;case"prev":case"next":f=R.modes[i.viewMode].navStep,"prev"===h[0].className&&(f=-1*f),i.viewDate.add(f,R.modes[i.viewMode].navFnc),t()}break;case"span":h.is(".month")?(d=h.parent().find("span").index(h),i.viewDate.month(d)):(e=parseInt(h.text(),10)||0,i.viewDate.year(e)),i.viewMode===i.minViewMode&&(i.date=b({y:i.viewDate.year(),M:i.viewDate.month(),d:i.viewDate.date(),h:i.date.hours(),m:i.date.minutes(),s:i.date.seconds()}),K(),o(j,c.type)),E(-1),t();break;case"td":h.is(".day")&&(g=parseInt(h.text(),10)||1,d=i.viewDate.month(),e=i.viewDate.year(),h.is(".old")?0===d?(d=11,e-=1):d-=1:h.is(".new")&&(11===d?(d=0,e+=1):d+=1),i.date=b({y:e,M:d,d:g,h:i.date.hours(),m:i.date.minutes(),s:i.date.seconds()}),i.viewDate=b({y:e,M:d,d:Math.min(28,g)}),t(),K(),o(j,c.type))}},z={incrementHours:function(){L("add","hours",1)},incrementMinutes:function(){L("add","minutes",i.options.minuteStepping)},incrementSeconds:function(){L("add","seconds",1)},decrementHours:function(){L("subtract","hours",1)},decrementMinutes:function(){L("subtract","minutes",i.options.minuteStepping)},decrementSeconds:function(){L("subtract","seconds",1)},togglePeriod:function(){var a=i.date.hours();a>=12?a-=12:a+=12,i.date.hours(a)},showPicker:function(){i.widget.find(".timepicker > div:not(.timepicker-picker)").hide(),i.widget.find(".timepicker .timepicker-picker").show()},showHours:function(){i.widget.find(".timepicker .timepicker-picker").hide(),i.widget.find(".timepicker .timepicker-hours").show()},showMinutes:function(){i.widget.find(".timepicker .timepicker-picker").hide(),i.widget.find(".timepicker .timepicker-minutes").show()},showSeconds:function(){i.widget.find(".timepicker .timepicker-picker").hide(),i.widget.find(".timepicker .timepicker-seconds").show()},selectHour:function(b){var c=parseInt(a(b.target).text(),10);i.use24hours||(i.date.hours()>=12?12!==c&&(c+=12):12===c&&(c=0)),i.date.hours(c),z.showPicker.call(i)},selectMinute:function(b){i.date.minutes(parseInt(a(b.target).text(),10)),z.showPicker.call(i)},selectSecond:function(b){i.date.seconds(parseInt(a(b.target).text(),10)),z.showPicker.call(i)}},A=function(c){var d=b(i.date),e=a(c.currentTarget).data("action"),f=z[e].apply(i,arguments);return B(c),i.date||(i.date=b({y:1970})),K(),x(),o(d,c.type),f},B=function(a){a.stopPropagation(),a.preventDefault()},C=function(a){27===a.keyCode&&i.hide()},D=function(c){b.locale(i.options.language);var d=a(c.target),e=b(i.date),f=b(d.val(),i.format,i.options.useStrict);f.isValid()&&!M(f)&&N(f)?(q(),i.setValue(f),o(e,c.type),K()):(i.viewDate=e,i.unset=!0,o(e,c.type),p(f))},E=function(a){a&&(i.viewMode=Math.max(i.minViewMode,Math.min(2,i.viewMode+a))),i.widget.find(".datepicker > div").hide().filter(".datepicker-"+R.modes[i.viewMode].clsName).show()},F=function(){var b,c,d,e,f;i.widget.on("click",".datepicker *",a.proxy(y,this)),i.widget.on("click","[data-action]",a.proxy(A,this)),i.widget.on("mousedown",a.proxy(B,this)),i.element.on("keydown",a.proxy(C,this)),i.options.pickDate&&i.options.pickTime&&i.widget.on("click.togglePicker",".accordion-toggle",function(g){if(g.stopPropagation(),b=a(this),c=b.closest("ul"),d=c.find(".in"),e=c.find(".collapse:not(.in)"),d&&d.length){if(f=d.data("collapse"),f&&f.transitioning)return;d.collapse("hide"),e.collapse("show"),b.find("span").toggleClass(i.options.icons.time+" "+i.options.icons.date),i.component&&i.component.find("span").toggleClass(i.options.icons.time+" "+i.options.icons.date)}}),i.isInput?i.element.on({click:a.proxy(i.show,this),focus:a.proxy(i.show,this),change:a.proxy(D,this),blur:a.proxy(i.hide,this)}):(i.element.on({change:a.proxy(D,this)},"input"),i.component?(i.component.on("click",a.proxy(i.show,this)),i.component.on("mousedown",a.proxy(B,this))):i.element.on("click",a.proxy(i.show,this)))},G=function(){a(window).on("resize.datetimepicker"+i.id,a.proxy(n,this)),i.isInput||a(document).on("mousedown.datetimepicker"+i.id,a.proxy(i.hide,this))},H=function(){i.widget.off("click",".datepicker *",i.click),i.widget.off("click","[data-action]"),i.widget.off("mousedown",i.stopEvent),i.options.pickDate&&i.options.pickTime&&i.widget.off("click.togglePicker"),i.isInput?i.element.off({focus:i.show,change:D,click:i.show,blur:i.hide}):(i.element.off({change:D},"input"),i.component?(i.component.off("click",i.show),i.component.off("mousedown",i.stopEvent)):i.element.off("click",i.show))},I=function(){a(window).off("resize.datetimepicker"+i.id),i.isInput||a(document).off("mousedown.datetimepicker"+i.id)},J=function(){if(i.element){var b,c=i.element.parents(),d=!1;for(b=0;b<c.length;b++)if("fixed"===a(c[b]).css("position")){d=!0;break}return d}return!1},K=function(){b.locale(i.options.language);var a="";i.unset||(a=b(i.date).format(i.format)),l().val(a),i.element.data("date",a),i.options.pickTime||i.hide()},L=function(a,c,d){b.locale(i.options.language);var e;return"add"===a?(e=b(i.date),23===e.hours()&&e.add(d,c),e.add(d,c)):e=b(i.date).subtract(d,c),M(b(e.subtract(d,c)))||M(e)?void p(e.format(i.format)):("add"===a?i.date.add(d,c):i.date.subtract(d,c),void(i.unset=!1))},M=function(a,c){b.locale(i.options.language);var d=b(i.options.maxDate,i.format,i.options.useStrict),e=b(i.options.minDate,i.format,i.options.useStrict);return c&&(d=d.endOf(c),e=e.startOf(c)),a.isAfter(d)||a.isBefore(e)?!0:i.options.disabledDates===!1?!1:i.options.disabledDates[a.format("YYYY-MM-DD")]===!0},N=function(a){return b.locale(i.options.language),i.options.enabledDates===!1?!0:i.options.enabledDates[a.format("YYYY-MM-DD")]===!0},O=function(a){var c,d={},e=0;for(c=0;c<a.length;c++)f=b.isMoment(a[c])||a[c]instanceof Date?b(a[c]):b(a[c],i.format,i.options.useStrict),f.isValid()&&(d[f.format("YYYY-MM-DD")]=!0,e++);return e>0?d:!1},P=function(a){return a=a.toString(),a.length>=2?a:"0"+a},Q=function(){var a='<thead><tr><th class="prev">&lsaquo;</th><th colspan="'+(i.options.calendarWeeks?"6":"5")+'" class="picker-switch"></th><th class="next">&rsaquo;</th></tr></thead>',b='<tbody><tr><td colspan="'+(i.options.calendarWeeks?"8":"7")+'"></td></tr></tbody>',c='<div class="datepicker-days"><table class="table-condensed">'+a+'<tbody></tbody></table></div><div class="datepicker-months"><table class="table-condensed">'+a+b+'</table></div><div class="datepicker-years"><table class="table-condensed">'+a+b+"</table></div>",d="";return i.options.pickDate&&i.options.pickTime?(d='<div class="bootstrap-datetimepicker-widget'+(i.options.sideBySide?" timepicker-sbs":"")+(i.use24hours?" usetwentyfour":"")+' dropdown-menu" style="z-index:9999 !important;">',d+=i.options.sideBySide?'<div class="row"><div class="col-sm-6 datepicker">'+c+'</div><div class="col-sm-6 timepicker">'+S.getTemplate()+"</div></div>":'<ul class="list-unstyled"><li'+(i.options.collapse?' class="collapse in"':"")+'><div class="datepicker">'+c+'</div></li><li class="picker-switch accordion-toggle"><a class="btn" style="width:100%"><span class="'+i.options.icons.time+'"></span></a></li><li'+(i.options.collapse?' class="collapse"':"")+'><div class="timepicker">'+S.getTemplate()+"</div></li></ul>",d+="</div>"):i.options.pickTime?'<div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="timepicker">'+S.getTemplate()+"</div></div>":'<div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="datepicker">'+c+"</div></div>"},R={modes:[{clsName:"days",navFnc:"month",navStep:1},{clsName:"months",navFnc:"year",navStep:1},{clsName:"years",navFnc:"year",navStep:10}]},S={hourTemplate:'<span data-action="showHours"   data-time-component="hours"   class="timepicker-hour"></span>',minuteTemplate:'<span data-action="showMinutes" data-time-component="minutes" class="timepicker-minute"></span>',secondTemplate:'<span data-action="showSeconds"  data-time-component="seconds" class="timepicker-second"></span>'};S.getTemplate=function(){return'<div class="timepicker-picker"><table class="table-condensed"><tr><td><a href="#" class="btn" data-action="incrementHours"><span class="'+i.options.icons.up+'"></span></a></td><td class="separator"></td><td>'+(i.options.useMinutes?'<a href="#" class="btn" data-action="incrementMinutes"><span class="'+i.options.icons.up+'"></span></a>':"")+"</td>"+(i.options.useSeconds?'<td class="separator"></td><td><a href="#" class="btn" data-action="incrementSeconds"><span class="'+i.options.icons.up+'"></span></a></td>':"")+(i.use24hours?"":'<td class="separator"></td>')+"</tr><tr><td>"+S.hourTemplate+'</td> <td class="separator">:</td><td>'+(i.options.useMinutes?S.minuteTemplate:'<span class="timepicker-minute">00</span>')+"</td> "+(i.options.useSeconds?'<td class="separator">:</td><td>'+S.secondTemplate+"</td>":"")+(i.use24hours?"":'<td class="separator"></td><td><button type="button" class="btn btn-primary" data-action="togglePeriod"></button></td>')+'</tr><tr><td><a href="#" class="btn" data-action="decrementHours"><span class="'+i.options.icons.down+'"></span></a></td><td class="separator"></td><td>'+(i.options.useMinutes?'<a href="#" class="btn" data-action="decrementMinutes"><span class="'+i.options.icons.down+'"></span></a>':"")+"</td>"+(i.options.useSeconds?'<td class="separator"></td><td><a href="#" class="btn" data-action="decrementSeconds"><span class="'+i.options.icons.down+'"></span></a></td>':"")+(i.use24hours?"":'<td class="separator"></td>')+'</tr></table></div><div class="timepicker-hours" data-action="selectHour"><table class="table-condensed"></table></div><div class="timepicker-minutes" data-action="selectMinute"><table class="table-condensed"></table></div>'+(i.options.useSeconds?'<div class="timepicker-seconds" data-action="selectSecond"><table class="table-condensed"></table></div>':"")},i.destroy=function(){H(),I(),i.widget.remove(),i.element.removeData("DateTimePicker"),i.component&&i.component.removeData("DateTimePicker")},i.show=function(a){if(!l().prop("disabled")){if(i.options.useCurrent&&""===l().val()){if(1!==i.options.minuteStepping){var c=b(),d=i.options.minuteStepping;c.minutes(Math.round(c.minutes()/d)*d%60).seconds(0),i.setValue(c.format(i.format))}else i.setValue(b().format(i.format));o("",a.type)}a&&"click"===a.type&&i.isInput&&i.widget.hasClass("picker-open")||(i.widget.hasClass("picker-open")?(i.widget.hide(),i.widget.removeClass("picker-open")):(i.widget.show(),i.widget.addClass("picker-open")),i.height=i.component?i.component.outerHeight():i.element.outerHeight(),n(),i.element.trigger({type:"dp.show",date:b(i.date)}),G(),a&&B(a))}},i.disable=function(){var a=l();a.prop("disabled")||(a.prop("disabled",!0),H())},i.enable=function(){var a=l();a.prop("disabled")&&(a.prop("disabled",!1),F())},i.hide=function(){var a,c,d=i.widget.find(".collapse");for(a=0;a<d.length;a++)if(c=d.eq(a).data("collapse"),c&&c.transitioning)return;i.widget.hide(),i.widget.removeClass("picker-open"),i.viewMode=i.startViewMode,E(),i.element.trigger({type:"dp.hide",date:b(i.date)}),I()},i.setValue=function(a){b.locale(i.options.language),a?i.unset=!1:(i.unset=!0,K()),a=b.isMoment(a)?a.locale(i.options.language):a instanceof Date?b(a):b(a,i.format,i.options.useStrict),a.isValid()?(i.date=a,K(),i.viewDate=b({y:i.date.year(),M:i.date.month()}),t(),x()):p(a)},i.getDate=function(){return i.unset?null:b(i.date)},i.setDate=function(a){var c=b(i.date);i.setValue(a?a:null),o(c,"function")},i.setDisabledDates=function(a){i.options.disabledDates=O(a),i.viewDate&&q()},i.setEnabledDates=function(a){i.options.enabledDates=O(a),i.viewDate&&q()},i.setMaxDate=function(a){void 0!==a&&(i.options.maxDate=b.isMoment(a)||a instanceof Date?b(a):b(a,i.format,i.options.useStrict),i.viewDate&&q())},i.setMinDate=function(a){void 0!==a&&(i.options.minDate=b.isMoment(a)||a instanceof Date?b(a):b(a,i.format,i.options.useStrict),i.viewDate&&q())},k()};a.fn.datetimepicker=function(b){return this.each(function(){var c=a(this),e=c.data("DateTimePicker");e||c.data("DateTimePicker",new d(this,b))})},a.fn.datetimepicker.defaults={format:!1,pickDate:!0,pickTime:!0,useMinutes:!0,useSeconds:!1,useCurrent:!0,calendarWeeks:!1,minuteStepping:1,minDate:b({y:1900}),maxDate:b().add(100,"y"),showToday:!0,collapse:!0,language:b.locale(),defaultDate:"",disabledDates:!1,enabledDates:!1,icons:{},useStrict:!1,direction:"auto",sideBySide:!1,daysOfWeekDisabled:[],widgetParent:!1}});

;
/* so_megamenu.js */

/* 1   */ var active = false;
/* 2   */ var hover = false;
/* 3   */ $(document).ready(function() {
/* 4   */ 	$("ul.megamenu li .sub-menu .content .hover-menu ul li").hover(function () {
/* 5   */ 		$(this).children("ul").show();
/* 6   */ 
/* 7   */ 	},function () {
/* 8   */ 		$(this).children("ul").hide();
/* 9   */ 	});
/* 10  */ 	
/* 11  */ 	
/* 12  */ 	var wd_width = $(window).width();
/* 13  */ 	if(wd_width <= 991) {
/* 14  */ 		$("ul.megamenu > li.hover").unbind('mouseenter mouseleave');
/* 15  */ 		removeWidthSubmenu();	
/* 16  */ 		clickMegaMenu();
/* 17  */ 	} else {
/* 18  */ 		$( "ul.megamenu > li.hover").unbind( "click" );
/* 19  */ 		hoverMegaMenu();
/* 20  */ 		renderWidthSubmenu();
/* 21  */ 	}
/* 22  */ 	
/* 23  */ 	$(window).resize(function() {
/* 24  */ 		var sp_width = $(window).width();
/* 25  */ 		if(sp_width <= 991){
/* 26  */ 			$("ul.megamenu > li.hover").unbind('mouseenter mouseleave');
/* 27  */ 			removeWidthSubmenu();
/* 28  */ 			clickMegaMenu();
/* 29  */ 		}	
/* 30  */ 		else{
/* 31  */ 			$( "ul.megamenu > li.hover").unbind( "click" );
/* 32  */ 			hoverMegaMenu();
/* 33  */ 			renderWidthSubmenu();
/* 34  */ 		}	
/* 35  */ 	});
/* 36  */ 	
/* 37  */ 	
/* 38  */ 	$("ul.megamenu > li.click").click(function () {
/* 39  */ 		if($(this).find(".content").is(':visible')) { return false; }
/* 40  */ 		active = $(this);
/* 41  */ 		hover = true;
/* 42  */ 		$("ul.megamenu > li").removeClass("active");
/* 43  */ 		$(this).addClass("active");
/* 44  */ 		$("ul.megamenu > li").children(".sub-menu").hide();
/* 45  */ 		$("ul.megamenu > li").find(".content").hide();
/* 46  */ 		$(this).children(".sub-menu").show();
/* 47  */ 		if(transition == 'slide') {
/* 48  */ 			$(this).find(".content").show();
/* 49  */ 			$(this).find(".content").css("height", "auto");
/* 50  */ 			var originalHeight = $(this).find(".content").height();

/* so_megamenu.js */

/* 51  */ 			$(this).find(".content").css("height", 0);
/* 52  */ 			$(this).find(".content").stop(true, true).animate({ height:originalHeight },animation_time);
/* 53  */ 		} else if(transition == 'fade') {
/* 54  */ 			$(this).find(".content").fadeIn(animation_time);
/* 55  */ 		} else {
/* 56  */ 			$(this).find(".content").show();
/* 57  */ 		}		
/* 58  */ 		$(this).children(".sub-menu").css("right", "auto");
/* 59  */ 			if ($("html").css("direction").toLowerCase() == "rtl"){
/* 60  */ 				var $whatever        = $(this).children(".sub-menu");
/* 61  */ 				var $whatever2       =  $($whatever).closest('ul.megamenu');
/* 62  */ 				if($whatever.offset().left < $whatever2.offset().left) {
/* 63  */ 					$(this).children(".sub-menu").css("right", "0");
/* 64  */ 				}				
/* 65  */ 			}else{
/* 66  */ 				var $whatever        = $(this).children(".sub-menu");
/* 67  */ 				var ending_right     = ($(window).width() - ($whatever.offset().left + $whatever.outerWidth()));
/* 68  */ 				var $whatever2       =  $($whatever).closest('ul.megamenu');
/* 69  */ 				var ending_right2    = ($(window).width() - ($whatever2.offset().left + $whatever2.outerWidth()));
/* 70  */ 				if(ending_right2 > ending_right) {
/* 71  */ 					$(this).children(".sub-menu").css("right", "0");
/* 72  */ 				}				
/* 73  */ 			}
/* 74  */ 
/* 75  */ 		return false;
/* 76  */ 	});
/* 77  */ 	
/* 78  */ 	$("#show-megamenu").click(function () {
/* 79  */ 		if($('.megamenu-wrapper').hasClass('so-megamenu-active'))
/* 80  */ 			$('.megamenu-wrapper').removeClass('so-megamenu-active');
/* 81  */ 		else
/* 82  */ 			$('.megamenu-wrapper').addClass('so-megamenu-active');
/* 83  */ 	}); 
/* 84  */ 	$('#remove-megamenu').click(function() {
/* 85  */         $('.megamenu-wrapper').removeClass('so-megamenu-active');
/* 86  */         return false;
/* 87  */     });		
/* 88  */ 	
/* 89  */ 	$("#show-verticalmenu").click(function () {
/* 90  */ 		if($('.vertical-wrapper').hasClass('so-vertical-active'))
/* 91  */ 			$('.vertical-wrapper').removeClass('so-vertical-active');
/* 92  */ 		else
/* 93  */ 			$('.vertical-wrapper').addClass('so-vertical-active');
/* 94  */ 	}); 
/* 95  */ 	$('#remove-verticalmenu').click(function() {
/* 96  */         $('.vertical-wrapper').removeClass('so-vertical-active');
/* 97  */         return false;
/* 98  */     });	
/* 99  */ 	
/* 100 */ 	$('html').on('click', function () {

/* so_megamenu.js */

/* 101 */ 		$("ul.megamenu > li.click").removeClass("active");
/* 102 */ 		$("ul.megamenu > li.click").children(".sub-menu").hide();
/* 103 */ 		$("ul.megamenu > li.click").find(".content").hide();
/* 104 */ 	});
/* 105 */ 	$('.close-menu').on('click', function () {
/* 106 */ 		$(this).parent().removeClass("active");
/* 107 */ 		$(this).parent().children(".sub-menu").hide();
/* 108 */ 		$(this).parent().find(".content").hide();
/* 109 */ 		return false;
/* 110 */ 	});
/* 111 */ });
/* 112 */ 
/* 113 */ function renderWidthSubmenu()
/* 114 */ {
/* 115 */ 	$('.vertical .sub-menu').each(function(){
/* 116 */ 		value = $(this).data("subwidth");
/* 117 */ 		if(value){
/* 118 */ 			var container_width = $('.container').width();
/* 119 */ 			var vertical_width = $('.vertical').width();
/* 120 */ 			var full_width = container_width - vertical_width;
/* 121 */ 			var width_submenu = (full_width*value)/100;
/* 122 */ 			$(this).css('width',width_submenu+'px');
/* 123 */ 		}	
/* 124 */ 	});
/* 125 */ }	
/* 126 */ function removeWidthSubmenu()
/* 127 */ {
/* 128 */ 	$('.vertical .sub-menu').each(function(){
/* 129 */ 		$(this).css('width','100%');
/* 130 */ 	});
/* 131 */ }
/* 132 */ function clickMegaMenu(){
/* 133 */ 	$("ul.megamenu > li.hover").click(function () {
/* 134 */ 		if($(this).find(".content").is(':visible')) { return false; }
/* 135 */ 		active = $(this);
/* 136 */ 		hover = true;
/* 137 */ 		$("ul.megamenu > li").removeClass("active");
/* 138 */ 		$(this).addClass("active");
/* 139 */ 		$("ul.megamenu > li").children(".sub-menu").hide();
/* 140 */ 		$("ul.megamenu > li").find(".content").hide();
/* 141 */ 		$(this).children(".sub-menu").show();
/* 142 */ 		if(transition == 'slide') {
/* 143 */ 			$(this).find(".content").show();
/* 144 */ 			$(this).find(".content").css("height", "auto");
/* 145 */ 			var originalHeight = $(this).find(".content").height();
/* 146 */ 			$(this).find(".content").css("height", 0);
/* 147 */ 			$(this).find(".content").stop(true, true).animate({ height:originalHeight },animation_time);
/* 148 */ 		} else if(transition == 'fade') {
/* 149 */ 			$(this).find(".content").fadeIn(animation_time);
/* 150 */ 		} else {

/* so_megamenu.js */

/* 151 */ 			$(this).find(".content").show();
/* 152 */ 		}		
/* 153 */ 		$(this).children(".sub-menu").css("right", "auto");
/* 154 */ 			if ($("html").css("direction").toLowerCase() == "rtl"){
/* 155 */ 				var $whatever        = $(this).children(".sub-menu");
/* 156 */ 				var $whatever2       =  $($whatever).closest('ul.megamenu');
/* 157 */ 				if($whatever.offset().left < $whatever2.offset().left) {
/* 158 */ 					$(this).children(".sub-menu").css("right", "0");
/* 159 */ 				}				
/* 160 */ 			}else{
/* 161 */ 				var $whatever        = $(this).children(".sub-menu");
/* 162 */ 				var ending_right     = ($(window).width() - ($whatever.offset().left + $whatever.outerWidth()));
/* 163 */ 				var $whatever2       =  $($whatever).closest('ul.megamenu');
/* 164 */ 				var ending_right2    = ($(window).width() - ($whatever2.offset().left + $whatever2.outerWidth()));
/* 165 */ 				if(ending_right2 > ending_right) {
/* 166 */ 					$(this).children(".sub-menu").css("right", "0");
/* 167 */ 				}				
/* 168 */ 			}
/* 169 */ 
/* 170 */ 	});	
/* 171 */ }
/* 172 */ 
/* 173 */ function hoverMegaMenu(){
/* 174 */ 		$("ul.megamenu > li.hover").hover(function () {
/* 175 */ 			active = $(this);
/* 176 */ 			hover = true;
/* 177 */ 			$("ul.megamenu > li").removeClass("active");
/* 178 */ 			$(this).addClass("active");
/* 179 */ 			$("ul.megamenu > li").children(".sub-menu").hide();
/* 180 */ 			$("ul.megamenu > li").find(".content").hide();
/* 181 */ 			$(this).children(".sub-menu").show();
/* 182 */ 			if(transition == 'slide') {
/* 183 */ 				$(this).find(".content").show();
/* 184 */ 				$(this).find(".content").css("height", "auto");
/* 185 */ 				var originalHeight = $(this).find(".content").height();
/* 186 */ 				$(this).find(".content").css("height", 0);
/* 187 */ 				$(this).find(".content").stop(true, true).animate({ height:originalHeight },animation_time);
/* 188 */ 			} else if(transition == 'fade') {
/* 189 */ 				$(this).find(".content").fadeIn(animation_time);
/* 190 */ 			} else {
/* 191 */ 				$(this).find(".content").show();
/* 192 */ 			}	
/* 193 */ 			$(this).children(".sub-menu").css("right", "auto");	
/* 194 */ 			if ($("html").css("direction").toLowerCase() == "rtl"){
/* 195 */ 				var $whatever        = $(this).children(".sub-menu");
/* 196 */ 				var $whatever2       =  $($whatever).closest('ul.megamenu');
/* 197 */ 				if($whatever.offset().left < $whatever2.offset().left) {
/* 198 */ 					$(this).children(".sub-menu").css("right", "0");
/* 199 */ 				}				
/* 200 */ 			}else{

/* so_megamenu.js */

/* 201 */ 				var $whatever        = $(this).children(".sub-menu");
/* 202 */ 				var ending_right     = ($(window).width() - ($whatever.offset().left + $whatever.outerWidth()));
/* 203 */ 				var $whatever2       =  $($whatever).closest('ul.megamenu');
/* 204 */ 				var ending_right2    = ($(window).width() - ($whatever2.offset().left + $whatever2.outerWidth()));
/* 205 */ 				if(ending_right2 > ending_right) {
/* 206 */ 					$(this).children(".sub-menu").css("right", "0");
/* 207 */ 				}				
/* 208 */ 			}
/* 209 */ 
/* 210 */ 		},function () {
/* 211 */ 			var rel = $(this).attr("title");
/* 212 */ 			hover = false;
/* 213 */ 			if(rel == 'hover-intent') {
/* 214 */ 				var hoverintent = $(this);
/* 215 */ 				setTimeout(function (){
/* 216 */ 					if(hover == false) {
/* 217 */ 						if(transition == 'slide') {
/* 218 */ 							$(hoverintent).find(".content").stop(true, true).animate({ height:"hide" },animation_time, function() { if(hover == false) { $(hoverintent).removeClass("active"); $(hoverintent).children(".sub-menu").hide(); } });
/* 219 */ 						} else if(transition == 'fade') {
/* 220 */ 							$(hoverintent).removeClass("active");
/* 221 */ 							$(hoverintent).find(".content").fadeOut(animation_time, function() {
/* 222 */ 								if(hover == false) { $(hoverintent).children(".sub-menu").hide(); }
/* 223 */ 							});
/* 224 */ 						} else {
/* 225 */ 							$(hoverintent).removeClass("active");
/* 226 */ 							$(hoverintent).children(".sub-menu").hide();
/* 227 */ 							$(hoverintent).find(".content").hide();
/* 228 */ 						}
/* 229 */ 					}
/* 230 */ 				}, 500);
/* 231 */ 			} else {
/* 232 */ 				if(transition == 'slide') {
/* 233 */ 					$(this).find(".content").stop(true, true).animate({ height:"hide" },animation_time, function() { if(hover == false) { $(active).removeClass("active"); $(active).children(".sub-menu").hide(); } });
/* 234 */ 				} else if(transition == 'fade') {
/* 235 */ 					$(active).removeClass("active");
/* 236 */ 					$(this).find(".content").fadeOut(animation_time, function() {
/* 237 */ 						if(hover == false) { $(active).children(".sub-menu").hide(); }
/* 238 */ 					});
/* 239 */ 				} else {
/* 240 */ 					$(this).removeClass("active");
/* 241 */ 					$(this).children(".sub-menu").hide();
/* 242 */ 					$(this).find(".content").hide();
/* 243 */ 				}
/* 244 */ 			}
/* 245 */ 		});	
/* 246 */ }

;
/* shortcodes.js */

/* 1  */ /*
/* 2  *|  * ------------------------------------------------------------------------
/* 3  *|  * Copyright (C) 2009 - 2013 The YouTech JSC. All Rights Reserved.
/* 4  *|  * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
/* 5  *|  * Author: The YouTech JSC
/* 6  *|  * Websites: http://www.smartaddons.com - http://www.cmsportal.net
/* 7  *|  * ------------------------------------------------------------------------
/* 8  *| */
/* 9  */ // Correctly calculate dimensions of hidden elements 
/* 10 */ 
/* 11 */ 
/* 12 */ /* Accordion Block */
/* 13 */ jQuery(document).ready(function($) {
/* 14 */ 	$("ul.yt-accordion li").each(function() {
/* 15 */ 		if($(this).index() > 0) {
/* 16 */ 			$(this).children(".accordion-inner").css('display', 'none');
/* 17 */ 		}
/* 18 */ 		else {
/* 19 */ 			$(this).find(".accordion-heading").addClass('active');
/* 20 */ 		}
/* 21 */ 		
/* 22 */ 		var ua = navigator.userAgent,
/* 23 */ 		event = (ua.match(/iPad/i)) ? "touchstart" : "click";
/* 24 */ 		$(this).children(".accordion-heading").bind(event, function() {
/* 25 */ 			$(this).addClass(function() {
/* 26 */ 				if($(this).hasClass("active")) return "";
/* 27 */ 				return "active";
/* 28 */ 			});
/* 29 */ 	
/* 30 */ 			$(this).siblings(".accordion-inner").slideDown(350);
/* 31 */ 			$(this).parent().siblings("li").children(".accordion-inner").slideUp(350);
/* 32 */ 			$(this).parent().siblings("li").find(".active").removeClass("active");
/* 33 */ 		});
/* 34 */ 	});
/* 35 */ 	
/* 36 */ 	
/* 37 */ 	
/* 38 */ });
/* 39 */ 
/* 40 */ 
/* 41 */ /* Gallery Block */
/* 42 */ jQuery(document).ready(function($) {
/* 43 */ 	// MixItUp plugin
/* 44 */ 	
/* 45 */ 	$(".tabnav li").click(function (){
/* 46 */ 			var clas = $(this).attr('class');
/* 47 */ 			if(clas.substr(0,7)=='showall')
/* 48 */ 			{
/* 49 */ 				$('.yt-gallery-tabbed').find('.tabnav .'+clas.substr(8)+'').removeClass('active');
/* 50 */ 			}

/* shortcodes.js */

/* 51 */ 			else
/* 52 */ 			{
/* 53 */ 				$('.yt-gallery-tabbed').find('.tabnav .'+clas+'').removeClass('active');
/* 54 */ 			}
/* 55 */ 			$(this).addClass('active');
/* 56 */ 			var al =$(this).attr('id');
/* 57 */ 			$("."+clas+".masonry-brick ").css('display','none');
/* 58 */ 			if(clas.substr(0,7)=='showall')
/* 59 */ 			{
/* 60 */ 				$("."+clas.substr(8,37)+".masonry-brick").css('display','block');
/* 61 */ 			}
/* 62 */ 			else
/* 63 */ 			{
/* 64 */ 				$('.'+al+'').css('display','block');
/* 65 */ 			}
/* 66 */ 	})
/* 67 */ 	
/* 68 */      
/* 69 */ 	$('.gallery-list').magnificPopup({
/* 70 */ 	  delegate: 'a',
/* 71 */ 	  type: 'image',
/* 72 */ 	  tLoading: 'Loading image #%curr%...',
/* 73 */ 	  mainClass: 'mfp-img-mobile',
/* 74 */ 	  gallery: {
/* 75 */ 		enabled: true,
/* 76 */ 		navigateByImgClick: true,
/* 77 */ 		preload: [0,1] // Will preload 0 - before current, and 1 after the current image
/* 78 */ 	  }
/* 79 */ 	});
/* 80 */       
/* 81 */     
/* 82 */ });
/* 83 */ 
/* 84 */ 
