
package beans;


public class urunResimler {
    private String urunResimID;
    private String urunID;
    private String resimAdi;
    private String klasor;
    private String albumAdi;

    public String getAlbumAdi() {
        return albumAdi;
    }

    public void setAlbumAdi(String albumAdi) {
        this.albumAdi = albumAdi;
    }

    public String getUrunResimID() {
        return urunResimID;
    }

    public void setUrunResimID(String urunResimID) {
        this.urunResimID = urunResimID;
    }

    public String getUrunID() {
        return urunID;
    }

    public void setUrunID(String urunID) {
        this.urunID = urunID;
    }

    public String getResimAdi() {
        return resimAdi;
    }

    public void setResimAdi(String resimAdi) {
        this.resimAdi = resimAdi;
    }

    public String getKlasor() {
        return klasor;
    }

    public void setKlasor(String klasor) {
        this.klasor = klasor;
    }
    
    
    
}
