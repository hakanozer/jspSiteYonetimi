package beans;

public class propertyTopList {

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getDetay() {
        return detay;
    }

    public void setDetay(String detay) {
        this.detay = detay;
    }

    public String getGecerliFiyat() {
        return gecerliFiyat;
    }

    public void setGecerliFiyat(String gecerliFiyat) {
        this.gecerliFiyat = gecerliFiyat;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getKatID() {
        return katID;
    }

    public void setKatID(String katID) {
        this.katID = katID;
    }

    public String getUrun_id() {
        return urun_id;
    }

    public void setUrun_id(String urun_id) {
        this.urun_id = urun_id;
    }

    public String getKlasor() {
        return klasor;
    }

    public void setKlasor(String klasor) {
        this.klasor = klasor;
    }

    public String getKatAdi() {
        return katAdi;
    }

    public void setKatAdi(String katAdi) {
        this.katAdi = katAdi;
    }

private String baslik;
private String detay;
private String gecerliFiyat;
private String id;
private String katID;
private String urun_id;
private String klasor;
private String katAdi;
private String resAdi;

    public String getResAdi() {
        return resAdi;
    }

    public void setResAdi(String resAdi) {
        this.resAdi = resAdi;
    }
}
