
package beans;


public class UrunArama {
    
    private String katID;
    private String id;
    private String baslik;
    private String kisaAciklama;
    private String detay;
    private String piyasaFiyati;
    private String gecerliFiyat;
    private String kampanyaliUrun;
    private String klasor;
    private String foto_adi;

    public String getKatID() {
        return katID;
    }

    public void setkatID(String katID) {
        this.katID = katID;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getKisaAciklama() {
        return kisaAciklama;
    }

    public void setKisaAciklama(String kisaAciklama) {
        this.kisaAciklama = kisaAciklama;
    }

    public String getDetay() {
        return detay;
    }

    public void setDetay(String detay) {
        this.detay = detay;
    }

    public String getPiyasaFiyati() {
        return piyasaFiyati;
    }

    public void setPiyasaFiyati(String piyasaFiyati) {
        this.piyasaFiyati = piyasaFiyati;
    }

    public String getGecerliFiyat() {
        return gecerliFiyat;
    }

    public void setGecerliFiyat(String gecerliFiyat) {
        this.gecerliFiyat = gecerliFiyat;
    }

    public String getKampanyaliUrun() {
        return kampanyaliUrun;
    }

    public void setKampanyaliUrun(String kampanyaliUrun) {
        this.kampanyaliUrun = kampanyaliUrun;
    }

    public String getKlasor() {
        return klasor;
    }

    public void setKlasor(String klasor) {
        this.klasor = klasor;
    }

    public String getFoto_adi() {
        return foto_adi;
    }

    public void setFoto_adi(String foto_adi) {
        this.foto_adi = foto_adi;
    }
    
    
}
