package beans;

public class urunler {

    private String id;
    private String katID;
    private String baslik;
    private String kisaAciklama;
    private String gununUrunu;
    private String haftaninUrunu;
    private String kampanyaliUrun;
    private String detay;
    private String piyasaFiyati;
    private String gecerliFiyat;
    private String gosterim;
 


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getKatID() {
        return katID;
    }

    public void setKatID(String katID) {
        this.katID = katID;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getKisaAciklama() {
        return kisaAciklama;
    }

    public void setKisaAciklama(String kisaAciklama) {
        this.kisaAciklama = kisaAciklama;
    }

    public String getGununUrunu() {
        return gununUrunu;
    }

    public void setGununUrunu(String gununUrunu) {
        this.gununUrunu = gununUrunu;
    }

    public String getHaftaninUrunu() {
        return haftaninUrunu;
    }

    public void setHaftaninUrunu(String haftaninUrunu) {
        this.haftaninUrunu = haftaninUrunu;
    }

    public String getKampanyaliUrun() {
        return kampanyaliUrun;
    }

    public void setKampanyaliUrun(String kampanyaliUrun) {
        this.kampanyaliUrun = kampanyaliUrun;
    }

    public String getDetay() {
        return detay;
    }

    public void setDetay(String detay) {
        this.detay = detay;
    }

    public String getPiyasaFiyati() {
        return piyasaFiyati;
    }

    public void setPiyasaFiyati(String piyasaFiyati) {
        this.piyasaFiyati = piyasaFiyati;
    }

    public String getGecerliFiyat() {
        return gecerliFiyat;
    }

    public void setGecerliFiyat(String gecerliFiyat) {
        this.gecerliFiyat = gecerliFiyat;
    }

    public String getGosterim() {
        return gosterim;
    }

    public void setGosterim(String gosterim) {
        this.gosterim = gosterim;
    }

}
