
package beans;


public class kategori {

    private String katID;

    public String getKatID() {
        return katID;
    }

    public void setKatID(String katID) {
        this.katID = katID;
    }

    public String getUstKat() {
        return ustKat;
    }

    public void setUstKat(String ustKat) {
        this.ustKat = ustKat;
    }

    public String getKatAdi() {
        return katAdi;
    }

    public void setKatAdi(String katAdi) {
        this.katAdi = katAdi;
    }
    private String ustKat;
    private String katAdi;
    
    
}
