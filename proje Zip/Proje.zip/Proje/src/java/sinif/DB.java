package sinif;

import beans.propertyTopList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public final class DB {

    String driver = "com.mysql.jdbc.Driver";
    String url = "jdbc:mysql://localhost/";
    String DBName = "proje?useUnicode=true&characterEncoding=utf-8";
    String kulAdi = "root";
    String sifre = "";
    ResultSet rs;
    Connection conn = null;
   public Statement st;

    public DB() {
        baglan();
    }

    public DB(String DBName, String kulAdi, String sifre ) {
        this.DBName = DBName;
        this.kulAdi = kulAdi;
        this.sifre = sifre;
        baglan();
    }
    
    // bağlantı aç
    public void baglan(){
        try {
            if(conn == null || conn.isClosed()) {
                Class.forName(driver);
                conn = DriverManager.getConnection(url+DBName, kulAdi, sifre);
                st = conn.createStatement();
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Hata : " + e);
        }
    }
    
    
    public boolean reklamEkle(String ad,String aciklama,String gosterim,String yukseklik,String genislik,String konum){
        boolean sonuc =false;
        try {
            sonuc=st.execute("insert into reklamlar values (null,'"+ad+"','"+aciklama+"','"+gosterim+"','"+yukseklik+"','"+genislik+"','"+konum+"')");
        } catch (Exception e) {
        }
        return sonuc;
    }
    
     public boolean reklamDuzenle(String id,String ad,String aciklama,String gosterim,String yukseklik,String genislik,String konum){
        boolean sonuc =false;
         try {
                     sonuc=st.execute("update reklamlar set reklam_adi='"+ad+"',reklam_aciklama='"+aciklama+"',kalan_gosterim='"+gosterim+"',yukseklik='"+yukseklik+"',genislik='"+genislik+"',konum='"+konum+"' where reklam_id="+id);

         } catch (Exception e) {
         }
        return sonuc;
    }
     
      public boolean reklamSil(String id){
        boolean sonuc =false;
          try {
              sonuc =st.execute("delete from reklamlar where reklam_id="+id);
          } catch (Exception e) {
          }
        return sonuc;
    }
    
    // bağlantıyı kapat
    public void kapat(){
        try {
            if(!conn.isClosed()){
                conn.close();
            }
        } catch (Exception e) {
            System.err.println("Bağlantı Kapatma Hatası");
        }
    }
    
    
    // data getir
    public ResultSet data(String tableName) {
        
        try {
            rs = st.executeQuery("select *from " + tableName);
        } catch (Exception e) {
            System.err.println("Data Getirme Hatası : " + e);
        }
        return rs;
    }

   
    public Boolean galeriSil(String galeriID)
    {
        boolean sonuc=false;
        try {
            sonuc=st.execute("DELETE FROM galeriler WHERE galeriID='"+galeriID+"'");
        } catch (Exception e) {
        }
    
    return sonuc;
    }
    
    public Boolean fotografSil(String fotografID)
    {
        boolean sonuc=false;
        try {
            sonuc=st.execute("DELETE FROM urun_fotograflari WHERE id='"+fotografID+"'");
        } catch (Exception e) {
        }
    
    return sonuc;
    }
    
    public Boolean galeriDuzenle(String galeriID,String galeriAdi,String galeriAciklamasi,String galeriDurumu)
    {
        boolean sonuc=false;
        try {
            sonuc=st.execute("UPDATE galeriler SET galeriAdi='"+galeriAdi+"', galeriAciklamasi='"+galeriAciklamasi+"', galeriDurumu='"+galeriDurumu+"' WHERE galeriID='"+galeriID+"'");
        } catch (Exception e) {
        }
    
    return sonuc;
    }
    
    public Boolean galeriEkle(String galeriAdi,String galeriAciklamasi,String galeriDurumu)
    {
        boolean sonuc=false;
        try {
            sonuc=st.execute("INSERT INTO galeriler VALUES(null,'"+galeriAdi+"','"+galeriAciklamasi+"','"+galeriDurumu+"',now())");
        } catch (Exception e) {
        }
    
    return sonuc;
    }
    
    ArrayList<propertyTopList> topLists = new ArrayList<>();

    public ArrayList<propertyTopList> topListGetir() {
        try {
            rs = st.executeQuery("SELECT urunler.baslik, urunler.detay, urunler.gecerliFiyat, urunler.id, urunler.katID, urun_fotograflari.urun_id, urun_fotograflari.adi, urun_fotograflari.klasor, kategori.katAdi FROM urunler INNER JOIN kategori on kategori.katID=urunler.katID INNER JOIN urun_fotograflari ON urun_fotograflari.urun_id=urunler.id WHERE urun_fotograflari.album_adi='urunler' order by urunler.id desc");
            while (rs.next()) {
                propertyTopList pro = new propertyTopList();

                pro.setBaslik(rs.getString("baslik"));
                pro.setDetay(rs.getString("detay"));
                pro.setGecerliFiyat(rs.getString("gecerliFiyat"));
                pro.setId(rs.getString("id"));
                pro.setKatAdi(rs.getString("katAdi"));
                pro.setKatID(rs.getString("katID"));
                pro.setKlasor(rs.getString("klasor"));
                pro.setUrun_id(rs.getString("urun_id"));
                pro.setResAdi(rs.getString("adi"));

                topLists.add(pro);
            }
        } catch (Exception e) {
        }
        return topLists;
    }
    
    
    
    
   // md5 fonk 
   public String MD5(String md5) {
   try {
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
        byte[] array = md.digest(md5.getBytes());
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < array.length; ++i) {
          sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
       }
        return sb.toString();
    } catch (java.security.NoSuchAlgorithmException e) {
    }
    return null;
}
  
   // video query
   public void query(String q)
    {
        try {
            st.execute(q);
        } catch (Exception e) {
        }
        
    }
   
   
   
   // data getir
    public ResultSet dataGtr(String tableName) {
        
        try {
            rs = st.executeQuery(tableName);
        } catch (Exception e) {
            System.err.println("Data Getirme Hatası : " + e);
        }
        return rs;
    }
   
   
}
